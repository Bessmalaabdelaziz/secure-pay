import { readFile, writeFile, mkdir } from 'node:fs/promises'

const css = await readFile('/tmp/fonts.css', 'utf8')
const KEEP = new Set(['latin', 'latin-ext', 'arabic'])
const blockRe = /\/\*\s*([a-z-]+)\s*\*\/\s*(@font-face\s*\{[^}]*\})/g

await mkdir('public/fonts', { recursive: true })

const out = []
let m
let count = 0
while ((m = blockRe.exec(css))) {
  const [, subset, block] = m
  if (!KEEP.has(subset)) continue
  const url = block.match(/url\((https:[^)]+\.woff2)\)/)?.[1]
  const family = block.match(/font-family:\s*'([^']+)'/)?.[1]
  const weight = block.match(/font-weight:\s*(\d+)/)?.[1]
  if (!url || !family || !weight) continue
  const name = `${family.toLowerCase().replace(/\s+/g, '-')}-${weight}-${subset}.woff2`
  const res = await fetch(url)
  if (!res.ok) throw new Error(`failed ${url}: ${res.status}`)
  await writeFile(`public/fonts/${name}`, Buffer.from(await res.arrayBuffer()))
  out.push(block.replace(url, `url('/fonts/${name}')`))
  count++
}

await writeFile('public/fonts/fonts.css', `/* Self-hosted Inter + Noto Kufi Arabic (SIL Open Font License) */\n${out.join('\n')}\n`)
console.log(`bundled ${count} font files`)
