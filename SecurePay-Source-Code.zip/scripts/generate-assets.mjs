import sharp from 'sharp'
import { mkdir } from 'node:fs/promises'

const OUT = 'assets'
await mkdir(OUT, { recursive: true })

const shield = (size, opacity = 1) => `
  <g opacity="${opacity}">
    <path d="M256 96l128 52v104c0 82-54 141-128 164-74-23-128-82-128-164V148l128-52z"
      fill="url(#g)" opacity="0.18"/>
    <path d="M256 96l128 52v104c0 82-54 141-128 164-74-23-128-82-128-164V148l128-52z"
      fill="none" stroke="url(#g)" stroke-width="18" stroke-linejoin="round"/>
    <path d="M200 262l40 40 78-86" fill="none" stroke="#EAF0FA" stroke-width="22"
      stroke-linecap="round" stroke-linejoin="round"/>
  </g>`

const defs = `<defs>
  <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#3B76FF"/>
    <stop offset="1" stop-color="#22D3EE"/>
  </linearGradient>
</defs>`

const iconOnly = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  ${defs}
  <rect width="512" height="512" rx="112" fill="#060C1A"/>
  <rect width="512" height="512" rx="112" fill="url(#bgGlow)" opacity="0.55"/>
  <defs>
    <radialGradient id="bgGlow" cx="0.25" cy="0.1" r="0.9">
      <stop offset="0" stop-color="#1B3C7A"/>
      <stop offset="1" stop-color="#060C1A"/>
    </radialGradient>
  </defs>
  ${shield(512)}
</svg>`

const iconForeground = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  ${defs}
  <g transform="translate(256 256) scale(0.62) translate(-256 -256)">
    ${shield(512)}
  </g>
</svg>`

const iconBackground = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <radialGradient id="bgg" cx="0.28" cy="0.12" r="0.95">
      <stop offset="0" stop-color="#1B3C7A"/>
      <stop offset="0.55" stop-color="#0A1428"/>
      <stop offset="1" stop-color="#060C1A"/>
    </radialGradient>
  </defs>
  <rect width="512" height="512" fill="url(#bgg)"/>
</svg>`

const splash = (dark = false) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 2732 2732" width="2732" height="2732">
  ${defs}
  <defs>
    <radialGradient id="s1" cx="0.2" cy="0.12" r="0.7">
      <stop offset="0" stop-color="#1E4BA8" stop-opacity="${dark ? 0.5 : 0.7}"/>
      <stop offset="1" stop-color="#060C1A" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="s2" cx="0.88" cy="0.62" r="0.6">
      <stop offset="0" stop-color="#0E7490" stop-opacity="${dark ? 0.35 : 0.5}"/>
      <stop offset="1" stop-color="#060C1A" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <rect width="2732" height="2732" fill="#060C1A"/>
  <rect width="2732" height="2732" fill="url(#s1)"/>
  <rect width="2732" height="2732" fill="url(#s2)"/>
  <g transform="translate(1366 1366) scale(1.5) translate(-256 -256)">
    ${shield(512)}
  </g>
</svg>`

await sharp(Buffer.from(iconOnly)).png().resize(1024, 1024).toFile(`${OUT}/icon-only.png`)
await sharp(Buffer.from(iconForeground)).png().resize(1024, 1024).toFile(`${OUT}/icon-foreground.png`)
await sharp(Buffer.from(iconBackground)).png().resize(1024, 1024).toFile(`${OUT}/icon-background.png`)
await sharp(Buffer.from(splash(false))).png().resize(2732, 2732).toFile(`${OUT}/splash.png`)
await sharp(Buffer.from(splash(true))).png().resize(2732, 2732).toFile(`${OUT}/splash-dark.png`)

console.log('assets written')
