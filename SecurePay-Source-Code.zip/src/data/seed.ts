import type {
  AppState,
  BankRecord,
  PaymentMethod,
  ReceiptAnalysis,
  Transaction,
  TxStatus,
  User,
} from '../types'
import { hashPassword } from '../lib/format'
import { reconcileAlerts } from '../lib/fraud'

function mulberry32(seed: number) {
  let a = seed
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

export function hashString(s: string): number {
  let h = 2166136261
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 16777619)
  }
  return Math.abs(h)
}

const CUSTOMERS = [
  'Amine Cherif',
  'Sofiane Bensalem',
  'Yasmine Kaci',
  'Mohamed Larbi',
  'Hakim Bouzid',
  'Sara Benali',
  'Rachid Meziane',
  'Imane Toumi',
  'Kamel Ferhat',
  'Nawel Brahimi',
  'Bilal Saadi',
  'Lyes Hamdi',
  'Farid Ould Ali',
  'Meriem Zerrouki',
  'Omar Benyahia',
  'Salima Ait Ali',
  'Toufik Guerroudj',
  'Nassim Boudjelal',
  'Hinda Mansouri',
  'Walid Kherbache',
]

const TERMINALS = ['TPE-001', 'TPE-002', 'TPE-003']

function pick<T>(r: number, arr: T[]): T {
  return arr[Math.floor(r * arr.length) % arr.length]
}

function amountFor(r: number): number {
  if (r < 0.18) return Math.round((300 + r * 7_000) / 100) * 100
  if (r < 0.62) return Math.round((1_500 + (r - 0.18) * 26_000) / 50) * 50
  if (r < 0.92) return Math.round((12_000 + (r - 0.62) * 90_000) / 500) * 500
  return Math.round((60_000 + (r - 0.92) * 1_200_000) / 500) * 500
}

function reference(date: Date, rand: () => number): string {
  const yy = String(date.getFullYear()).slice(-2)
  const mm = String(date.getMonth() + 1).padStart(2, '0')
  const dd = String(date.getDate()).padStart(2, '0')
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  let code = ''
  for (let i = 0; i < 6; i++) code += alphabet[Math.floor(rand() * alphabet.length)]
  return `TPE${yy}${mm}${dd}-${code}`
}

function issuerFor(method: PaymentMethod): string {
  if (method === 'cash') return 'Encaissement caisse'
  if (method === 'virement') return 'BNA · Virement'
  return method === 'cib' ? 'SATIM · CIB' : 'SATIM · Edahabia'
}

export function simulateBankRecord(input: {
  reference: string
  amount: number
  terminal: string
  method: PaymentMethod
  date: string
}): BankRecord {
  const h = hashString(`${input.reference}|${input.amount}|${input.terminal}`)
  const issuer = issuerFor(input.method)
  if (input.method === 'cash') {
    return {
      reference: input.reference,
      status: 'confirmed',
      settledAmount: input.amount,
      settlementDate: input.date,
      terminal: input.terminal,
      issuer,
      message: 'Encaissement en espèces enregistré au point de vente.',
    }
  }
  const roll = h % 100
  const settlement = new Date(new Date(input.date).getTime() + 22 * 3600_000)
  if (input.method === 'virement') {
    return roll < 80
      ? {
          reference: input.reference,
          status: 'confirmed',
          settledAmount: input.amount,
          settlementDate: settlement.toISOString(),
          terminal: input.terminal,
          issuer,
          message: 'Virement reçu et rapproché au compte du commerce.',
        }
      : {
          reference: input.reference,
          status: 'pending',
          settledAmount: 0,
          terminal: input.terminal,
          issuer,
          message: 'Virement en cours de traitement interbancaire.',
        }
  }
  if (roll < 58) {
    return {
      reference: input.reference,
      status: 'confirmed',
      settledAmount: input.amount,
      settlementDate: settlement.toISOString(),
      terminal: input.terminal,
      issuer,
      message: 'Transaction autorisée et réglée par la banque.',
    }
  }
  if (roll < 74) {
    return {
      reference: input.reference,
      status: 'pending',
      settledAmount: 0,
      terminal: input.terminal,
      issuer,
      message: 'Autorisation reçue, compensation en attente.',
    }
  }
  if (roll < 84) {
    return {
      reference: input.reference,
      status: 'failed',
      settledAmount: 0,
      terminal: input.terminal,
      issuer,
      message: 'Transaction refusée par la banque émettrice.',
    }
  }
  if (roll < 92) {
    const factor = 0.55 + ((h >> 7) % 35) / 100
    const settled = Math.round((input.amount * factor) / 10) * 10
    return {
      reference: input.reference,
      status: 'mismatch',
      settledAmount: settled,
      settlementDate: settlement.toISOString(),
      terminal: input.terminal,
      issuer,
      message: 'Montant réglé différent du montant demandé.',
    }
  }
  return {
    reference: input.reference,
    status: 'not_found',
    settledAmount: 0,
    terminal: input.terminal,
    issuer,
    message: "Référence absente du registre de compensation.",
  }
}

function bankFromStatus(tx: Transaction): BankRecord {
  const base = {
    reference: tx.reference,
    terminal: tx.terminal,
    issuer: issuerFor(tx.method),
  }
  switch (tx.status) {
    case 'confirmed':
      return {
        ...base,
        status: 'confirmed',
        settledAmount: tx.amountExpected,
        settlementDate: new Date(new Date(tx.date).getTime() + 20 * 3600_000).toISOString(),
        message: 'Transaction autorisée et réglée par la banque.',
      }
    case 'pending':
      return {
        ...base,
        status: 'pending',
        settledAmount: 0,
        message: 'Autorisation reçue, compensation en attente.',
      }
    case 'delayed':
      return {
        ...base,
        status: 'pending',
        settledAmount: 0,
        message: 'Délai de compensation dépassé (plus de 48 h).',
      }
    case 'failed':
      return {
        ...base,
        status: 'failed',
        settledAmount: 0,
        message: 'Transaction refusée par la banque émettrice.',
      }
    case 'missing':
      return {
        ...base,
        status: 'not_found',
        settledAmount: 0,
        message: 'Référence absente du registre de compensation.',
      }
    case 'suspicious':
      return {
        ...base,
        status: tx.amountConfirmed > 0 ? 'mismatch' : 'not_found',
        settledAmount: tx.amountConfirmed,
        settlementDate: tx.amountConfirmed > 0 ? tx.date : undefined,
        message:
          tx.amountConfirmed > 0
            ? 'Montant réglé différent du montant demandé.'
            : 'Référence absente du registre de compensation.',
      }
  }
}

export const DEMO_PASSWORD = 'demo1234'

export async function createSeedState(): Promise<AppState> {
  const ownerSalt = 'sp-owner-9f2a'
  const karimSalt = 'sp-karim-71cd'
  const nadiaSalt = 'sp-nadia-4b8e'

  const ownerHash = await hashPassword(DEMO_PASSWORD, ownerSalt)
  const karimHash = await hashPassword(DEMO_PASSWORD, karimSalt)
  const nadiaHash = await hashPassword(DEMO_PASSWORD, nadiaSalt)

  const createdAt = new Date(Date.now() - 120 * 86400_000).toISOString()

  const users: User[] = [
    {
      id: 'u_owner',
      name: 'Yacine Belkacem',
      email: 'demo@securepay.dz',
      phone: '+213 660 12 34 56',
      role: 'owner',
      shopName: 'Épicerie El Baraka',
      passwordHash: ownerHash,
      salt: ownerSalt,
      permissions: {
        addTransaction: true,
        viewAllTransactions: true,
        viewReports: true,
        viewFraud: true,
        verifyPayments: true,
        manageEmployees: true,
      },
      active: true,
      createdAt,
      color: '#2F6BFF',
    },
    {
      id: 'u_karim',
      name: 'Karim Haddad',
      email: 'karim@securepay.dz',
      phone: '+213 661 88 20 14',
      role: 'employee',
      shopName: 'Épicerie El Baraka',
      passwordHash: karimHash,
      salt: karimSalt,
      permissions: {
        addTransaction: true,
        viewAllTransactions: false,
        viewReports: false,
        viewFraud: false,
        verifyPayments: false,
        manageEmployees: false,
      },
      active: true,
      createdAt,
      color: '#22C55E',
    },
    {
      id: 'u_nadia',
      name: 'Nadia Saidi',
      email: 'nadia@securepay.dz',
      phone: '+213 770 45 09 31',
      role: 'employee',
      shopName: 'Épicerie El Baraka',
      passwordHash: nadiaHash,
      salt: nadiaSalt,
      permissions: {
        addTransaction: true,
        viewAllTransactions: true,
        viewReports: false,
        viewFraud: false,
        verifyPayments: true,
        manageEmployees: false,
      },
      active: true,
      createdAt,
      color: '#8B5CF6',
    },
  ]

  const rand = mulberry32(20261106)
  const now = new Date()
  const transactions: Transaction[] = []

  const employeeIds = ['u_karim', 'u_nadia', 'u_owner']

  for (let i = 0; i < 116; i++) {
    const dayOffset = Math.floor(rand() * 45)
    const hour = 8 + Math.floor(rand() * 12)
    const minute = Math.floor(rand() * 60)
    const date = new Date(now)
    date.setDate(date.getDate() - dayOffset)
    date.setHours(hour, minute, Math.floor(rand() * 60), 0)
    if (date.getTime() > now.getTime()) date.setDate(date.getDate() - 1)

    const roll = rand()
    const methodRoll = rand()
    const method: PaymentMethod =
      methodRoll < 0.46
        ? 'cib'
        : methodRoll < 0.79
          ? 'edahabia'
          : methodRoll < 0.93
            ? 'cash'
            : 'virement'

    const expected = amountFor(rand())
    const ageHours = (now.getTime() - date.getTime()) / 3600_000

    let status: TxStatus
    if (roll < 0.64) status = 'confirmed'
    else if (roll < 0.76) status = 'pending'
    else if (roll < 0.82) status = ageHours > 48 ? 'delayed' : 'pending'
    else if (roll < 0.88) status = 'failed'
    else if (roll < 0.94) status = 'missing'
    else status = 'suspicious'

    if (method === 'cash' && ['missing', 'delayed'].includes(status)) status = 'confirmed'

    const confirmed =
      status === 'confirmed'
        ? expected
        : status === 'suspicious'
          ? Math.round((expected * (0.25 + rand() * 0.4)) / 10) * 10
          : 0

    const employeeId = pick(rand(), employeeIds)
    const tx: Transaction = {
      id: `tx_${i}_${Math.floor(rand() * 1e6).toString(36)}`,
      reference: reference(date, rand),
      amountExpected: expected,
      amountConfirmed: confirmed,
      date: date.toISOString(),
      method,
      status,
      customer: pick(rand(), CUSTOMERS),
      terminal: pick(rand(), TERMINALS),
      employeeId,
      notes: '',
      flags: [],
      createdAt: new Date(date.getTime() + 120_000).toISOString(),
      updatedAt: new Date(date.getTime() + 120_000).toISOString(),
    }
    if (status === 'missing' || status === 'suspicious' || status === 'delayed') {
      tx.bankCheckedAt = new Date(date.getTime() + 86400_000).toISOString()
    }
    if (status === 'confirmed' && rand() < 0.5) {
      tx.bankCheckedAt = new Date(date.getTime() + 3600_000).toISOString()
      tx.bankRef = `BR${hashString(tx.reference) % 10_000_000}`
      tx.bankMessage = 'Transaction autorisée et réglée par la banque.'
    }
    transactions.push(tx)
  }

  // --- Scripted cases that exercise every detection rule -------------------
  const dupRef = 'TPE' + reference(new Date(), rand).slice(3, 9) + '-DUP41X'
  const dupDateA = new Date(now.getTime() - 3 * 86400_000)
  dupDateA.setHours(11, 24, 0, 0)
  const dupDateB = new Date(now.getTime() - 2 * 86400_000)
  dupDateB.setHours(16, 12, 0, 0)

  const dupA: Transaction = {
    id: 'tx_dup_a',
    reference: dupRef,
    amountExpected: 24_500,
    amountConfirmed: 24_500,
    date: dupDateA.toISOString(),
    method: 'cib',
    status: 'confirmed',
    customer: 'Amine Cherif',
    terminal: 'TPE-002',
    employeeId: 'u_karim',
    notes: 'Paiement initial, ticket remis au client.',
    bankRef: 'BR8841203',
    bankCheckedAt: dupDateA.toISOString(),
    bankMessage: 'Transaction autorisée et réglée par la banque.',
    flags: [],
    createdAt: dupDateA.toISOString(),
    updatedAt: dupDateA.toISOString(),
  }
  const dupB: Transaction = {
    id: 'tx_dup_b',
    reference: dupRef,
    amountExpected: 24_500,
    amountConfirmed: 0,
    date: dupDateB.toISOString(),
    method: 'cib',
    status: 'suspicious',
    customer: 'Inconnu',
    terminal: 'TPE-002',
    employeeId: 'u_karim',
    notes: 'Même référence que la transaction tx_dup_a.',
    duplicateOf: 'tx_dup_a',
    flags: ['duplicate'],
    bankCheckedAt: dupDateB.toISOString(),
    bankMessage: 'Référence déjà réglée : second encaissement impossible.',
    createdAt: dupDateB.toISOString(),
    updatedAt: dupDateB.toISOString(),
  }

  const mismatchDate = new Date(now.getTime() - 5 * 86400_000)
  mismatchDate.setHours(15, 3, 0, 0)
  const mismatch: Transaction = {
    id: 'tx_mismatch',
    reference: 'TPE' + reference(mismatchDate, rand).slice(3, 9) + '-M5T29K',
    amountExpected: 46_500,
    amountConfirmed: 42_000,
    date: mismatchDate.toISOString(),
    method: 'edahabia',
    status: 'suspicious',
    customer: 'Sofiane Bensalem',
    terminal: 'TPE-001',
    employeeId: 'u_nadia',
    notes: 'Client affirme avoir payé 46 500 DZD. Reçu à contrôler.',
    bankCheckedAt: mismatchDate.toISOString(),
    bankMessage: 'Montant réglé différent du montant demandé.',
    flags: ['amount_mismatch'],
    createdAt: mismatchDate.toISOString(),
    updatedAt: mismatchDate.toISOString(),
  }

  const missingDate = new Date(now.getTime() - 6 * 86400_000)
  missingDate.setHours(12, 40, 0, 0)
  const missing: Transaction = {
    id: 'tx_missing',
    reference: 'TPE' + reference(missingDate, rand).slice(3, 9) + '-MSS118',
    amountExpected: 32_400,
    amountConfirmed: 0,
    date: missingDate.toISOString(),
    method: 'cib',
    status: 'missing',
    customer: 'Yasmine Kaci',
    terminal: 'TPE-003',
    employeeId: 'u_karim',
    notes: 'Ticket imprimé mais aucun règlement constaté.',
    bankCheckedAt: missingDate.toISOString(),
    bankMessage: 'Référence absente du registre de compensation.',
    flags: ['missing'],
    createdAt: missingDate.toISOString(),
    updatedAt: missingDate.toISOString(),
  }

  const delayedDate = new Date(now.getTime() - 4 * 86400_000)
  delayedDate.setHours(18, 55, 0, 0)
  const delayed: Transaction = {
    id: 'tx_delayed',
    reference: 'TPE' + reference(delayedDate, rand).slice(3, 9) + '-DLY772',
    amountExpected: 78_000,
    amountConfirmed: 0,
    date: delayedDate.toISOString(),
    method: 'edahabia',
    status: 'delayed',
    customer: 'Mohamed Larbi',
    terminal: 'TPE-001',
    employeeId: 'u_nadia',
    notes: 'Compensation annoncée sous 24 h, toujours rien.',
    bankCheckedAt: delayedDate.toISOString(),
    bankMessage: 'Délai de compensation dépassé (plus de 48 h).',
    flags: ['delayed'],
    createdAt: delayedDate.toISOString(),
    updatedAt: delayedDate.toISOString(),
  }

  const highDate = new Date(now.getTime() - 2 * 86400_000)
  highDate.setHours(10, 15, 0, 0)
  const highValue: Transaction = {
    id: 'tx_high',
    reference: 'TPE' + reference(highDate, rand).slice(3, 9) + '-HV9001',
    amountExpected: 168_000,
    amountConfirmed: 168_000,
    date: highDate.toISOString(),
    method: 'virement',
    status: 'confirmed',
    customer: 'Hakim Bouzid',
    terminal: 'TPE-003',
    employeeId: 'u_owner',
    notes: 'Commande en gros — 12 cartons.',
    bankCheckedAt: highDate.toISOString(),
    bankMessage: 'Virement reçu et rapproché au compte du commerce.',
    flags: ['high_value'],
    createdAt: highDate.toISOString(),
    updatedAt: highDate.toISOString(),
  }

  const nightDate = new Date(now.getTime() - 86400_000)
  nightDate.setHours(1, 20, 0, 0)
  const night: Transaction = {
    id: 'tx_night',
    reference: 'TPE' + reference(nightDate, rand).slice(3, 9) + '-NGT044',
    amountExpected: 24_500,
    amountConfirmed: 0,
    date: nightDate.toISOString(),
    method: 'cib',
    status: 'pending',
    customer: 'Bilal Saadi',
    terminal: 'TPE-002',
    employeeId: 'u_karim',
    notes: 'Encaissement nocturne inhabituel.',
    flags: ['off_hours'],
    createdAt: nightDate.toISOString(),
    updatedAt: nightDate.toISOString(),
  }

  const receiptTx: ReceiptAnalysis = {
    fileName: 'recu_tpe_5400.jpg',
    analyzedAt: new Date(now.getTime() - 3 * 86000_000).toISOString(),
    score: 34,
    verdict: 'suspicious',
    checks: [
      { id: 'reference', ok: true, detail: 'Référence lisible et identique.' },
      { id: 'amount', ok: true, detail: 'Montant aligné avec la saisie.' },
      { id: 'date', ok: false, detail: 'Date du ticket : 12/09, saisie : 05/09.' },
      { id: 'terminal', ok: true, detail: 'TPE-001 détecté sur le ticket.' },
      { id: 'stamp', ok: false, detail: 'Aucun cachet / signature du terminal.' },
      { id: 'font', ok: false, detail: 'Police du total différente du reste du ticket.' },
      { id: 'duplicate', ok: true, detail: 'Aucun autre reçu identique.' },
    ],
    ocr: {
      reference: 'TPE260905-K4L91P',
      amount: 58_000,
      date: '05/09/2026',
      terminal: 'TPE-001',
      merchant: 'ÉPICERIE EL BARAKA',
    },
  }
  const receiptDate = new Date(now.getTime() - 3 * 86400_000)
  receiptDate.setHours(17, 12, 0, 0)
  const suspiciousReceipt: Transaction = {
    id: 'tx_receipt',
    reference: 'TPE' + reference(receiptDate, rand).slice(3, 9) + '-K4L91P',
    amountExpected: 58_000,
    amountConfirmed: 58_000,
    date: receiptDate.toISOString(),
    method: 'cib',
    status: 'confirmed',
    customer: 'Imane Toumi',
    terminal: 'TPE-001',
    employeeId: 'u_nadia',
    notes: 'Reçu joint par l’employé, quelques incohérences visibles.',
    bankCheckedAt: receiptDate.toISOString(),
    bankMessage: 'Transaction autorisée et réglée par la banque.',
    flags: [],
    receipt: receiptTx,
    createdAt: receiptDate.toISOString(),
    updatedAt: receiptDate.toISOString(),
  }

  const failedDate = new Date(now.getTime() - 7 * 3600_000)
  const failed: Transaction = {
    id: 'tx_failed',
    reference: 'TPE' + reference(failedDate, rand).slice(3, 9) + '-FAL602',
    amountExpected: 9_400,
    amountConfirmed: 0,
    date: failedDate.toISOString(),
    method: 'cib',
    status: 'failed',
    customer: 'Sara Benali',
    terminal: 'TPE-001',
    employeeId: 'u_karim',
    notes: 'Deuxième tentative refusée : plafond dépassé.',
    bankCheckedAt: failedDate.toISOString(),
    bankMessage: 'Transaction refusée par la banque émettrice.',
    flags: ['failed'],
    createdAt: failedDate.toISOString(),
    updatedAt: failedDate.toISOString(),
  }

  // Burst of 4 payments within 10 minutes (rapid rule)
  const burstBase = new Date(now.getTime() - 30 * 3600_000)
  const burst: Transaction[] = [0, 3, 6, 9].map((mins, idx) => {
    const d = new Date(burstBase.getTime() + mins * 60_000)
    return {
      id: `tx_burst_${idx}`,
      reference: 'TPE' + reference(d, rand).slice(3, 9) + `-RPD${idx}01`,
      amountExpected: 3_200 + idx * 1_500,
      amountConfirmed: 3_200 + idx * 1_500,
      date: d.toISOString(),
      method: 'cib' as PaymentMethod,
      status: 'confirmed' as TxStatus,
      customer: pick(rand(), CUSTOMERS),
      terminal: 'TPE-003',
      employeeId: 'u_karim',
      notes: 'Série de paiements rapprochés.',
      bankCheckedAt: d.toISOString(),
      bankMessage: 'Transaction autorisée et réglée par la banque.',
      flags: ['rapid_succession'],
      createdAt: d.toISOString(),
      updatedAt: d.toISOString(),
    }
  })

  // Today's activity so the dashboard is alive on first open
  const todayBase = new Date(now)
  const todaySpecs: { hoursAgo: number; amount: number; status: TxStatus; method: PaymentMethod }[] = [
    { hoursAgo: 0.4, amount: 8_500, status: 'pending', method: 'cib' },
    { hoursAgo: 1.2, amount: 3_250, status: 'confirmed', method: 'edahabia' },
    { hoursAgo: 2.1, amount: 12_800, status: 'confirmed', method: 'cib' },
    { hoursAgo: 3.4, amount: 1_900, status: 'confirmed', method: 'cash' },
    { hoursAgo: 4.6, amount: 27_400, status: 'pending', method: 'edahabia' },
    { hoursAgo: 5.8, amount: 6_700, status: 'failed', method: 'cib' },
    { hoursAgo: 7.5, amount: 14_100, status: 'confirmed', method: 'cib' },
  ]
  todaySpecs.forEach((spec, idx) => {
    const d = new Date(todayBase.getTime() - spec.hoursAgo * 3600_000)
    const tx: Transaction = {
      id: `tx_today_${idx}`,
      reference: 'TPE' + reference(d, rand).slice(3, 9) + `-T${String(idx).padStart(2, '0')}9X`,
      amountExpected: spec.amount,
      amountConfirmed: spec.status === 'confirmed' ? spec.amount : 0,
      date: d.toISOString(),
      method: spec.method,
      status: spec.status,
      customer: pick(rand(), CUSTOMERS),
      terminal: pick(rand(), TERMINALS),
      employeeId: idx % 2 === 0 ? 'u_karim' : 'u_nadia',
      notes: '',
      flags: [],
      createdAt: d.toISOString(),
      updatedAt: d.toISOString(),
    }
    if (spec.status === 'confirmed') {
      tx.bankRef = `BR${hashString(tx.reference) % 10_000_000}`
      tx.bankCheckedAt = new Date(d.getTime() + 40 * 60_000).toISOString()
      tx.bankMessage = 'Transaction autorisée et réglée par la banque.'
    }
    transactions.push(tx)
  })

  const all = [
    dupA,
    dupB,
    mismatch,
    missing,
    delayed,
    highValue,
    night,
    suspiciousReceipt,
    failed,
    ...burst,
    ...transactions,
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())

  const bankLedger: Record<string, BankRecord> = {}
  for (const tx of all) {
    if (!bankLedger[tx.reference]) bankLedger[tx.reference] = bankFromStatus(tx)
  }
  // The duplicate pair shares one settled record in the bank ledger.
  bankLedger[dupB.reference] = bankFromStatus(dupA)

  const settings = {
    lang: 'fr' as const,
    notificationsEnabled: true,
    biometric: false,
    twoFactor: true,
    highValueThreshold: 100_000,
    autoLockMinutes: 15,
  }

  let alerts = [] as AppState['alerts']
  for (const tx of all) {
    alerts = reconcileAlerts(alerts, tx, all, settings)
  }
  // Mark the noisiest historical alerts as already read, keep recent ones unread.
  const cutoff = Date.now() - 24 * 3600_000
  alerts = alerts.map((a) => {
    const tx = all.find((t) => t.id === a.transactionId)
    const isRecent = tx ? new Date(tx.date).getTime() > cutoff : true
    return isRecent ? a : { ...a, read: true }
  })

  const audit = [
    {
      id: 'au_seed_1',
      actorId: 'u_owner',
      actorName: 'Yacine Belkacem',
      action: 'Connexion',
      detail: 'Connexion propriétaire · appareil de confiance',
      at: new Date(now.getTime() - 2 * 3600_000).toISOString(),
      severity: 'low' as const,
    },
    {
      id: 'au_seed_2',
      actorId: 'u_karim',
      actorName: 'Karim Haddad',
      action: 'Nouvelle transaction',
      detail: `${failed.reference} · 9 400 DZD · Carte CIB`,
      at: failed.createdAt,
      severity: 'low' as const,
    },
    {
      id: 'au_seed_3',
      actorId: 'u_nadia',
      actorName: 'Nadia Saidi',
      action: 'Analyse de reçu',
      detail: `${suspiciousReceipt.reference} · score 34/100 · reçu suspect`,
      at: receiptTx.analyzedAt,
      severity: 'medium' as const,
    },
    {
      id: 'au_seed_4',
      actorId: 'u_owner',
      actorName: 'Yacine Belkacem',
      action: 'Vérification bancaire',
      detail: `${missing.reference} · référence absente du registre`,
      at: missing.bankCheckedAt ?? missing.date,
      severity: 'high' as const,
    },
  ]

  return {
    version: 1,
    users,
    transactions: all,
    alerts,
    audit,
    bankLedger,
    settings,
    sessionUserId: null,
  }
}
