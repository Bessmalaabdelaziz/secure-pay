import { useMemo, useState } from 'react'
import { useStore } from '../store'
import {
  AccessDenied,
  Button,
  Card,
  EmptyState,
  InfoNote,
  PageHeader,
  ProgressBar,
  Screen,
  SectionHeader,
  Segmented,
} from '../components/ui'
import { Icon, type IconName } from '../components/icons'
import { BarPairChart, Donut, HBars } from '../components/charts'
import {
  computeStats,
  dailySeries,
  employeeBreakdown,
  filterRange,
  methodBreakdown,
  monthlySeries,
  statusBreakdown,
  toCSV,
} from '../lib/stats'
import { downloadFile, formatAmount, formatDate, METHOD_LABEL } from '../lib/format'

type Period = 'day' | 'week' | 'month'
type Granularity = 'daily' | 'monthly'

const DAYS: Record<Period, number> = { day: 1, week: 7, month: 30 }

export default function Reports() {
  const { t, lang, state, can, currentUser, employeeName, notify } = useStore()
  const [period, setPeriod] = useState<Period>('week')
  const [granularity, setGranularity] = useState<Granularity>('daily')

  const scoped = useMemo(
    () =>
      can('viewAllTransactions')
        ? state.transactions
        : state.transactions.filter((tx) => tx.employeeId === currentUser?.id),
    [state.transactions, can, currentUser?.id],
  )

  const txns = useMemo(() => filterRange(scoped, DAYS[period]), [scoped, period])
  const stats = useMemo(() => computeStats(txns), [txns])
  const points = useMemo(
    () => (granularity === 'daily' ? dailySeries(scoped, DAYS[period] === 1 ? 7 : DAYS[period]) : monthlySeries(scoped, 6)),
    [scoped, granularity, period],
  )
  const byStatus = useMemo(() => statusBreakdown(txns), [txns])
  const byMethod = useMemo(() => methodBreakdown(txns), [txns])
  const byEmployee = useMemo(
    () => employeeBreakdown(txns, Object.fromEntries(state.users.map((u) => [u.id, u.name]))),
    [txns, state.users],
  )

  const insights = useMemo(() => {
    const items: { icon: IconName; text: string }[] = []
    const best = [...points].sort((a, b) => b.confirmed - a.confirmed)[0]
    if (best && best.confirmed > 0) {
      items.push({
        icon: 'trendUp',
        text: t('rep.insightBestDay', {
          day: formatDate(best.date.toISOString(), lang),
          amount: formatAmount(best.confirmed),
        }),
      })
    }
    const risky = txns.filter((x) => ['missing', 'failed'].includes(x.status))
    if (risky.length) {
      items.push({
        icon: 'alertTriangle',
        text: t('rep.insightMissing', {
          count: risky.length,
          amount: formatAmount(risky.reduce((s, x) => s + x.amountExpected, 0)),
        }),
      })
    }
    const checked = txns.filter((x) => x.bankCheckedAt && x.amountConfirmed > 0)
    if (checked.length) {
      const hours =
        checked.reduce(
          (s, x) =>
            s + (new Date(x.bankCheckedAt!).getTime() - new Date(x.date).getTime()) / 3_600_000,
          0,
        ) / checked.length
      items.push({
        icon: 'clock',
        text: t('rep.insightDelay', { hours: Math.max(1, Math.round(hours)) }),
      })
    }
    const prev = filterRange(scoped, DAYS[period] * 2).filter(
      (x) => new Date(x.date).getTime() < Date.now() - DAYS[period] * 86_400_000,
    )
    const prevConfirmed = computeStats(prev).confirmed
    if (prevConfirmed > 0) {
      const growth = ((stats.confirmed - prevConfirmed) / prevConfirmed) * 100
      items.push({
        icon: growth >= 0 ? 'trendUp' : 'trendDown',
        text: t('rep.insightGrowth', {
          value: `${growth >= 0 ? '+' : ''}${Math.round(growth)}`,
        }),
      })
    }
    const topMethod = [...byMethod].sort((a, b) => b.count - a.count)[0]
    if (topMethod) {
      items.push({
        icon: 'card',
        text: t('rep.insightMethod', {
          method: METHOD_LABEL[topMethod.method][lang],
          value: Math.round((topMethod.count / Math.max(txns.length, 1)) * 100),
        }),
      })
    }
    return items
  }, [points, txns, scoped, period, stats.confirmed, byMethod, t, lang])

  if (!can('viewReports')) return <AccessDenied />

  const exportCsv = () => {
    const names = Object.fromEntries(state.users.map((u) => [u.id, u.name]))
    const csv = toCSV(txns, names)
    downloadFile(`securepay-rapport-${period}-${new Date().toISOString().slice(0, 10)}.csv`, csv)
    notify(t('rep.exported'))
  }

  return (
    <Screen>
      <PageHeader
        title={t('rep.title')}
        subtitle={`${stats.count} ${t('tx.count')}`}
        actions={
          <button type="button" className="icon-btn" aria-label={t('rep.export')} onClick={exportCsv}>
            <Icon name="download" size={19} />
          </button>
        }
      />

      <Segmented<Period>
        name={t('rep.period')}
        value={period}
        onChange={setPeriod}
        options={[
          { value: 'day', label: t('common.today') },
          { value: 'week', label: t('dash.periodWeek') },
          { value: 'month', label: t('dash.periodMonth') },
        ]}
      />

      <div className="report-kpis">
        <Card className="report-kpi">
          <span>{t('rep.kpiExpected')}</span>
          <strong>{formatAmount(stats.expected)}</strong>
          <em>DZD</em>
        </Card>
        <Card className="report-kpi report-kpi--success">
          <span>{t('rep.kpiConfirmed')}</span>
          <strong>{formatAmount(stats.confirmed)}</strong>
          <em>DZD</em>
        </Card>
        <Card className="report-kpi report-kpi--warn">
          <span>{t('rep.kpiGap')}</span>
          <strong>{formatAmount(stats.gap)}</strong>
          <em>DZD</em>
        </Card>
        <Card className="report-kpi report-kpi--blue">
          <span>{t('rep.recovery')}</span>
          <strong>{Math.round(stats.recoveryRate)}%</strong>
          <em>{stats.count} {t('tx.count')}</em>
        </Card>
      </div>

      <Card className="chart-card">
        <div className="chart-card__head">
          <div>
            <h3>{t('rep.chartDaily')}</h3>
            <p>{t('dash.chartHint')}</p>
          </div>
        </div>
        <Segmented<Granularity>
          name={t('rep.period')}
          value={granularity}
          onChange={setGranularity}
          options={[
            { value: 'daily', label: t('rep.daily') },
            { value: 'monthly', label: t('rep.monthly') },
          ]}
        />
        <BarPairChart points={points} lang={lang} height={160} />
        <ProgressBar value={stats.recoveryRate} label={t('rep.recovery')} tone={stats.recoveryRate > 80 ? 'success' : 'warn'} />
      </Card>

      <SectionHeader title={t('rep.byStatus')} />
      <Card className="donut-card">
        {txns.length === 0 ? (
          <EmptyState icon="chart" title={t('rep.noData')} />
        ) : (
          <Donut
            data={byStatus}
            total={stats.expected}
            centerLabel={t('rep.kpiExpected')}
            lang={lang}
          />
        )}
      </Card>

      <SectionHeader title={t('rep.byMethod')} />
      <Card className="padded">
        {byMethod.length === 0 ? (
          <p className="muted-pad">{t('rep.noData')}</p>
        ) : (
          <HBars
            items={byMethod.map((m) => ({
              label: METHOD_LABEL[m.method][lang],
              value: m.amount,
              caption: `${formatAmount(m.amount)} DZD`,
              color:
                m.method === 'cib'
                  ? 'linear-gradient(90deg,#2F6BFF,#5B8CFF)'
                  : m.method === 'edahabia'
                    ? 'linear-gradient(90deg,#8B5CF6,#C084FC)'
                    : m.method === 'cash'
                      ? 'linear-gradient(90deg,#22C55E,#4ADE80)'
                      : 'linear-gradient(90deg,#22D3EE,#67E8F9)',
            }))}
          />
        )}
      </Card>

      {can('viewAllTransactions') ? (
        <>
          <SectionHeader title={t('rep.byEmployee')} />
          <Card className="padded">
            {byEmployee.length === 0 ? (
              <p className="muted-pad">{t('rep.noData')}</p>
            ) : (
              <HBars
                items={byEmployee.map((e) => ({
                  label: e.name,
                  value: e.confirmed,
                  caption: `${formatAmount(e.confirmed)} DZD · ${e.count}`,
                  color: 'linear-gradient(90deg,#22C55E,#22D3EE)',
                }))}
              />
            )}
          </Card>
        </>
      ) : null}

      <SectionHeader title={t('rep.summary')} />
      <Card className="padded">
        <ul className="insights">
          {insights.map((insight, idx) => (
            <li key={idx}>
              <span className="insights__icon">
                <Icon name={insight.icon} size={15} />
              </span>
              {insight.text}
            </li>
          ))}
          {insights.length === 0 ? <p className="muted-pad">{t('rep.noData')}</p> : null}
        </ul>
        <div className="report-actions">
          <Button variant="secondary" full icon="download" onClick={exportCsv}>
            {t('rep.export')}
          </Button>
        </div>
        <p className="report-foot">
          {employeeName(currentUser?.id ?? '')} · {t('prof.connectedAs')}
        </p>
      </Card>

      <InfoNote icon="alertTriangle" tone="warn">
        {t('rep.disclaimer')}
      </InfoNote>
    </Screen>
  )
}
