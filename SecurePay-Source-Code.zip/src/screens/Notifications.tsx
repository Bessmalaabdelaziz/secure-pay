import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { AlertRow, useAlertNavigation } from '../components/AlertRow'
import { EmptyState, PageHeader, Screen, Segmented, SectionHeader } from '../components/ui'
import { Icon } from '../components/icons'
import { sameDay } from '../lib/format'

type Tab = 'all' | 'unread'

export default function Notifications() {
  const { t, state, markAllAlertsRead, resolveAlert, notify } = useStore()
  const navigate = useNavigate()
  const openAlert = useAlertNavigation()
  const [tab, setTab] = useState<Tab>('all')

  const grouped = useMemo(() => {
    const list = state.alerts
      .filter((a) => !a.resolved)
      .filter((a) => (tab === 'unread' ? !a.read : true))
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    const today = list.filter((a) => sameDay(new Date(a.createdAt), new Date()))
    const earlier = list.filter((a) => !sameDay(new Date(a.createdAt), new Date()))
    return { today, earlier, list }
  }, [state.alerts, tab])

  const unread = state.alerts.filter((a) => !a.read && !a.resolved).length

  return (
    <Screen>
      <PageHeader
        title={t('notif.title')}
        subtitle={`${unread} ${t('notif.unread')}`}
        actions={
          <button
            type="button"
            className="icon-btn"
            aria-label={t('notif.markAll')}
            onClick={() => {
              markAllAlertsRead()
              notify(t('notif.markedAll'))
            }}
          >
            <Icon name="check" size={20} />
          </button>
        }
      />

      <Segmented<Tab>
        name={t('notif.filter')}
        value={tab}
        onChange={setTab}
        options={[
          { value: 'all', label: t('notif.all') },
          { value: 'unread', label: `${t('notif.unreadOnly')} (${unread})` },
        ]}
      />

      {grouped.list.length === 0 ? (
        <EmptyState
          icon="bell"
          title={t('notif.empty')}
          hint={t('notif.emptyHint')}
          action={
            <button type="button" className="link-btn" onClick={() => navigate('/app/profile')}>
              {t('notif.settings')} <Icon name="chevronRight" size={14} />
            </button>
          }
        />
      ) : (
        <div className="stack">
          {grouped.today.length > 0 ? (
            <section>
              <SectionHeader title={t('notif.today')} />
              <div className="alert-list">
                {grouped.today.map((alert) => (
                  <AlertRow
                    key={alert.id}
                    alert={alert}
                    onOpen={() => openAlert(alert)}
                    onResolve={() => {
                      resolveAlert(alert.id)
                      notify(t('notif.resolvedMsg'))
                    }}
                    showResolve
                  />
                ))}
              </div>
            </section>
          ) : null}
          {grouped.earlier.length > 0 ? (
            <section>
              <SectionHeader title={t('notif.earlier')} />
              <div className="alert-list">
                {grouped.earlier.map((alert) => (
                  <AlertRow
                    key={alert.id}
                    alert={alert}
                    onOpen={() => openAlert(alert)}
                    onResolve={() => {
                      resolveAlert(alert.id)
                      notify(t('notif.resolvedMsg'))
                    }}
                    showResolve
                  />
                ))}
              </div>
            </section>
          ) : null}
        </div>
      )}

      <div className="settings-hint">
        <Icon name="info" size={14} />
        <span>{t('fraud.liveNote')}</span>
      </div>
    </Screen>
  )
}
