import { useMemo, useRef, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useStore } from '../store'
import {
  Button,
  Card,
  EmptyState,
  Field,
  InfoNote,
  PageHeader,
  Screen,
  SectionHeader,
  Select,
  Sheet,
} from '../components/ui'
import { Icon } from '../components/icons'
import { formatAmount, formatDateTime } from '../lib/format'
import { resizeImage, runReceiptAnalysis } from '../lib/receipt'
import type { ReceiptAnalysis as Receipt } from '../types'
import type { TranslationKey } from '../i18n'

const CHECK_LABEL: Record<string, TranslationKey> = {
  reference: 'rec.checkRef',
  amount: 'rec.checkAmount',
  date: 'rec.checkDate',
  terminal: 'rec.checkTerminal',
  stamp: 'rec.checkStamp',
  font: 'rec.checkFont',
  duplicate: 'rec.checkDuplicate',
}

function ScoreRing({ score, verdict }: { score: number; verdict: Receipt['verdict'] }) {
  const radius = 42
  const circumference = 2 * Math.PI * radius
  const color = verdict === 'clean' ? '#22C55E' : verdict === 'doubtful' ? '#F59E0B' : '#F04438'
  return (
    <div className="ring">
      <svg viewBox="0 0 100 100" className="ring__svg">
        <circle cx="50" cy="50" r={radius} className="ring__track" />
        <circle
          cx="50"
          cy="50"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="8"
          strokeLinecap="round"
          strokeDasharray={`${(score / 100) * circumference} ${circumference}`}
          transform="rotate(-90 50 50)"
        />
      </svg>
      <div className="ring__center">
        <strong style={{ color }}>{score}</strong>
        <span>/100</span>
      </div>
    </div>
  )
}

export default function ReceiptAnalysis() {
  const { t, lang, state, currentUser, attachReceipt, notify } = useStore()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const fileRef = useRef<HTMLInputElement>(null)

  const candidates = useMemo(
    () =>
      [...state.transactions]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 25),
    [state.transactions],
  )

  const initialId = params.get('tx')
  const [txId, setTxId] = useState<string>(initialId ?? candidates[0]?.id ?? '')
  const [image, setImage] = useState<string | null>(null)
  const [fileName, setFileName] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [fresh, setFresh] = useState<Receipt | null>(null)
  const [fullImage, setFullImage] = useState(false)

  const tx = state.transactions.find((x) => x.id === txId)
  const receipt = fresh ?? tx?.receipt ?? null
  const verdictLabel =
    receipt?.verdict === 'clean'
      ? t('rec.verdictClean')
      : receipt?.verdict === 'doubtful'
        ? t('rec.verdictDoubtful')
        : t('rec.verdictSuspicious')

  const onPick = async (file: File | undefined) => {
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setError(t('add.fileType'))
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError(t('add.fileTooLarge'))
      return
    }
    try {
      const data = await resizeImage(file)
      setImage(data)
      setFileName(file.name)
      setError(null)
      setFresh(null)
    } catch {
      setError(t('common.error'))
    }
  }

  const analyze = () => {
    if (!tx) {
      setError(t('rec.needTx'))
      return
    }
    if (!image) {
      setError(t('rec.needFile'))
      return
    }
    setBusy(true)
    setError(null)
    window.setTimeout(() => {
      const analysis = runReceiptAnalysis({
        fileName: fileName || 'recu.jpg',
        image,
        tx,
        all: state.transactions,
        merchant: (currentUser?.shopName ?? 'SecurePay').toUpperCase(),
      })
      attachReceipt(tx.id, analysis)
      setFresh(analysis)
      setBusy(false)
      notify(t('rec.saved'), analysis.verdict === 'clean' ? 'success' : 'error')
    }, 1500)
  }

  return (
    <Screen>
      <PageHeader title={t('rec.title')} subtitle={t('rec.subtitle')} />

      <InfoNote icon="alertTriangle" tone="warn" title={t('common.simulation')}>
        {t('rec.disclaimer')}
      </InfoNote>

      <Card className="form-card">
        <Field label={t('rec.chooseTx')}>
          <Select value={txId} onChange={(e) => {
            setTxId(e.target.value)
            setFresh(null)
          }}>
            {candidates.map((c) => (
              <option key={c.id} value={c.id}>
                {c.reference} · {formatAmount(c.amountExpected)} DZD
              </option>
            ))}
          </Select>
        </Field>

        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="visually-hidden"
          onChange={(e) => void onPick(e.target.files?.[0])}
        />

        {image ? (
          <div className="receipt-preview">
            <button type="button" onClick={() => setFullImage(true)} className="receipt-preview__img">
              <img src={image} alt={t('rec.preview')} />
              <span className="receipt-preview__zoom">
                <Icon name="eye" size={15} />
              </span>
            </button>
            <div className="receipt-preview__meta">
              <span>{fileName}</span>
              <div className="sheet-actions">
                <Button size="sm" variant="ghost" icon="camera" onClick={() => fileRef.current?.click()}>
                  {t('rec.replace')}
                </Button>
                <Button size="sm" variant="secondary" onClick={() => setImage(null)}>
                  {t('add.removeReceipt')}
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <button type="button" className="upload-zone" onClick={() => fileRef.current?.click()}>
            <span className="upload-zone__icon">
              <Icon name="upload" size={22} />
            </span>
            <strong>{t('rec.upload')}</strong>
            <span>{t('rec.uploadHint')}</span>
          </button>
        )}

        {error ? <p className="form-error">{error}</p> : null}

        <Button full size="lg" icon="scan" loading={busy} onClick={analyze}>
          {busy ? t('rec.analyzing') : t('rec.analyze')}
        </Button>
      </Card>

      {receipt ? (
        <>
          <Card className={`receipt-result receipt-result--${receipt.verdict}`}>
            <div className="receipt-result__head">
              <ScoreRing score={receipt.score} verdict={receipt.verdict} />
              <div className="receipt-result__summary">
                <span className="receipt-result__eyebrow">{t('rec.score')}</span>
                <strong>{verdictLabel}</strong>
                <p>{t('rec.scoreHint')}</p>
                <span className="receipt-result__file">
                  <Icon name="receipt" size={12} /> {receipt.fileName}
                </span>
                <span className="receipt-result__file">
                  {formatDateTime(receipt.analyzedAt, lang)}
                </span>
              </div>
            </div>

            <div className="ocr">
              <h4>{t('rec.ocrTitle')}</h4>
              <div className="ocr__grid">
                <div>
                  <span>{t('common.reference')}</span>
                  <strong>{receipt.ocr.reference}</strong>
                </div>
                <div>
                  <span>{t('common.amount')}</span>
                  <strong>{formatAmount(receipt.ocr.amount)} DZD</strong>
                </div>
                <div>
                  <span>{t('common.date')}</span>
                  <strong>{receipt.ocr.date}</strong>
                </div>
                <div>
                  <span>{t('common.terminal')}</span>
                  <strong>{receipt.ocr.terminal}</strong>
                </div>
                <div className="ocr__wide">
                  <span>{t('prof.shop')}</span>
                  <strong>{receipt.ocr.merchant}</strong>
                </div>
              </div>
            </div>

            <h4 className="checks__title">{t('rec.checks')}</h4>
            <ul className="checks">
              {receipt.checks.map((check) => (
                <li key={check.id} className={check.ok ? 'is-ok' : 'is-bad'}>
                  <span className="checks__icon">
                    <Icon name={check.ok ? 'check' : 'x'} size={13} />
                  </span>
                  <div>
                    <strong>{t(CHECK_LABEL[check.id] ?? 'rec.checks')}</strong>
                    <p>{check.detail}</p>
                  </div>
                  {!check.ok ? <em>{t('rec.detected')}</em> : null}
                </li>
              ))}
            </ul>

            <div className="sheet-actions">
              <Button variant="secondary" icon="bank" onClick={() => tx && navigate(`/app/verify?ref=${tx.reference}`)}>
                {t('rec.verifyLink')}
              </Button>
              <Button icon="refresh" loading={busy} onClick={analyze} disabled={!image}>
                {t('det.recheck')}
              </Button>
            </div>
          </Card>

          <InfoNote icon="shield" tone="danger" title={t('det.disclaimer')}>
            {t('rec.disclaimer')}
          </InfoNote>
        </>
      ) : (
        <EmptyState
          icon="receipt"
          title={t('rec.noImageYet')}
          hint={t('rec.tipBody')}
        />
      )}

      {tx ? (
        <>
          <SectionHeader title={t('rec.resultFor')} />
          <Card className="inline-empty">
            <Icon name="card" size={18} />
            <span>
              {tx.reference} · {formatAmount(tx.amountExpected)} DZD
            </span>
            <Button size="sm" variant="ghost" onClick={() => navigate(`/app/transactions/${tx.id}`)}>
              {t('common.open')}
            </Button>
          </Card>
        </>
      ) : null}

      <Sheet open={fullImage && Boolean(image)} onClose={() => setFullImage(false)} title={t('rec.preview')}>
        {image ? <img src={image} alt={t('rec.preview')} className="full-image" /> : null}
      </Sheet>
    </Screen>
  )
}
