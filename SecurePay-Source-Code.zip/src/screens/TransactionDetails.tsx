import { useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useStore } from '../store'
import {
  Avatar,
  Button,
  Card,
  EmptyState,
  InfoNote,
  KeyValue,
  Money,
  PageHeader,
  Screen,
  SectionHeader,
  Sheet,
  StatusBadge,
} from '../components/ui'
import { Icon } from '../components/icons'
import { METHOD_LABEL, formatDateTime, formatAmount, formatDate } from '../lib/format'
import { detectSignals, riskScore } from '../lib/fraud'
import type { TxStatus } from '../types'

const STATUS_OPTIONS: TxStatus[] = [
  'confirmed',
  'pending',
  'delayed',
  'missing',
  'failed',
  'suspicious',
]

export default function TransactionDetails() {
  const { id } = useParams()
  const navigate = useNavigate()
  const {
    t,
    lang,
    state,
    userById,
    can,
    verifyTransaction,
    updateStatus,
    toggleFlag,
    notify,
  } = useStore()
  const [statusOpen, setStatusOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  const tx = state.transactions.find((x) => x.id === id)
  const all = state.transactions

  const signals = useMemo(
    () => (tx ? detectSignals(tx, all, state.settings) : []),
    [tx, all, state.settings],
  )

  if (!tx) {
    return (
      <Screen>
        <PageHeader title={t('det.title')} />
        <EmptyState icon="search" title={t('det.notFound')} />
      </Screen>
    )
  }

  const employee = userById(tx.employeeId)
  const duplicate = tx.duplicateOf ? all.find((x) => x.id === tx.duplicateOf) : undefined
  const gap = tx.amountExpected - tx.amountConfirmed
  const score = riskScore(tx, all, state.settings)
  const timeline = state.audit.filter((a) => a.detail.includes(tx.reference))

  const runVerify = () => {
    setBusy(true)
    window.setTimeout(() => {
      const record = verifyTransaction(tx.id)
      setBusy(false)
      if (record) {
        notify(
          record.status === 'confirmed'
            ? t('ver.confirmedDesc')
            : record.status === 'not_found'
              ? t('ver.notFoundDesc')
              : record.status === 'failed'
                ? t('ver.failedDesc')
                : record.status === 'mismatch'
                  ? t('ver.mismatchDesc')
                  : t('ver.pendingDesc'),
          record.status === 'confirmed' ? 'success' : 'error',
        )
      } else {
        notify(t('ver.refused'), 'error')
      }
    }, 1100)
  }

  return (
    <Screen>
      <PageHeader
        title={t('det.title')}
        actions={
          <button
            type="button"
            className="icon-btn"
            aria-label={t('common.details')}
            onClick={() => navigate(`/app/receipt?tx=${tx.id}`)}
          >
            <Icon name="receipt" size={20} />
          </button>
        }
      />

      <div className="detail-hero">
        <div className="detail-hero__top">
          <StatusBadge status={tx.status} />
          <span className="detail-hero__score">
            <Icon name="target" size={13} />
            {t('fraud.score')} {score}
          </span>
        </div>
        <Money value={tx.amountExpected} size="xl" strong />
        <p className="detail-hero__ref">
          <Icon name="copy" size={13} /> {tx.reference}
        </p>
        <div className="detail-hero__meta">
          <span>
            <Icon name="card" size={14} /> {METHOD_LABEL[tx.method][lang]}
          </span>
          <span>
            <Icon name="calendar" size={14} /> {formatDateTime(tx.date, lang)}
          </span>
          <span>
            <Icon name="target" size={14} /> {tx.terminal}
          </span>
        </div>
      </div>

      <div className="action-row">
        {can('verifyPayments') ? (
          <Button icon="bank" loading={busy} onClick={runVerify} full>
            {t('det.verifyNow')}
          </Button>
        ) : null}
        <Button variant="secondary" icon="receipt" onClick={() => navigate(`/app/receipt?tx=${tx.id}`)}>
          {t('det.analyze')}
        </Button>
      </div>

      <div className="kpi-grid kpi-grid--3">
        <Card className="kpi kpi--success">
          <span className="kpi__label">{t('det.confirmedAmount')}</span>
          <span className="kpi__value">{formatAmount(tx.amountConfirmed)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
        <Card className="kpi kpi--warn">
          <span className="kpi__label">{t('det.gap')}</span>
          <span className="kpi__value">{formatAmount(gap)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
        <Card className="kpi kpi--blue">
          <span className="kpi__label">{t('fraud.signals')}</span>
          <span className="kpi__value">{signals.length}</span>
          <span className="kpi__cur">/ {t('fraud.score')} {score}</span>
        </Card>
      </div>

      <SectionHeader title={t('det.overview')} />
      <Card className="kv-card">
        <KeyValue label={t('common.customer')} value={tx.customer} />
        <KeyValue label={t('common.method')} value={METHOD_LABEL[tx.method][lang]} />
        <KeyValue label={t('common.terminal')} value={tx.terminal} />
        <KeyValue
          label={t('det.createdBy')}
          value={
            <span className="kv__person">
              <Avatar name={employee?.name ?? '—'} color={employee?.color} size={22} />
              {employee?.name ?? '—'}
            </span>
          }
        />
        <KeyValue label={t('det.createdAt')} value={formatDateTime(tx.createdAt, lang)} />
        <KeyValue label={t('det.updatedAt')} value={formatDateTime(tx.updatedAt, lang)} />
        {tx.notes ? <KeyValue label={t('common.notes')} value={tx.notes} /> : null}
      </Card>

      {duplicate ? (
        <Card tone="danger" className="dup-banner" onClick={() => navigate(`/app/transactions/${duplicate.id}`)}>
          <Icon name="copy" size={18} />
          <div>
            <strong>{t('det.duplicateOf')}</strong>
            <span>
              {duplicate.reference} · {formatDate(duplicate.date, lang)} ·{' '}
              {formatAmount(duplicate.amountExpected)} DZD
            </span>
          </div>
          <Icon name="chevronRight" size={16} />
        </Card>
      ) : null}

      <SectionHeader title={t('det.bank')} />
      <Card className="bank-card">
        <div className="bank-card__head">
          <span className="bank-card__icon">
            <Icon name="bank" size={20} />
          </span>
          <div>
            <strong>{tx.bankMessage ? t('det.bankStatus') : t('ver.simTitle')}</strong>
            <p>
              <span className="badge badge--warn">
                <Icon name="info" size={11} /> {t('det.simBadge')}
              </span>
            </p>
          </div>
        </div>
        {tx.bankCheckedAt ? (
          <>
            <KeyValue
              label={t('det.bankStatus')}
              value={
                tx.status === 'confirmed'
                  ? t('ver.confirmedDesc')
                  : tx.status === 'missing'
                    ? t('ver.notFoundDesc')
                    : tx.status === 'failed'
                      ? t('ver.failedDesc')
                      : t('ver.pendingDesc')
              }
            />
            <KeyValue label={t('det.bankRef')} value={tx.bankRef ?? '—'} />
            <KeyValue label={t('det.settledOn')} value={formatDateTime(tx.bankCheckedAt, lang)} />
            <p className="bank-card__msg">{tx.bankMessage}</p>
          </>
        ) : (
          <p className="muted-pad">{t('det.noBankCheck')}</p>
        )}
      </Card>

      <SectionHeader title={t('det.receipt')} />
      {tx.receipt ? (
        <Card className="receipt-card" onClick={() => navigate(`/app/receipt?tx=${tx.id}`)}>
          <div className="receipt-card__score">
            <span>{tx.receipt.score}</span>
            <em>/100</em>
          </div>
          <div className="receipt-card__info">
            <strong>
              {tx.receipt.verdict === 'clean'
                ? t('rec.verdictClean')
                : tx.receipt.verdict === 'doubtful'
                  ? t('rec.verdictDoubtful')
                  : t('rec.verdictSuspicious')}
            </strong>
            <span>{tx.receipt.fileName}</span>
            <span>{t('det.analysisAt')} {formatDateTime(tx.receipt.analyzedAt, lang)}</span>
          </div>
          <Icon name="chevronRight" size={16} />
        </Card>
      ) : (
        <Card className="inline-empty inline-empty--col">
          <Icon name="receipt" size={20} />
          <span>{t('det.receiptNone')}</span>
          <Button variant="secondary" size="sm" onClick={() => navigate(`/app/receipt?tx=${tx.id}`)}>
            {t('det.analyze')}
          </Button>
        </Card>
      )}
      <InfoNote icon="alertTriangle" tone="warn">
        {t('det.disclaimer')}
      </InfoNote>

      <SectionHeader
        title={t('det.flags')}
        action={can('viewFraud') ? t('det.markStatus') : undefined}
        onAction={can('viewFraud') ? () => setStatusOpen(true) : undefined}
      />
      <Card className="signals-card">
        {signals.length === 0 ? (
          <p className="muted-pad">{t('det.noFlags')}</p>
        ) : (
          <ul className="signals">
            {signals.map((sig) => (
              <li key={sig.id}>
                <span className={`signals__dot signals__dot--${sig.weight >= 35 ? 'high' : sig.weight >= 20 ? 'medium' : 'low'}`} />
                <div>
                  <strong>{t(sig.titleKey)}</strong>
                  <p>{t(sig.bodyKey, sig.params)}</p>
                </div>
                <b>+{sig.weight}</b>
              </li>
            ))}
          </ul>
        )}
        <div className="signals-actions">
          <Button
            variant={tx.flags.includes('suspicious') ? 'ghost' : 'danger'}
            size="sm"
            icon="flag"
            onClick={() => {
              const on = !tx.flags.includes('suspicious')
              toggleFlag(tx.id, 'suspicious', on)
              notify(on ? t('det.suspiciousSet') : t('det.cleared'), on ? 'error' : 'success')
            }}
          >
            {tx.flags.includes('suspicious') ? t('det.clearFlags') : t('det.flagSuspicious')}
          </Button>
          <Button variant="secondary" size="sm" icon="refresh" onClick={() => setStatusOpen(true)}>
            {t('det.markStatus')}
          </Button>
        </div>
      </Card>

      {timeline.length > 0 ? (
        <>
          <SectionHeader title={t('det.timeline')} />
          <Card className="timeline">
            {timeline.slice(0, 6).map((entry) => (
              <div className="timeline__item" key={entry.id}>
                <span className={`timeline__dot timeline__dot--${entry.severity}`} />
                <div>
                  <strong>{entry.action}</strong>
                  <p>{entry.detail}</p>
                  <em>
                    {entry.actorName} · {formatDateTime(entry.at, lang)}
                  </em>
                </div>
              </div>
            ))}
          </Card>
        </>
      ) : null}

      <Sheet open={statusOpen} onClose={() => setStatusOpen(false)} title={t('det.markStatus')}>
        <div className="status-options">
          {STATUS_OPTIONS.map((s) => (
            <button
              key={s}
              type="button"
              className={`status-option ${s === tx.status ? 'is-active' : ''}`}
              onClick={() => {
                updateStatus(tx.id, s)
                setStatusOpen(false)
                notify(t('det.statusUpdated'))
              }}
            >
              <StatusBadge status={s} />
              {s === tx.status ? <Icon name="check" size={16} /> : null}
            </button>
          ))}
        </div>
        <InfoNote icon="info" tone="info">
          {t('add.secureNote')}
        </InfoNote>
      </Sheet>
    </Screen>
  )
}
