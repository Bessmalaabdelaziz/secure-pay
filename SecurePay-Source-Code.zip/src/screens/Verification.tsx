import { useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useStore } from '../store'
import type { BankRecord, Transaction } from '../types'
import {
  AccessDenied,
  Button,
  Card,
  EmptyState,
  Field,
  InfoNote,
  Input,
  KeyValue,
  PageHeader,
  Screen,
  SectionHeader,
  Segmented,
  StatusBadge,
} from '../components/ui'
import { Icon, type IconName } from '../components/icons'
import { formatAmount, formatDateTime } from '../lib/format'

type Tab = 'ref' | 'list'

const RESULT_META: Record<BankRecord['status'], { icon: IconName; tone: 'success' | 'warn' | 'danger'; descKey: string }> = {
  confirmed: { icon: 'checkCircle', tone: 'success', descKey: 'ver.confirmedDesc' },
  pending: { icon: 'clock', tone: 'warn', descKey: 'ver.pendingDesc' },
  failed: { icon: 'xCircle', tone: 'danger', descKey: 'ver.failedDesc' },
  not_found: { icon: 'alertTriangle', tone: 'danger', descKey: 'ver.notFoundDesc' },
  mismatch: { icon: 'alertTriangle', tone: 'warn', descKey: 'ver.mismatchDesc' },
}

export default function Verification() {
  const {
    t,
    lang,
    state,
    can,
    verifyTransaction,
    notify,
  } = useStore()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [tab, setTab] = useState<Tab>('ref')
  const [reference, setReference] = useState(params.get('ref') ?? '')
  const [error, setError] = useState<string | null>(null)
  const [running, setRunning] = useState(false)
  const [step, setStep] = useState(0)
  const [result, setResult] = useState<{ record: BankRecord; txId: string } | null>(null)

  const pending = useMemo(
    () =>
      state.transactions
        .filter((tx) => !tx.bankCheckedAt || ['pending', 'delayed'].includes(tx.status))
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 12),
    [state.transactions],
  )

  if (!can('verifyPayments')) return <AccessDenied />

  const runFor = (tx: Transaction) => {
    setError(null)
    setRunning(true)
    setResult(null)
    setStep(0)
    const iv = window.setInterval(() => {
      setStep((s) => Math.min(3, s + 1))
    }, 420)
    window.setTimeout(() => {
      window.clearInterval(iv)
      setStep(4)
      const record = verifyTransaction(tx.id)
      setRunning(false)
      if (!record) {
        setError(t('ver.refused'))
        return
      }
      setResult({ record, txId: tx.id })
      notify(t('ver.applied'))
    }, 1800)
  }

  const run = () => {
    const ref = reference.trim().toUpperCase()
    const tx = state.transactions.find((x) => x.reference.toUpperCase() === ref)
    if (!tx) {
      setError(t('ver.invalid'))
      setResult(null)
      return
    }
    runFor(tx)
  }

  const meta = result ? RESULT_META[result.record.status] : null
  const resultTx = result ? state.transactions.find((x) => x.id === result.txId) ?? null : null

  return (
    <Screen>
      <PageHeader title={t('ver.title')} subtitle={t('ver.subtitle')} />

      <InfoNote icon="info" tone="warn" title={t('ver.simTitle')}>
        {t('ver.simBody')}
      </InfoNote>

      <Segmented<Tab>
        name={t('ver.title')}
        value={tab}
        onChange={setTab}
        options={[
          { value: 'ref', label: t('ver.byRef') },
          { value: 'list', label: t('ver.byList') },
        ]}
      />

      {tab === 'ref' ? (
        <Card className="form-card">
          <Field label={t('ver.refLabel')} hint={t('add.refHint')} error={error ?? undefined}>
            <Input
              value={reference}
              onChange={(e) => {
                setReference(e.target.value.toUpperCase())
                setError(null)
              }}
              placeholder={t('ver.refPlaceholder')}
              autoCapitalize="characters"
              spellCheck={false}
            />
          </Field>
          <Button full size="lg" icon="bank" loading={running} onClick={run} disabled={!reference.trim()}>
            {running ? t('ver.running') : t('ver.run')}
          </Button>
        </Card>
      ) : null}

      {running ? (
        <Card className="steps-card">
          {[t('ver.step1'), t('ver.step2'), t('ver.step3'), t('ver.step4')].map((label, idx) => (
            <div
              key={label}
              className={`step ${step > idx ? 'is-done' : step === idx ? 'is-active' : ''}`}
            >
              <span className="step__marker">
                {step > idx ? <Icon name="check" size={12} /> : <span />}
              </span>
              <span>{label}</span>
              {step === idx ? <span className="spinner" /> : null}
            </div>
          ))}
        </Card>
      ) : null}

      {result && meta && resultTx ? (
        <Card className={`bank-result bank-result--${meta.tone}`}>
          <div className="bank-result__head">
            <span className={`bank-result__icon bank-result__icon--${meta.tone}`}>
              <Icon name={meta.icon} size={26} />
            </span>
            <div>
              <span className="bank-result__label">{t('ver.result')}</span>
              <strong>{result.record.status === 'confirmed' ? t('status.confirmed') : result.record.status === 'pending' ? t('status.pending') : result.record.status === 'failed' ? t('status.failed') : t('status.missing')}</strong>
            </div>
          </div>
          <p className="bank-result__desc">
            {t(meta.descKey as 'ver.confirmedDesc')}
          </p>
          <div className="bank-result__amounts">
            <div>
              <span>{t('det.expectedAmount')}</span>
              <strong>{formatAmount(resultTx.amountExpected)} DZD</strong>
            </div>
            <div>
              <span>{t('ver.mismatchAmount')}</span>
              <strong className={`text-${meta.tone === 'success' ? 'success' : meta.tone === 'warn' ? 'warn' : 'danger'}`}>
                {formatAmount(result.record.settledAmount)} DZD
              </strong>
            </div>
          </div>
          <div className="kv-card kv-card--flat">
            <KeyValue label={t('common.reference')} value={result.record.reference} />
            <KeyValue label={t('ver.bankName')} value={result.record.issuer} />
            <KeyValue label={t('ver.checkTerminal')} value={result.record.terminal} />
            <KeyValue
              label={t('det.settledOn')}
              value={
                result.record.settlementDate
                  ? formatDateTime(result.record.settlementDate, lang)
                  : t('common.never')
              }
            />
            <KeyValue
              label={t('ver.confidence')}
              value={result.record.status === 'not_found' ? '—' : '98 %'}
            />
          </div>
          <div className="bank-result__status">
            {t('common.status')} : <StatusBadge status={resultTx.status} />
          </div>
          <div className="sheet-actions">
            <Button variant="secondary" onClick={() => navigate(`/app/transactions/${resultTx.id}`)}>
              {t('notif.open')}
            </Button>
            <Button icon="refresh" onClick={() => runFor(resultTx)}>
              {t('det.recheck')}
            </Button>
          </div>
        </Card>
      ) : null}

      {tab === 'list' ? (
        <>
          <SectionHeader title={t('ver.recent')} />
          {pending.length === 0 ? (
            <EmptyState icon="shieldCheck" title={t('ver.noPending')} />
          ) : (
            <div className="verify-list">
              {pending.map((tx) => (
                <Card key={tx.id} className="verify-item">
                  <div className="verify-item__info">
                    <strong>{tx.reference}</strong>
                    <span>
                      {tx.customer} · {formatAmount(tx.amountExpected)} DZD
                    </span>
                    <StatusBadge status={tx.status} />
                  </div>
                  <Button size="sm" icon="scan" onClick={() => runFor(tx)}>
                    {t('ver.run')}
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </>
      ) : null}

      <InfoNote icon="alertTriangle" tone="warn">
        {t('det.disclaimer')}
      </InfoNote>
    </Screen>
  )
}
