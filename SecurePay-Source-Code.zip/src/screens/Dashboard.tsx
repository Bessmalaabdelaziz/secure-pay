import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { computeStats, dailySeries, filterRange } from '../lib/stats'
import { formatAmount, formatDate } from '../lib/format'
import { Icon } from '../components/icons'
import {
  Card,
  IconButton,
  InfoNote,
  Money,
  ProgressBar,
  Screen,
  SectionHeader,
  Segmented,
  StatusBadge,
} from '../components/ui'
import { BarPairChart } from '../components/charts'
import { TransactionRow } from '../components/TransactionRow'
import { AlertRow, useAlertNavigation } from '../components/AlertRow'

type Period = 'today' | 'week' | 'month'

const PERIOD_DAYS: Record<Period, number> = { today: 1, week: 7, month: 30 }

export default function Dashboard() {
  const { t, lang, state, currentUser, can, markAllAlertsRead } = useStore()
  const navigate = useNavigate()
  const openAlert = useAlertNavigation()
  const [period, setPeriod] = useState<Period>('today')

  const scoped = useMemo(() => {
    const mine = can('viewAllTransactions')
      ? state.transactions
      : state.transactions.filter((tx) => tx.employeeId === currentUser?.id)
    return filterRange(mine, PERIOD_DAYS[period])
  }, [state.transactions, can, currentUser?.id, period])

  const allScoped = useMemo(
    () =>
      can('viewAllTransactions')
        ? state.transactions
        : state.transactions.filter((tx) => tx.employeeId === currentUser?.id),
    [state.transactions, can, currentUser?.id],
  )

  const stats = useMemo(() => computeStats(scoped), [scoped])
  const chartPoints = useMemo(
    () => dailySeries(allScoped, period === 'today' ? 7 : PERIOD_DAYS[period]),
    [allScoped, period],
  )

  const alerts = useMemo(
    () =>
      state.alerts
        .filter((a) => !a.resolved)
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [state.alerts],
  )
  const unread = alerts.filter((a) => !a.read).length

  const recent = useMemo(
    () =>
      [...scoped]
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 4),
    [scoped],
  )

  const hour = new Date().getHours()
  const greeting = hour < 12 ? t('dash.morning') : hour < 18 ? t('dash.afternoon') : t('dash.evening')
  const todayLabel = formatDate(new Date().toISOString(), lang)

  return (
    <Screen>
      <header className="dash-head">
        <div>
          <p className="dash-head__hello">
            {greeting}, {currentUser?.name.split(' ')[0]}
          </p>
          <p className="dash-head__shop">
            <Icon name="building" size={13} />
            {currentUser?.shopName} · {todayLabel}
          </p>
        </div>
        <div className="dash-head__actions">
          <IconButton
            icon="globe"
            label={t('common.language')}
            onClick={() => navigate('/app/profile')}
          />
          <IconButton
            icon="bell"
            label={t('notif.title')}
            badge={unread}
            onClick={() => navigate('/app/notifications')}
          />
        </div>
      </header>

      <Segmented<Period>
        name={t('rep.period')}
        value={period}
        onChange={setPeriod}
        options={[
          { value: 'today', label: t('dash.periodToday') },
          { value: 'week', label: t('dash.periodWeek') },
          { value: 'month', label: t('dash.periodMonth') },
        ]}
      />

      <div className="balance-card">
        <div className="balance-card__glow" aria-hidden="true" />
        <div className="balance-card__top">
          <span className="balance-card__label">
            <Icon name="shieldCheck" size={14} />
            {t('dash.balanceLabel')}
          </span>
          <span className="balance-card__badge">{stats.count} {t('tx.count')}</span>
        </div>
        <div className="balance-card__amount">
          <Money value={stats.confirmed} size="xl" strong />
        </div>
        <div className="balance-card__rows">
          <div>
            <span>{t('dash.expected')}</span>
            <strong>{formatAmount(stats.expected)}</strong>
          </div>
          <div>
            <span>{t('dash.gap')}</span>
            <strong className={stats.gap > 0 ? 'text-warn' : 'text-success'}>
              {formatAmount(stats.gap)}
            </strong>
          </div>
        </div>
        <ProgressBar
          value={stats.recoveryRate}
          tone={stats.recoveryRate > 80 ? 'success' : stats.recoveryRate > 55 ? 'warn' : 'danger'}
          label={t('dash.recovery')}
        />
      </div>

      <div className="quick-actions">
        <button
          type="button"
          className="quick-action"
          onClick={() =>
            can('verifyPayments') ? navigate('/app/verify') : navigate('/app/profile')
          }
        >
          <span className="quick-action__icon quick-action__icon--blue">
            <Icon name="bank" size={20} />
          </span>
          <span>{t('dash.verifyCta')}</span>
        </button>
        <button type="button" className="quick-action" onClick={() => navigate('/app/receipt')}>
          <span className="quick-action__icon quick-action__icon--purple">
            <Icon name="scan" size={20} />
          </span>
          <span>{t('rec.title')}</span>
        </button>
        <button
          type="button"
          className="quick-action"
          onClick={() =>
            can('viewReports') ? navigate('/app/reports') : navigate('/app/transactions')
          }
        >
          <span className="quick-action__icon quick-action__icon--green">
            <Icon name="chart" size={20} />
          </span>
          <span>{t('dash.viewReports')}</span>
        </button>
      </div>

      <div className="kpi-grid">
        <Card className="kpi kpi--warn" onClick={() => navigate('/app/transactions?status=pending')}>
          <span className="kpi__icon">
            <Icon name="clock" size={16} />
          </span>
          <span className="kpi__label">{t('dash.pending')}</span>
          <span className="kpi__value">{formatAmount(stats.pending)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
        <Card className="kpi kpi--danger" onClick={() => navigate('/app/transactions?status=missing')}>
          <span className="kpi__icon">
            <Icon name="alertTriangle" size={16} />
          </span>
          <span className="kpi__label">{t('dash.missing')}</span>
          <span className="kpi__value">{formatAmount(stats.missing)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
        <Card className="kpi kpi--danger" onClick={() => navigate('/app/transactions?status=failed')}>
          <span className="kpi__icon">
            <Icon name="xCircle" size={16} />
          </span>
          <span className="kpi__label">{t('dash.failed')}</span>
          <span className="kpi__value">{formatAmount(stats.failed)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
        <Card className="kpi kpi--purple" onClick={() => navigate('/app/fraud')}>
          <span className="kpi__icon">
            <Icon name="shield" size={16} />
          </span>
          <span className="kpi__label">{t('dash.suspicious')}</span>
          <span className="kpi__value">{formatAmount(stats.suspicious)}</span>
          <span className="kpi__cur">DZD</span>
        </Card>
      </div>

      <div className="mini-stats">
        <div>
          <span>{t('dash.avgTicket')}</span>
          <strong>{formatAmount(stats.avgTicket)} DZD</strong>
        </div>
        <div>
          <span>{t('dash.volume')}</span>
          <strong>{stats.count}</strong>
        </div>
        <div>
          <span>{t('dash.toVerify')}</span>
          <strong>
            {scoped.filter((tx) => !tx.bankCheckedAt).length}
          </strong>
        </div>
      </div>

      <Card className="chart-card">
        <div className="chart-card__head">
          <div>
            <h3>{t('dash.chartTitle')}</h3>
            <p>{t('dash.chartHint')}</p>
          </div>
          <span className="chart-card__pill">
            <Icon name="trendUp" size={13} />
            {Math.round(stats.recoveryRate)}%
          </span>
        </div>
        <BarPairChart points={chartPoints} lang={lang} />
      </Card>

      <SectionHeader
        title={t('dash.alerts')}
        action={t('common.viewAll')}
        onAction={() => {
          markAllAlertsRead()
          navigate('/app/notifications')
        }}
      />
      <div className="alert-list">
        {alerts.slice(0, 3).map((alert) => (
          <AlertRow key={alert.id} alert={alert} onOpen={() => openAlert(alert)} />
        ))}
        {alerts.length === 0 ? (
          <Card className="inline-empty">
            <Icon name="shieldCheck" size={18} />
            <span>{t('fraud.emptyHint')}</span>
          </Card>
        ) : null}
      </div>

      <SectionHeader
        title={t('dash.recent')}
        action={t('common.viewAll')}
        onAction={() => navigate('/app/transactions')}
      />
      <Card className="list-card">
        {recent.map((tx, idx) => (
          <div key={tx.id} className={idx > 0 ? 'list-card__item list-card__item--sep' : 'list-card__item'}>
            <TransactionRow tx={tx} showEmployee={can('viewAllTransactions')} />
          </div>
        ))}
        {recent.length === 0 ? <p className="muted-pad">{t('dash.noRecent')}</p> : null}
      </Card>

      <InfoNote icon="info" tone="warn" title={t('common.simulation')}>
        {t('dash.secureNote')}
      </InfoNote>

      <div className="status-legend">
        {(['confirmed', 'pending', 'failed', 'missing', 'suspicious'] as const).map((s) => (
          <StatusBadge key={s} status={s} />
        ))}
      </div>
    </Screen>
  )
}
