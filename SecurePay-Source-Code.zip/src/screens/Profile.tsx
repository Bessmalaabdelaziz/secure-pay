import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import {
  Avatar,
  Badge,
  Button,
  Card,
  Field,
  InfoNote,
  Input,
  PageHeader,
  Screen,
  SectionHeader,
  Segmented,
  Sheet,
  Toggle,
} from '../components/ui'
import { Icon, type IconName } from '../components/icons'
import { formatDate, formatAmount } from '../lib/format'
import type { Lang } from '../types'
import type { TranslationKey } from '../i18n'

const PERMISSION_LABELS: { key: keyof NonNullable<ReturnType<typeof useStore>['currentUser']>['permissions']; label: TranslationKey }[] = [
  { key: 'addTransaction', label: 'emp.permAdd' },
  { key: 'viewAllTransactions', label: 'emp.permViewAll' },
  { key: 'viewReports', label: 'emp.permReports' },
  { key: 'viewFraud', label: 'emp.permFraud' },
  { key: 'verifyPayments', label: 'emp.permVerify' },
  { key: 'manageEmployees', label: 'emp.permManage' },
]

function Row({
  icon,
  label,
  value,
  onClick,
  tone,
}: {
  icon: IconName
  label: string
  value?: string
  onClick?: () => void
  tone?: 'danger'
}) {
  const Tag = onClick ? 'button' : 'div'
  return (
    <Tag type="button" className={`setting-row ${tone === 'danger' ? 'setting-row--danger' : ''}`.trim()} onClick={onClick}>
      <span className="setting-row__icon">
        <Icon name={icon} size={17} />
      </span>
      <span className="setting-row__label">{label}</span>
      {value ? <span className="setting-row__value">{value}</span> : null}
      {onClick ? <Icon name="chevronRight" size={15} /> : null}
    </Tag>
  )
}

export default function Profile() {
  const {
    t,
    lang,
    state,
    currentUser,
    setSettings,
    updateProfile,
    changePassword,
    resetDemo,
    logout,
    notify,
  } = useStore()
  const navigate = useNavigate()

  const [editOpen, setEditOpen] = useState(false)
  const [pwdOpen, setPwdOpen] = useState(false)
  const [logoutOpen, setLogoutOpen] = useState(false)
  const [form, setForm] = useState({
    name: currentUser?.name ?? '',
    email: currentUser?.email ?? '',
    phone: currentUser?.phone ?? '',
    shopName: currentUser?.shopName ?? '',
  })
  const [pwd, setPwd] = useState({ current: '', next: '', confirm: '' })
  const [pwdError, setPwdError] = useState<string | null>(null)
  const [threshold, setThreshold] = useState(String(state.settings.highValueThreshold))

  if (!currentUser) return null
  const isOwner = currentUser.role === 'owner'

  const saveProfile = () => {
    if (!form.name.trim() || !form.email.trim()) return
    updateProfile({
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      shopName: form.shopName.trim(),
    })
    setEditOpen(false)
    notify(t('prof.savedProfile'))
  }

  const submitPassword = async () => {
    setPwdError(null)
    if (pwd.next !== pwd.confirm) {
      setPwdError(t('prof.passwordMismatch'))
      return
    }
    if (pwd.next.length < 6) {
      setPwdError(t('auth.passwordShort'))
      return
    }
    const result = await changePassword(pwd.current, pwd.next)
    if (result === 'wrong') {
      setPwdError(t('prof.wrongPassword'))
      return
    }
    if (result === 'short') {
      setPwdError(t('auth.passwordShort'))
      return
    }
    setPwd({ current: '', next: '', confirm: '' })
    setPwdOpen(false)
    notify(t('prof.passwordChanged'))
  }

  return (
    <Screen>
      <PageHeader title={t('prof.title')} subtitle={currentUser.shopName} />

      <Card className="profile-card">
        <Avatar name={currentUser.name} color={currentUser.color} size={62} />
        <div className="profile-card__info">
          <strong>{currentUser.name}</strong>
          <span>{currentUser.email}</span>
          <div className="profile-card__badges">
            <Badge tone={isOwner ? 'info' : 'success'} icon={isOwner ? 'shieldCheck' : 'user'}>
              {isOwner ? t('prof.roleOwner') : t('prof.roleEmployee')}
            </Badge>
          </div>
        </div>
        <button type="button" className="icon-btn" onClick={() => setEditOpen(true)} aria-label={t('prof.edit')}>
          <Icon name="edit" size={17} />
        </button>
      </Card>

      <div className="mini-stats mini-stats--3">
        <div>
          <span>{t('prof.memberSince')}</span>
          <strong>{formatDate(currentUser.createdAt, lang).replace(/\s\d{4}$/, '')}</strong>
        </div>
        <div>
          <span>{t('prof.shop')}</span>
          <strong>{currentUser.shopName.split(' ')[0]}</strong>
        </div>
        <div>
          <span>{t('prof.threshold')}</span>
          <strong>{formatAmount(state.settings.highValueThreshold)}</strong>
        </div>
      </div>

      <SectionHeader title={t('prof.account')} />
      <Card className="settings-card">
        <Row icon="user" label={t('auth.name')} value={currentUser.name} onClick={() => setEditOpen(true)} />
        <Row icon="mail" label={t('prof.email')} value={currentUser.email} onClick={() => setEditOpen(true)} />
        <Row icon="phone" label={t('prof.phone')} value={currentUser.phone || '—'} onClick={() => setEditOpen(true)} />
        <Row icon="building" label={t('prof.shopName')} value={currentUser.shopName} onClick={() => setEditOpen(true)} />
      </Card>

      <SectionHeader title={t('prof.permissions')} />
      <Card className="padded">
        <div className="emp-card__perms">
          {PERMISSION_LABELS.filter((p) => currentUser.permissions[p.key]).map((p) => (
            <span className="mini-chip mini-chip--ok" key={p.key}>
              <Icon name="check" size={11} /> {t(p.label)}
            </span>
          ))}
        </div>
      </Card>

      <SectionHeader title={t('prof.security')} />
      <Card className="settings-card">
        <Row icon="key" label={t('prof.changePassword')} onClick={() => setPwdOpen(true)} />
        <Toggle
          label={t('prof.twoFactor')}
          description={t('prof.twoFactorDesc')}
          checked={state.settings.twoFactor}
          onChange={(v) => setSettings({ twoFactor: v })}
        />
        <Toggle
          label={t('prof.biometric')}
          description={t('prof.biometricDesc')}
          checked={state.settings.biometric}
          onChange={(v) => setSettings({ biometric: v })}
        />
        <Toggle
          label={t('prof.notifications')}
          description={t('prof.notifDesc')}
          checked={state.settings.notificationsEnabled}
          onChange={(v) => setSettings({ notificationsEnabled: v })}
        />
      </Card>

      <SectionHeader title={t('prof.language')} />
      <Card className="padded">
        <Segmented<Lang>
          name={t('prof.language')}
          value={lang}
          onChange={(value) => setSettings({ lang: value })}
          options={[
            { value: 'fr', label: t('common.french') },
            { value: 'ar', label: t('common.arabic') },
          ]}
        />
        <p className="muted-pad">{lang === 'ar' ? 'RTL · العربية' : 'FR · Français'} · DZD</p>
      </Card>

      {isOwner ? (
        <>
          <SectionHeader title={t('prof.threshold')} />
          <Card className="padded">
            <Field label={t('prof.threshold')} hint={t('prof.thresholdDesc')}>
              <div className="input-affix input-affix--money">
                <Input
                  inputMode="numeric"
                  value={threshold}
                  onChange={(e) => setThreshold(e.target.value.replace(/[^\d]/g, ''))}
                  onBlur={() => {
                    const value = Number(threshold)
                    if (value >= 1000) {
                      setSettings({ highValueThreshold: value })
                      notify(t('common.saved'))
                    } else {
                      setThreshold(String(state.settings.highValueThreshold))
                    }
                  }}
                />
                <span>DZD</span>
              </div>
            </Field>
          </Card>

          <SectionHeader title={t('prof.shop')} />
          <Card className="settings-card">
            <Row icon="users" label={t('emp.title')} value={String(state.users.filter((u) => u.role === 'employee').length)} onClick={() => navigate('/app/employees')} />
            <Row icon="chart" label={t('rep.title')} onClick={() => navigate('/app/reports')} />
            <Row icon="shield" label={t('emp.audit')} onClick={() => navigate('/app/audit')} />
          </Card>
        </>
      ) : (
        <>
          <SectionHeader title={t('prof.session')} />
          <Card className="settings-card">
            <Row icon="shield" label={t('emp.audit')} onClick={() => navigate('/app/audit')} />
          </Card>
        </>
      )}

      <SectionHeader title={t('prof.about')} />
      <Card className="settings-card">
        <Row icon="info" label={t('prof.version')} value="1.0.0 (prototype)" />
        <Row icon="lock" label={t('prof.privacy')} value="" />
        <Row icon="refresh" label={t('prof.resetData')} onClick={() => {
          void resetDemo().then(() => notify(t('prof.resetDone')))
        }} />
        <Row icon="globe" label={t('common.language')} value={lang === 'fr' ? 'Français' : 'العربية'} onClick={() => setSettings({ lang: lang === 'fr' ? 'ar' : 'fr' })} />
      </Card>

      <InfoNote icon="shieldCheck" tone="info" title={t('prof.privacy')}>
        {t('prof.privacyDesc')} {t('prof.appInfo')}
      </InfoNote>

      <Button variant="danger" full icon="logout" onClick={() => setLogoutOpen(true)}>
        {t('common.logout')}
      </Button>

      <Sheet
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title={t('prof.edit')}
        footer={<Button full icon="check" onClick={saveProfile}>{t('common.save')}</Button>}
      >
        <div className="stack">
          <Field label={t('auth.name')}>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label={t('prof.email')}>
            <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </Field>
          <Field label={t('prof.phone')} optional={t('common.optional')}>
            <Input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          </Field>
          <Field label={t('prof.shopName')}>
            <Input value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} />
          </Field>
        </div>
      </Sheet>

      <Sheet
        open={pwdOpen}
        onClose={() => setPwdOpen(false)}
        title={t('prof.changePassword')}
        footer={<Button full icon="lock" onClick={() => void submitPassword()}>{t('common.save')}</Button>}
      >
        <div className="stack">
          <Field label={t('prof.current')}>
            <Input type="password" value={pwd.current} onChange={(e) => setPwd({ ...pwd, current: e.target.value })} />
          </Field>
          <Field label={t('prof.new')}>
            <Input type="password" value={pwd.next} onChange={(e) => setPwd({ ...pwd, next: e.target.value })} />
          </Field>
          <Field label={t('prof.confirmPwd')} error={pwdError ?? undefined}>
            <Input type="password" value={pwd.confirm} onChange={(e) => setPwd({ ...pwd, confirm: e.target.value })} />
          </Field>
          {pwdError ? <p className="form-error">{pwdError}</p> : null}
          <InfoNote icon="key" tone="info">
            {t('prof.twoFactorDesc')}
          </InfoNote>
        </div>
      </Sheet>

      <Sheet
        open={logoutOpen}
        onClose={() => setLogoutOpen(false)}
        title={t('prof.logoutConfirm')}
        footer={
          <div className="sheet-actions">
            <Button variant="ghost" onClick={() => setLogoutOpen(false)}>{t('common.cancel')}</Button>
            <Button variant="danger" icon="logout" onClick={() => {
              setLogoutOpen(false)
              logout()
              navigate('/auth', { replace: true })
            }}>
              {t('common.logout')}
            </Button>
          </div>
        }
      >
        <InfoNote icon="info" tone="info">
          {t('auth.protected')}
        </InfoNote>
      </Sheet>
    </Screen>
  )
}
