import { useEffect, useMemo, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { useStore } from '../store'
import type { PaymentMethod, TxStatus } from '../types'
import { METHOD_LABEL, formatAmount, formatDate } from '../lib/format'
import { computeStats } from '../lib/stats'
import { Icon } from '../components/icons'
import {
  Button,
  Card,
  Chip,
  EmptyState,
  InfoNote,
  Screen,
  Select,
  Sheet,
} from '../components/ui'
import { TransactionRow } from '../components/TransactionRow'

type Sort = 'newest' | 'amount' | 'status'

const STATUSES: TxStatus[] = [
  'confirmed',
  'pending',
  'delayed',
  'missing',
  'failed',
  'suspicious',
]

export default function Transactions() {
  const { t, lang, state, currentUser, can, employeeName } = useStore()
  const navigate = useNavigate()
  const [params] = useSearchParams()
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<Sort>('newest')
  const [method, setMethod] = useState<PaymentMethod | 'all'>('all')
  const [filtersOpen, setFiltersOpen] = useState(false)
  const [status, setStatus] = useState<TxStatus | 'all'>(
    (params.get('status') as TxStatus | null) ?? 'all',
  )

  useEffect(() => {
    const s = params.get('status')
    if (s) setStatus(s as TxStatus)
  }, [params])

  const scoped = useMemo(
    () =>
      can('viewAllTransactions')
        ? state.transactions
        : state.transactions.filter((tx) => tx.employeeId === currentUser?.id),
    [state.transactions, can, currentUser?.id],
  )

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    let list = scoped
    if (status !== 'all') list = list.filter((tx) => tx.status === status)
    if (method !== 'all') list = list.filter((tx) => tx.method === method)
    if (q) {
      list = list.filter(
        (tx) =>
          tx.reference.toLowerCase().includes(q) ||
          tx.customer.toLowerCase().includes(q) ||
          tx.terminal.toLowerCase().includes(q) ||
          employeeName(tx.employeeId).toLowerCase().includes(q) ||
          String(tx.amountExpected).includes(q),
      )
    }
    const sorted = [...list]
    if (sort === 'newest') {
      sorted.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    } else if (sort === 'amount') {
      sorted.sort((a, b) => b.amountExpected - a.amountExpected)
    } else {
      const order: Record<TxStatus, number> = {
        suspicious: 0,
        missing: 1,
        failed: 2,
        delayed: 3,
        pending: 4,
        confirmed: 5,
      }
      sorted.sort((a, b) => order[a.status] - order[b.status])
    }
    return sorted
  }, [scoped, status, method, query, sort, employeeName])

  const stats = useMemo(() => computeStats(filtered), [filtered])

  const groups = useMemo(() => {
    const map: { key: string; label: string; items: typeof filtered }[] = []
    for (const tx of filtered) {
      const key = new Date(tx.date).toDateString()
      const last = map[map.length - 1]
      if (last && last.key === key) last.items.push(tx)
      else map.push({ key, label: formatDate(tx.date, lang), items: [tx] })
    }
    return map
  }, [filtered, lang])

  const activeFilters =
    (status !== 'all' ? 1 : 0) + (method !== 'all' ? 1 : 0) + (sort !== 'newest' ? 1 : 0)

  return (
    <Screen>
      <header className="stack-head">
        <div>
          <h1>{t('tx.title')}</h1>
          <p>
            {filtered.length} {t('tx.count')} · {formatAmount(stats.expected)} DZD
          </p>
        </div>
        <button
          type="button"
          className="icon-btn"
          aria-label={t('tx.addNew')}
          onClick={() => navigate('/app/transactions/new')}
        >
          <Icon name="plus" size={20} />
        </button>
      </header>

      {!can('viewAllTransactions') ? (
        <InfoNote icon="lock" tone="info">
          {t('tx.employeeNotice')}
        </InfoNote>
      ) : null}

      <div className="searchbar">
        <Icon name="search" size={18} />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={t('tx.searchPlaceholder')}
          aria-label={t('common.search')}
        />
        {query ? (
          <button type="button" onClick={() => setQuery('')} aria-label={t('common.cancel')}>
            <Icon name="x" size={16} />
          </button>
        ) : null}
      </div>

      <div className="chips-row">
        <Chip active={status === 'all'} onClick={() => setStatus('all')}>
          {t('common.all')}
        </Chip>
        {STATUSES.map((s) => (
          <Chip key={s} active={status === s} onClick={() => setStatus(s)}>
            {t(`status.${s}` as 'status.confirmed')}
          </Chip>
        ))}
        <button type="button" className="chips-row__filter" onClick={() => setFiltersOpen(true)}>
          <Icon name="filter" size={15} />
          {activeFilters > 0 ? <span>{activeFilters}</span> : null}
        </button>
      </div>

      <div className="list-summary">
        <span>{t('rep.kpiConfirmed')}</span>
        <strong>{formatAmount(stats.confirmed)} DZD</strong>
      </div>

      {groups.length === 0 ? (
        <EmptyState
          icon="list"
          title={t('tx.empty')}
          hint={t('tx.emptyHint')}
          action={
            <Button variant="secondary" icon="refresh" onClick={() => {
              setQuery('')
              setStatus('all')
              setMethod('all')
              setSort('newest')
            }}>
              {t('tx.resetFilters')}
            </Button>
          }
        />
      ) : (
        <div className="tx-groups">
          {groups.map((group) => (
            <section key={group.key} className="tx-group">
              <h3 className="tx-group__label">{group.label}</h3>
              <Card className="list-card">
                {group.items.map((tx, idx) => (
                  <div
                    key={tx.id}
                    className={idx > 0 ? 'list-card__item list-card__item--sep' : 'list-card__item'}
                  >
                    <TransactionRow tx={tx} showEmployee={can('viewAllTransactions')} />
                  </div>
                ))}
              </Card>
            </section>
          ))}
        </div>
      )}

      <Sheet
        open={filtersOpen}
        onClose={() => setFiltersOpen(false)}
        title={t('common.filters')}
        footer={
          <div className="sheet-actions">
            <Button
              variant="ghost"
              onClick={() => {
                setMethod('all')
                setSort('newest')
                setStatus('all')
              }}
            >
              {t('common.reset')}
            </Button>
            <Button onClick={() => setFiltersOpen(false)}>{t('common.apply')}</Button>
          </div>
        }
      >
        <div className="stack">
          <label className="field">
            <span className="field__label">{t('tx.filterMethod')}</span>
            <Select
              value={method}
              onChange={(e) => setMethod(e.target.value as PaymentMethod | 'all')}
            >
              <option value="all">{t('common.all')}</option>
              {(Object.keys(METHOD_LABEL) as PaymentMethod[]).map((m) => (
                <option key={m} value={m}>
                  {METHOD_LABEL[m][lang]}
                </option>
              ))}
            </Select>
          </label>
          <label className="field">
            <span className="field__label">{t('common.status')}</span>
            <Select value={status} onChange={(e) => setStatus(e.target.value as TxStatus | 'all')}>
              <option value="all">{t('common.all')}</option>
              {STATUSES.map((s) => (
                <option key={s} value={s}>
                  {t(`status.${s}` as 'status.confirmed')}
                </option>
              ))}
            </Select>
          </label>
          <label className="field">
            <span className="field__label">Tri</span>
            <Select value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
              <option value="newest">{t('tx.sortNewest')}</option>
              <option value="amount">{t('tx.sortAmount')}</option>
              <option value="status">{t('tx.sortStatus')}</option>
            </Select>
          </label>
        </div>
      </Sheet>
    </Screen>
  )
}
