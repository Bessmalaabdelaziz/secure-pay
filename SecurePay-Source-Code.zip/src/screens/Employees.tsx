import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import type { Permissions, User } from '../types'
import {
  AccessDenied,
  Avatar,
  Badge,
  Button,
  Card,
  EmptyState,
  Field,
  InfoNote,
  Input,
  PageHeader,
  Screen,
  SectionHeader,
  Sheet,
  Toggle,
} from '../components/ui'
import { Icon } from '../components/icons'
import { formatAmount } from '../lib/format'
import type { TranslationKey } from '../i18n'

const PERMISSION_ENTRIES: { key: keyof Permissions; label: TranslationKey }[] = [
  { key: 'addTransaction', label: 'emp.permAdd' },
  { key: 'viewAllTransactions', label: 'emp.permViewAll' },
  { key: 'viewReports', label: 'emp.permReports' },
  { key: 'viewFraud', label: 'emp.permFraud' },
  { key: 'verifyPayments', label: 'emp.permVerify' },
  { key: 'manageEmployees', label: 'emp.permManage' },
]

const DEFAULT_PERMS: Permissions = {
  addTransaction: true,
  viewAllTransactions: false,
  viewReports: false,
  viewFraud: false,
  verifyPayments: false,
  manageEmployees: false,
}

export default function Employees() {
  const { t, can, employees, state, addEmployee, updateEmployee, removeEmployee, notify } =
    useStore()
  const navigate = useNavigate()

  const [addOpen, setAddOpen] = useState(false)
  const [editing, setEditing] = useState<User | null>(null)
  const [createdPwd, setCreatedPwd] = useState<{ name: string; password: string } | null>(null)
  const [form, setForm] = useState({ name: '', email: '', phone: '', permissions: DEFAULT_PERMS })
  const [error, setError] = useState<TranslationKey | null>(null)
  const [confirmDelete, setConfirmDelete] = useState(false)

  const stats = useMemo(() => {
    const map: Record<string, { count: number; confirmed: number }> = {}
    for (const tx of state.transactions) {
      const cur = map[tx.employeeId] ?? { count: 0, confirmed: 0 }
      cur.count += 1
      cur.confirmed += Math.min(tx.amountConfirmed, tx.amountExpected)
      map[tx.employeeId] = cur
    }
    return map
  }, [state.transactions])

  if (!can('manageEmployees')) return <AccessDenied />

  const openAdd = () => {
    setForm({ name: '', email: '', phone: '', permissions: DEFAULT_PERMS })
    setError(null)
    setAddOpen(true)
  }

  const submitAdd = () => {
    const result = addEmployee({
      name: form.name,
      email: form.email,
      phone: form.phone,
      permissions: form.permissions,
    })
    if (!result.ok) {
      setError(result.error ?? 'common.error')
      return
    }
    setAddOpen(false)
    setCreatedPwd({ name: form.name, password: result.password ?? '—' })
    notify(t('emp.created'))
  }

  return (
    <Screen>
      <PageHeader
        title={t('emp.title')}
        subtitle={t('emp.subtitle')}
        actions={
          <button type="button" className="icon-btn" aria-label={t('emp.add')} onClick={openAdd}>
            <Icon name="plus" size={20} />
          </button>
        }
      />

      <div className="mini-stats mini-stats--3">
        <div>
          <span>{t('emp.title')}</span>
          <strong>{employees.length}</strong>
        </div>
        <div>
          <span>{t('emp.active')}</span>
          <strong>{employees.filter((e) => e.active).length}</strong>
        </div>
        <div>
          <span>{t('emp.inactive')}</span>
          <strong>{employees.filter((e) => !e.active).length}</strong>
        </div>
      </div>

      {employees.length === 0 ? (
        <EmptyState icon="users" title={t('emp.noEmployees')} action={<Button icon="plus" onClick={openAdd}>{t('emp.add')}</Button>} />
      ) : (
        <div className="stack">
          {employees.map((emp) => {
            const s = stats[emp.id] ?? { count: 0, confirmed: 0 }
            return (
              <Card key={emp.id} className="emp-card">
                <div className="emp-card__head">
                  <Avatar name={emp.name} color={emp.color} size={44} />
                  <div className="emp-card__id">
                    <strong>{emp.name}</strong>
                    <span>{emp.email}</span>
                    <span>{emp.phone || '—'}</span>
                  </div>
                  <Badge tone={emp.active ? 'success' : 'danger'}>
                    {emp.active ? t('emp.active') : t('emp.inactive')}
                  </Badge>
                </div>
                <p className="emp-card__stats">
                  {t('emp.stats', {
                    count: s.count,
                    amount: formatAmount(s.confirmed),
                  })}
                </p>
                <div className="emp-card__perms">
                  {PERMISSION_ENTRIES.filter((p) => emp.permissions[p.key]).map((p) => (
                    <span className="mini-chip" key={p.key}>
                      {t(p.label)}
                    </span>
                  ))}
                  {PERMISSION_ENTRIES.every((p) => !emp.permissions[p.key]) ? (
                    <span className="mini-chip">{t('prof.noPermission')}</span>
                  ) : null}
                </div>
                <div className="emp-card__actions">
                  <Button size="sm" variant="secondary" icon="edit" onClick={() => { setEditing(emp); setConfirmDelete(false) }}>
                    {t('common.edit')}
                  </Button>
                  <Button
                    size="sm"
                    variant={emp.active ? 'ghost' : 'success'}
                    icon={emp.active ? 'pause' : 'check'}
                    onClick={() => {
                      updateEmployee(emp.id, { active: !emp.active })
                      notify(t('emp.updated'))
                    }}
                  >
                    {emp.active ? t('emp.deactivate') : t('emp.activate')}
                  </Button>
                </div>
              </Card>
            )
          })}
        </div>
      )}

      <SectionHeader title={t('emp.audit')} />
      <Card className="inline-empty" onClick={() => navigate('/app/audit')}>
        <Icon name="shield" size={18} />
        <span>{t('emp.auditHint')}</span>
        <Icon name="chevronRight" size={16} />
      </Card>

      <InfoNote icon="lock" tone="info">
        {t('add.secureNote')}
      </InfoNote>

      <Sheet
        open={addOpen}
        onClose={() => setAddOpen(false)}
        title={t('emp.addTitle')}
        footer={
          <div className="sheet-actions">
            <Button variant="ghost" onClick={() => setAddOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button icon="check" onClick={submitAdd}>
              {t('common.add')}
            </Button>
          </div>
        }
      >
        <div className="stack">
          <Field label={t('emp.name')}>
            <Input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Karim Haddad"
            />
          </Field>
          <Field label={t('emp.email')}>
            <Input
              type="email"
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="employe@commerce.dz"
            />
          </Field>
          <Field label={t('emp.phone')} optional={t('common.optional')}>
            <Input
              type="tel"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="0660 00 00 00"
            />
          </Field>
          <div className="perm-list">
            <span className="field__label">{t('emp.permissions')}</span>
            {PERMISSION_ENTRIES.map((p) => (
              <Toggle
                key={p.key}
                label={t(p.label)}
                checked={form.permissions[p.key]}
                onChange={(v) =>
                  setForm({
                    ...form,
                    permissions: { ...form.permissions, [p.key]: v },
                  })
                }
              />
            ))}
          </div>
          {error ? <p className="form-error">{t(error)}</p> : null}
        </div>
      </Sheet>

      <Sheet open={Boolean(editing)} onClose={() => setEditing(null)} title={editing?.name ?? ''}>
        {editing ? (
          <div className="stack">
            <div className="emp-card__head">
              <Avatar name={editing.name} color={editing.color} size={44} />
              <div className="emp-card__id">
                <strong>{editing.name}</strong>
                <span>{editing.email}</span>
              </div>
            </div>
            <div className="perm-list">
              <span className="field__label">{t('emp.permissions')}</span>
              {PERMISSION_ENTRIES.map((p) => (
                <Toggle
                  key={p.key}
                  label={t(p.label)}
                  checked={editing.permissions[p.key]}
                  onChange={(v) => {
                    const permissions = { ...editing.permissions, [p.key]: v }
                    setEditing({ ...editing, permissions })
                    updateEmployee(editing.id, { permissions })
                  }}
                />
              ))}
            </div>
            <Toggle
              label={t('emp.active')}
              checked={editing.active}
              onChange={(v) => {
                setEditing({ ...editing, active: v })
                updateEmployee(editing.id, { active: v })
              }}
            />
            <Button
              variant="danger"
              icon="trash"
              onClick={() => {
                if (!confirmDelete) {
                  setConfirmDelete(true)
                  return
                }
                removeEmployee(editing.id)
                setEditing(null)
                notify(t('emp.updated'))
              }}
            >
              {confirmDelete ? t('emp.deleteTitle') : t('common.delete')}
            </Button>
            {confirmDelete ? <p className="muted-pad">{t('emp.deleteBody')}</p> : null}
          </div>
        ) : null}
      </Sheet>

      <Sheet
        open={Boolean(createdPwd)}
        onClose={() => setCreatedPwd(null)}
        title={t('emp.created')}
        footer={<Button full onClick={() => setCreatedPwd(null)}>{t('common.understand')}</Button>}
      >
        {createdPwd ? (
          <div className="stack">
            <InfoNote icon="key" tone="success">
              {t('emp.tempPassword')}
            </InfoNote>
            <div className="pwd-box">
              <span>{createdPwd.name}</span>
              <strong>{createdPwd.password}</strong>
            </div>
            <p className="muted-pad">{t('auth.secureNote')}</p>
          </div>
        ) : null}
      </Sheet>
    </Screen>
  )
}
