import { useMemo, useState } from 'react'
import { useStore } from '../store'
import { Avatar, Badge, Card, Chip, EmptyState, PageHeader, Screen } from '../components/ui'
import { formatDateTime } from '../lib/format'
import type { Severity } from '../types'

export default function AuditLog() {
  const { t, lang, state, currentUser } = useStore()
  const [filter, setFilter] = useState<Severity | 'all'>('all')

  const entries = useMemo(() => {
    const isOwner = currentUser?.role === 'owner'
    return state.audit
      .filter((entry) => (isOwner ? true : entry.actorId === currentUser?.id))
      .filter((entry) => (filter === 'all' ? true : entry.severity === filter))
      .slice(0, 100)
  }, [state.audit, currentUser, filter])

  return (
    <Screen>
      <PageHeader title={t('emp.audit')} subtitle={t('emp.auditHint')} />

      <div className="chips-row">
        <Chip active={filter === 'all'} onClick={() => setFilter('all')}>
          {t('common.all')}
        </Chip>
        <Chip active={filter === 'high'} onClick={() => setFilter('high')}>
          {t('notif.severityHigh')}
        </Chip>
        <Chip active={filter === 'medium'} onClick={() => setFilter('medium')}>
          {t('notif.severityMedium')}
        </Chip>
        <Chip active={filter === 'low'} onClick={() => setFilter('low')}>
          {t('notif.severityLow')}
        </Chip>
      </div>

      {entries.length === 0 ? (
        <EmptyState icon="shield" title={t('audit.empty')} />
      ) : (
        <Card className="audit">
          {entries.map((entry) => (
            <div className="audit__item" key={entry.id}>
              <Avatar name={entry.actorName} size={34} />
              <div className="audit__body">
                <div className="audit__head">
                  <strong>{entry.action}</strong>
                  <Badge
                    tone={
                      entry.severity === 'high'
                        ? 'danger'
                        : entry.severity === 'medium'
                          ? 'warn'
                          : 'neutral'
                    }
                  >
                    {entry.severity === 'high'
                      ? t('notif.severityHigh')
                      : entry.severity === 'medium'
                        ? t('notif.severityMedium')
                        : t('notif.severityLow')}
                  </Badge>
                </div>
                <p>{entry.detail}</p>
                <em>
                  {entry.actorName} · {formatDateTime(entry.at, lang)}
                </em>
              </div>
            </div>
          ))}
        </Card>
      )}
    </Screen>
  )
}
