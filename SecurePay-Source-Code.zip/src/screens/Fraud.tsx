import { useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { detectSignals, riskScore } from '../lib/fraud'
import { formatAmount } from '../lib/format'
import {
  AccessDenied,
  Button,
  Card,
  EmptyState,
  InfoNote,
  PageHeader,
  Screen,
  SectionHeader,
} from '../components/ui'
import { Icon, type IconName } from '../components/icons'
import type { TranslationKey } from '../i18n'

const RULES: { icon: IconName; title: TranslationKey; desc: TranslationKey }[] = [
  { icon: 'copy', title: 'fraud.ruleDuplicate', desc: 'fraud.ruleDuplicateDesc' },
  { icon: 'alertTriangle', title: 'fraud.ruleMismatch', desc: 'fraud.ruleMismatchDesc' },
  { icon: 'trendUp', title: 'fraud.ruleHighValue', desc: 'fraud.ruleHighValueDesc' },
  { icon: 'clock', title: 'fraud.ruleOffHours', desc: 'fraud.ruleOffHoursDesc' },
  { icon: 'zap', title: 'fraud.ruleRapid', desc: 'fraud.ruleRapidDesc' },
  { icon: 'receipt', title: 'fraud.ruleReceipt', desc: 'fraud.ruleReceiptDesc' },
  { icon: 'bank', title: 'fraud.ruleMissing', desc: 'fraud.ruleMissingDesc' },
]

export default function Fraud() {
  const { t, can, state, notify, resolveAlert } = useStore()
  const navigate = useNavigate()

  const flagged = useMemo(() => {
    return state.transactions
      .map((tx) => ({
        tx,
        score: riskScore(tx, state.transactions, state.settings),
        signals: detectSignals(tx, state.transactions, state.settings),
      }))
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score)
  }, [state.transactions, state.settings])

  const atRisk = flagged.reduce(
    (sum, item) => sum + Math.max(0, item.tx.amountExpected - item.tx.amountConfirmed),
    0,
  )
  const resolved = state.alerts.filter((a) => a.resolved).length

  if (!can('viewFraud')) return <AccessDenied />

  return (
    <Screen>
      <PageHeader title={t('fraud.title')} subtitle={t('fraud.subtitle')} />

      <div className="fraud-hero">
        <div>
          <span>{t('fraud.totalAtRisk')}</span>
          <strong>{formatAmount(atRisk)} DZD</strong>
        </div>
        <div className="fraud-hero__stats">
          <div>
            <span>{t('fraud.flaggedCount')}</span>
            <b>{flagged.length}</b>
          </div>
          <div>
            <span>{t('fraud.resolvedCount')}</span>
            <b>{resolved}</b>
          </div>
        </div>
      </div>

      <InfoNote icon="info" tone="info" title={t('fraud.howTitle')}>
        {t('fraud.howBody')}
      </InfoNote>

      <SectionHeader title={t('fraud.detailTitle')} />
      {flagged.length === 0 ? (
        <EmptyState icon="shieldCheck" title={t('fraud.empty')} hint={t('fraud.emptyHint')} />
      ) : (
        <div className="fraud-list">
          {flagged.map(({ tx, score, signals }) => {
            const level = score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low'
            return (
              <Card key={tx.id} className={`fraud-item fraud-item--${level}`}>
                <button
                  type="button"
                  className="fraud-item__top"
                  onClick={() => navigate(`/app/transactions/${tx.id}`)}
                >
                  <div className="fraud-item__main">
                    <strong>{tx.reference}</strong>
                    <span>
                      {tx.customer} · {formatAmount(tx.amountExpected)} DZD
                    </span>
                  </div>
                  <div className={`fraud-score fraud-score--${level}`}>
                    <b>{score}</b>
                    <span>
                      {level === 'high'
                        ? t('fraud.riskHigh')
                        : level === 'medium'
                          ? t('fraud.riskMedium')
                          : t('fraud.riskLow')}
                    </span>
                  </div>
                </button>
                <div className="fraud-item__bar">
                  <span style={{ width: `${score}%` }} />
                </div>
                <div className="fraud-item__signals">
                  {signals.map((sig) => (
                    <span className="mini-chip" key={sig.id}>
                      {t(sig.titleKey)}
                    </span>
                  ))}
                </div>
                <div className="fraud-item__actions">
                  <Button
                    size="sm"
                    variant="secondary"
                    icon="search"
                    onClick={() => navigate(`/app/transactions/${tx.id}`)}
                  >
                    {t('fraud.investigate')}
                  </Button>
                  {tx.status === 'suspicious' ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      icon="check"
                      onClick={() => {
                        const alert = state.alerts.find(
                          (a) => a.transactionId === tx.id && !a.resolved,
                        )
                        if (alert) {
                          resolveAlert(alert.id)
                          notify(t('notif.resolvedMsg'))
                        } else {
                          notify(t('fraud.noSignals'), 'info')
                        }
                      }}
                    >
                      {t('fraud.markResolved')}
                    </Button>
                  ) : null}
                </div>
              </Card>
            )
          })}
        </div>
      )}

      <SectionHeader title={t('fraud.rulesTitle')} />
      <Card className="kv-card">
        <ul className="rules">
          {RULES.map((rule) => (
            <li key={rule.title}>
              <span className="rules__icon">
                <Icon name={rule.icon} size={16} />
              </span>
              <div>
                <strong>{t(rule.title)}</strong>
                <p>{t(rule.desc)}</p>
              </div>
              <span className="rules__on" />
            </li>
          ))}
        </ul>
        <p className="rules__note">
          {t('fraud.thresholdNote', { amount: formatAmount(state.settings.highValueThreshold) })}
          {' · '}
          {t('fraud.liveNote')}
        </p>
      </Card>
    </Screen>
  )
}
