import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { Logo } from '../components/icons'

export default function Splash() {
  const navigate = useNavigate()
  const { t, currentUser, ready } = useStore()
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const started = Date.now()
    const iv = window.setInterval(() => {
      setProgress(Math.min(100, ((Date.now() - started) / 1800) * 100))
    }, 60)
    const timer = window.setTimeout(() => {
      navigate(currentUser ? '/app/dashboard' : '/auth', { replace: true })
    }, 1950)
    return () => {
      window.clearInterval(iv)
      window.clearTimeout(timer)
    }
  }, [navigate, currentUser])

  return (
    <div className="splash">
      <div className="splash__glow splash__glow--1" aria-hidden="true" />
      <div className="splash__glow splash__glow--2" aria-hidden="true" />
      <div className="splash__content">
        <div className="splash__logo">
          <Logo size={92} />
        </div>
        <h1 className="splash__title">SecurePay</h1>
        <p className="splash__tagline" style={{ whiteSpace: 'pre-line' }}>
          {t('splash.tagline')}
        </p>
        <span className="splash__badge">
          <span className="splash__badge-dot" />
          {t('splash.badge')}
        </span>
      </div>
      <div className="splash__footer">
        <div className="splash__bar">
          <div className="splash__bar-fill" style={{ width: `${ready ? progress : 12}%` }} />
        </div>
        <p>{ready ? t('splash.loading') : t('common.loading')}</p>
      </div>
    </div>
  )
}
