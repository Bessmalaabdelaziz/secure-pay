import { useRef, useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { AccessDenied, Button, Field, InfoNote, Input, PageHeader, Screen, Select, Sheet, TextArea } from '../components/ui'
import { Icon } from '../components/icons'
import { METHOD_LABEL, formatAmount, formatDate, toLocalInputValue } from '../lib/format'
import { resizeImage, runReceiptAnalysis } from '../lib/receipt'
import type { PaymentMethod } from '../types'
import type { TranslationKey } from '../i18n'

const TERMINALS = ['TPE-001', 'TPE-002', 'TPE-003']
const MAX_FILE = 5 * 1024 * 1024

export default function AddTransaction() {
  const { t, lang, can, state, currentUser, addTransaction, attachReceipt, notify, userById } =
    useStore()
  const navigate = useNavigate()
  const fileRef = useRef<HTMLInputElement>(null)

  const [reference, setReference] = useState('')
  const [amount, setAmount] = useState('')
  const [date, setDate] = useState(toLocalInputValue(new Date().toISOString()))
  const [method, setMethod] = useState<PaymentMethod>('cib')
  const [customer, setCustomer] = useState('')
  const [terminal, setTerminal] = useState('TPE-001')
  const [employeeId, setEmployeeId] = useState(currentUser?.id ?? '')
  const [notes, setNotes] = useState('')
  const [receiptImage, setReceiptImage] = useState<string | null>(null)
  const [receiptName, setReceiptName] = useState('')
  const [error, setError] = useState<TranslationKey | null>(null)
  const [addressError, setAddressError] = useState<string | null>(null)
  const [duplicate, setDuplicate] = useState<{ id: string; reference: string; date: string; amount: number } | null>(null)
  const [busy, setBusy] = useState(false)

  if (!can('addTransaction')) return <AccessDenied />

  const resetErrors = () => {
    setError(null)
    setAddressError(null)
  }

  const onPickFile = async (file: File | undefined) => {
    if (!file) return
    if (!file.type.startsWith('image/')) {
      setAddressError(t('add.fileType'))
      return
    }
    if (file.size > MAX_FILE) {
      setAddressError(t('add.fileTooLarge'))
      return
    }
    try {
      const data = await resizeImage(file)
      setReceiptImage(data)
      setReceiptName(file.name)
      setAddressError(null)
    } catch {
      setAddressError(t('common.error'))
    }
  }

  const submit = (force = false) => {
    resetErrors()
    const parsed = Number(amount.replace(/\s/g, '').replace(',', '.'))
    setBusy(true)
    const result = addTransaction(
      {
        reference,
        amountExpected: parsed,
        date: new Date(date).toISOString(),
        method,
        customer,
        terminal,
        notes,
        employeeId,
      },
      force,
    )
    setBusy(false)
    if (!result.ok) {
      if (result.duplicate) {
        setDuplicate({
          id: result.duplicate.id,
          reference: result.duplicate.reference,
          date: result.duplicate.date,
          amount: result.duplicate.amountExpected,
        })
        return
      }
      setError(result.error ?? 'common.error')
      return
    }
    const created = result.tx
    if (created && receiptImage) {
      const analysis = runReceiptAnalysis({
        fileName: receiptName || 'recu.jpg',
        image: receiptImage,
        tx: created,
        all: state.transactions,
        merchant: (currentUser?.shopName ?? 'SecurePay').toUpperCase(),
      })
      attachReceipt(created.id, analysis)
    }
    notify(t('add.success'))
    navigate(created ? `/app/transactions/${created.id}` : '/app/transactions', { replace: true })
  }

  const onSubmit = (e: FormEvent) => {
    e.preventDefault()
    submit(false)
  }

  const duplicateOwner = duplicate ? userById(duplicate.id) : undefined

  return (
    <Screen>
      <PageHeader title={t('add.title')} subtitle={t('add.subtitle')} />

      <form onSubmit={onSubmit} className="stack">
        <div className="card form-card">
          <Field label={t('add.reference')} hint={t('add.refHint')}>
            <Input
              value={reference}
              onChange={(e) => {
                setReference(e.target.value.toUpperCase())
                resetErrors()
              }}
              placeholder="TPE20261106-8F3K2L"
              autoCapitalize="characters"
              spellCheck={false}
              required
            />
          </Field>

          <Field label={t('add.amount')} hint={t('add.amountHint')}>
            <div className="input-affix input-affix--money">
              <Input
                inputMode="decimal"
                value={amount}
                onChange={(e) => {
                  setAmount(e.target.value.replace(/[^\d.,]/g, ''))
                  resetErrors()
                }}
                placeholder="12 500"
                required
              />
              <span>DZD</span>
            </div>
          </Field>

          <Field label={t('add.date')}>
            <Input
              type="datetime-local"
              value={date}
              max={toLocalInputValue(new Date().toISOString())}
              onChange={(e) => setDate(e.target.value)}
              required
            />
          </Field>

          <Field label={t('common.method')}>
            <Select value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
              {(Object.keys(METHOD_LABEL) as PaymentMethod[]).map((m) => (
                <option key={m} value={m}>
                  {METHOD_LABEL[m][lang]}
                </option>
              ))}
            </Select>
          </Field>

          <Field label={t('add.customer')}>
            <Input
              value={customer}
              onChange={(e) => {
                setCustomer(e.target.value)
                resetErrors()
              }}
              placeholder="Amine Cherif"
              required
            />
          </Field>

          <div className="form-grid">
            <Field label={t('add.terminal')}>
              <Select value={terminal} onChange={(e) => setTerminal(e.target.value)}>
                {TERMINALS.map((tm) => (
                  <option key={tm} value={tm}>
                    {tm}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label={t('common.employee')}>
              <Select value={employeeId} onChange={(e) => setEmployeeId(e.target.value)}>
                {state.users
                  .filter((u) => u.active)
                  .map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
              </Select>
            </Field>
          </div>

          <Field label={t('add.notes')} optional={t('common.optional')}>
            <TextArea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="Commande, remarque du client…"
            />
          </Field>
        </div>

        <div className="card form-card">
          <div className="upload-head">
            <div>
              <h3>{t('add.receipt')}</h3>
              <p>{t('add.uploadHint')}</p>
            </div>
            <span className="badge badge--info">{t('common.optional')}</span>
          </div>

          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="visually-hidden"
            onChange={(e) => void onPickFile(e.target.files?.[0])}
          />

          {receiptImage ? (
            <div className="upload-preview">
              <img src={receiptImage} alt={t('det.receiptImage')} />
              <div className="upload-preview__meta">
                <span>{receiptName}</span>
                <span className="badge badge--success" style={{ marginTop: 6 }}>
                  <Icon name="check" size={12} /> {t('add.receiptSaved')}
                </span>
              </div>
              <button
                type="button"
                className="icon-btn"
                onClick={() => {
                  setReceiptImage(null)
                  setReceiptName('')
                }}
                aria-label={t('add.removeReceipt')}
              >
                <Icon name="x" size={16} />
              </button>
            </div>
          ) : (
            <button type="button" className="upload-zone" onClick={() => fileRef.current?.click()}>
              <span className="upload-zone__icon">
                <Icon name="camera" size={22} />
              </span>
              <strong>{t('add.uploadReceipt')}</strong>
              <span>{t('add.uploadHint')}</span>
            </button>
          )}

          {addressError ? <p className="form-error">{addressError}</p> : null}
        </div>

        {error ? <p className="form-error">{t(error)}</p> : null}

        <InfoNote icon="lock" tone="info">
          {t('add.secureNote')}
        </InfoNote>

        <Button type="submit" full size="lg" icon="check" loading={busy}>
          {t('add.submit')}
        </Button>
      </form>

      <Sheet
        open={Boolean(duplicate)}
        onClose={() => setDuplicate(null)}
        title={t('add.duplicateTitle')}
        footer={
          <div className="sheet-actions">
            <Button variant="ghost" onClick={() => setDuplicate(null)}>
              {t('common.cancel')}
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                setDuplicate(null)
                submit(true)
              }}
            >
              {t('add.duplicateForce')}
            </Button>
          </div>
        }
      >
        {duplicate ? (
          <div className="stack">
            <InfoNote icon="alertTriangle" tone="danger">
              {t('add.duplicateBody', {
                ref: duplicate.reference,
                date: formatDate(duplicate.date, lang),
              })}
            </InfoNote>
            <div className="dup-card">
              <span className="txrow__icon txrow__icon--suspicious">
                <Icon name="receipt" size={18} />
              </span>
              <div>
                <strong>{duplicate.reference}</strong>
                <p>
                  {formatDate(duplicate.date, lang)} · {formatAmount(duplicate.amount)} DZD
                  {duplicateOwner ? ` · ${duplicateOwner.name}` : ''}
                </p>
              </div>
            </div>
            <Button
              variant="secondary"
              icon="arrowRight"
              onClick={() => navigate(`/app/transactions/${duplicate.id}`)}
            >
              {t('common.open')}
            </Button>
          </div>
        ) : null}
      </Sheet>
    </Screen>
  )
}
