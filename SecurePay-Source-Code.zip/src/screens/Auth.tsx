import { useState, type FormEvent } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { Logo, Icon } from '../components/icons'
import { Button, Field, Input, InfoNote } from '../components/ui'
import { DEMO_PASSWORD } from '../data/seed'
import type { TranslationKey } from '../i18n'

type Mode = 'login' | 'register'

const DEMO_ACCOUNTS = [
  { email: 'demo@securepay.dz', labelKey: 'auth.demoOwner' as TranslationKey, name: 'Yacine Belkacem', color: '#2F6BFF' },
  { email: 'karim@securepay.dz', labelKey: 'auth.demoEmployee' as TranslationKey, name: 'Karim Haddad', color: '#22C55E' },
  { email: 'nadia@securepay.dz', labelKey: 'auth.demoEmployee' as TranslationKey, name: 'Nadia Saidi', color: '#8B5CF6' },
]

export default function Auth() {
  const { t, lang, state, currentUser, authenticate, startSession, register, setSettings, notify } = useStore()
  const navigate = useNavigate()
  const [mode, setMode] = useState<Mode>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState<TranslationKey | null>(null)
  const [busy, setBusy] = useState(false)
  const [pendingUserId, setPendingUserId] = useState<string | null>(null)
  const [otpCode, setOtpCode] = useState('')
  const [otpInput, setOtpInput] = useState('')
  const [otpError, setOtpError] = useState(false)

  const [reg, setReg] = useState({ name: '', shopName: '', email: '', phone: '', password: '' })

  if (currentUser) return <Navigate to="/app/dashboard" replace />

  const onLogin = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!email.trim() || !password) {
      setError('auth.fillFields')
      return
    }
    setBusy(true)
    const result = await authenticate(email, password)
    setBusy(false)
    if (result.error || !result.user) {
      setError(result.error ?? 'auth.invalid')
      return
    }
    if (!state.settings.twoFactor) {
      startSession(result.user.id)
      notify(t('auth.secureNote'))
      navigate('/app/dashboard', { replace: true })
      return
    }
    const code = String(Math.floor(100000 + Math.random() * 900000))
    setOtpCode(code)
    setOtpInput('')
    setPendingUserId(result.user.id)
  }

  const verifyOtp = (e: FormEvent) => {
    e.preventDefault()
    if (!pendingUserId) return
    if (otpInput.trim() !== otpCode) {
      setOtpError(true)
      return
    }
    startSession(pendingUserId)
    notify(t('auth.secureNote'))
    navigate('/app/dashboard', { replace: true })
  }

  const onRegister = async (e: FormEvent) => {
    e.preventDefault()
    setError(null)
    setBusy(true)
    const result = await register({
      name: reg.name,
      email: reg.email,
      phone: reg.phone,
      shopName: reg.shopName,
      password: reg.password,
      role: 'owner',
    })
    setBusy(false)
    if (!result.ok) {
      setError(result.error ?? 'common.error')
      return
    }
    notify(t('auth.secureNote'))
    navigate('/app/dashboard', { replace: true })
  }

  const useDemo = (demoEmail: string) => {
    setMode('login')
    setEmail(demoEmail)
    setPassword(DEMO_PASSWORD)
    setError(null)
  }

  return (
    <div className="auth">
      <div className="auth__glow" aria-hidden="true" />
      <header className="auth__top">
        <div className="auth__brand">
          <Logo size={40} />
          <div>
            <strong>SecurePay</strong>
            <span>{t('app.slogan')}</span>
          </div>
        </div>
        <button
          type="button"
          className="lang-btn"
          onClick={() => setSettings({ lang: lang === 'fr' ? 'ar' : 'fr' })}
        >
          <Icon name="globe" size={15} />
          {lang === 'fr' ? 'العربية' : 'Français'}
        </button>
      </header>

      <div className="auth__hero">
        <h1>{t('auth.welcome')}</h1>
        <p>{t('auth.subtitle')}</p>
      </div>

      <div className="auth__card">
        {pendingUserId ? (
          <form onSubmit={verifyOtp} className="auth__form">
            <div className="otp">
              <span className="otp__icon">
                <Icon name="shieldCheck" size={26} />
              </span>
              <h2>{t('auth.otpTitle')}</h2>
              <p>
                {t('auth.otpHint')} {email}
              </p>
              <input
                className="otp__input"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                value={otpInput}
                onChange={(e) => {
                  setOtpInput(e.target.value.replace(/[^0-9]/g, ''))
                  setOtpError(false)
                }}
                aria-label={t('auth.otpLabel')}
                placeholder="••••••"
                autoFocus
              />
              {otpError ? <p className="otp__error">{t('auth.otpWrong')}</p> : null}
              <Button type="submit" full size="lg" icon="shieldCheck">
                {t('auth.otpVerify')}
              </Button>
              <button
                type="button"
                className="link-btn link-btn--center"
                onClick={() => {
                  setOtpCode(String(Math.floor(100000 + Math.random() * 900000)))
                  setOtpInput('')
                  setOtpError(false)
                }}
              >
                {t('auth.resend')}
              </button>
              <div className="otp__demo">
                <Icon name="info" size={14} />
                <span>
                  {t('auth.otpDemo')} : <strong>{otpCode}</strong>
                </span>
              </div>
            </div>
          </form>
        ) : (
          <>
            <div className="auth__tabs">
              <button
                type="button"
                className={mode === 'login' ? 'is-active' : ''}
                onClick={() => {
                  setMode('login')
                  setError(null)
                }}
              >
                {t('auth.login')}
              </button>
              <button
                type="button"
                className={mode === 'register' ? 'is-active' : ''}
                onClick={() => {
                  setMode('register')
                  setError(null)
                }}
              >
                {t('auth.register')}
              </button>
            </div>

            {mode === 'login' ? (
              <form onSubmit={onLogin} className="auth__form">
                <Field label={t('auth.email')}>
                  <Input
                    type="email"
                    autoComplete="email"
                    placeholder="vous@commerce.dz"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </Field>
                <Field label={t('auth.password')}>
                  <div className="input-affix">
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      aria-label={t('auth.password')}
                      onClick={() => setShowPassword((v) => !v)}
                    >
                      <Icon name={showPassword ? 'eyeOff' : 'eye'} size={18} />
                    </button>
                  </div>
                </Field>
                {error ? <p className="form-error">{t(error)}</p> : null}
                <Button type="submit" full size="lg" loading={busy} iconEnd="arrowRight">
                  {t('auth.submitLogin')}
                </Button>
              </form>
            ) : (
              <form onSubmit={onRegister} className="auth__form">
                <div className="form-grid">
                  <Field label={t('auth.name')}>
                    <Input
                      value={reg.name}
                      onChange={(e) => setReg({ ...reg, name: e.target.value })}
                      placeholder="Ahmed Bensalah"
                    />
                  </Field>
                  <Field label={t('auth.shop')}>
                    <Input
                      value={reg.shopName}
                      onChange={(e) => setReg({ ...reg, shopName: e.target.value })}
                      placeholder="Superette El Feth"
                    />
                  </Field>
                </div>
                <Field label={t('auth.email')}>
                  <Input
                    type="email"
                    value={reg.email}
                    onChange={(e) => setReg({ ...reg, email: e.target.value })}
                    placeholder="vous@commerce.dz"
                  />
                </Field>
                <Field label={t('auth.phone')} optional={t('common.optional')}>
                  <Input
                    type="tel"
                    value={reg.phone}
                    onChange={(e) => setReg({ ...reg, phone: e.target.value })}
                    placeholder="0660 12 34 56"
                  />
                </Field>
                <Field label={t('auth.password')} hint={t('auth.passwordShort')}>
                  <Input
                    type="password"
                    autoComplete="new-password"
                    value={reg.password}
                    onChange={(e) => setReg({ ...reg, password: e.target.value })}
                    placeholder="••••••••"
                  />
                </Field>
                {error ? <p className="form-error">{t(error)}</p> : null}
                <Button type="submit" full size="lg" loading={busy}>
                  {t('auth.submitRegister')}
                </Button>
                <p className="auth__terms">{t('auth.terms')}</p>
              </form>
            )}
          </>
        )}
      </div>

      <div className="auth__demo">
        <div className="auth__demo-head">
          <span>
            <Icon name="sparkles" size={15} /> {t('auth.demoTitle')}
          </span>
          <em>{t('common.demo')}</em>
        </div>
        <p className="auth__demo-hint">{t('auth.demoHint')}</p>
        <div className="auth__demo-list">
          {DEMO_ACCOUNTS.map((acc) => (
            <button type="button" key={acc.email} onClick={() => useDemo(acc.email)} className="demo-account">
              <span className="demo-account__avatar" style={{ background: `${acc.color}22`, color: acc.color }}>
                {acc.name
                  .split(' ')
                  .map((n) => n[0])
                  .join('')}
              </span>
              <span className="demo-account__info">
                <strong>{acc.name}</strong>
                <span>{acc.email}</span>
              </span>
              <span className="demo-account__role">{t(acc.labelKey)}</span>
            </button>
          ))}
        </div>
        <p className="auth__demo-pwd">
          {t('auth.password')} : <strong>{DEMO_PASSWORD}</strong>
        </p>
      </div>

      <InfoNote icon="lock" tone="info">
        {t('auth.protected')} {t('auth.secureNote')}
      </InfoNote>
    </div>
  )
}
