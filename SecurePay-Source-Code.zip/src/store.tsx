import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react'
import type {
  Alert,
  AppState,
  AuditEntry,
  BankRecord,
  NewTransactionInput,
  Permissions,
  ReceiptAnalysis,
  Settings,
  Transaction,
  TxStatus,
  User,
} from './types'
import { createSeedState, hashString, simulateBankRecord } from './data/seed'
import { hashPassword, uid } from './lib/format'
import { reconcileAlerts } from './lib/fraud'
import { translate, type TranslationKey } from './i18n'
import type { Lang } from './types'

const STORAGE_KEY = 'securepay.state.v2'

type T = (key: TranslationKey, params?: Record<string, string | number>) => string

export type ActionResult = { ok: true } | { ok: false; error: TranslationKey }

export interface RegisterInput {
  name: string
  email: string
  phone: string
  shopName: string
  password: string
  role: 'owner' | 'employee'
}

export interface EmployeeInput {
  name: string
  email: string
  phone: string
  permissions: Permissions
}

interface Store {
  ready: boolean
  state: AppState
  lang: Lang
  dir: 'ltr' | 'rtl'
  t: T
  currentUser: User | null
  employees: User[]
  userById: (id: string) => User | undefined
  employeeName: (id: string) => string
  can: (perm: keyof Permissions) => boolean
  authenticate: (email: string, password: string) => Promise<{ user?: User; error?: TranslationKey }>
  startSession: (userId: string) => void
  register: (input: RegisterInput) => Promise<ActionResult>
  logout: () => void
  addTransaction: (
    input: NewTransactionInput,
    force?: boolean,
  ) => { ok: boolean; error?: TranslationKey; duplicate?: Transaction; tx?: Transaction }
  updateStatus: (id: string, status: TxStatus, note?: string) => void
  verifyTransaction: (id: string) => BankRecord | null
  lookupBank: (reference: string) => BankRecord | null
  attachReceipt: (id: string, analysis: ReceiptAnalysis) => void
  toggleFlag: (id: string, flag: string, on: boolean) => void
  resolveAlert: (id: string) => void
  markAllAlertsRead: () => void
  addEmployee: (input: EmployeeInput) => { ok: boolean; error?: TranslationKey; password?: string }
  updateEmployee: (id: string, patch: { permissions?: Permissions; active?: boolean }) => void
  removeEmployee: (id: string) => void
  updateProfile: (patch: Partial<Pick<User, 'name' | 'email' | 'phone' | 'shopName'>>) => void
  changePassword: (current: string, next: string) => Promise<'ok' | 'wrong' | 'short'>
  setSettings: (patch: Partial<Settings>) => void
  resetDemo: () => Promise<void>
  logAudit: (action: string, detail: string, severity?: AuditEntry['severity']) => void
  notify: (message: string, tone?: 'success' | 'error' | 'info') => void
  toast: { message: string; tone: 'success' | 'error' | 'info' } | null
  clearToast: () => void
}

const StoreContext = createContext<Store | null>(null)

function loadState(): AppState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as AppState
    if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.users)) return null
    return parsed
  } catch {
    return null
  }
}

const EMPTY_STATE: AppState = {
  version: 1,
  users: [],
  transactions: [],
  alerts: [],
  audit: [],
  bankLedger: {},
  settings: {
    lang: 'fr',
    notificationsEnabled: true,
    biometric: false,
    twoFactor: true,
    highValueThreshold: 100_000,
    autoLockMinutes: 15,
  },
  sessionUserId: null,
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState | null>(() => loadState())
  const [ready, setReady] = useState<boolean>(() => loadState() !== null)
  const [toast, setToast] = useState<Store['toast']>(null)
  const toastTimer = useRef<number | null>(null)

  useEffect(() => {
    if (state) return
    let cancelled = false
    void (async () => {
      const seeded = await createSeedState()
      if (cancelled) return
      setState(seeded)
      setReady(true)
    })()
    return () => {
      cancelled = true
    }
  }, [state])

  const notify = useCallback((message: string, tone: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, tone })
    if (toastTimer.current) window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(null), 3200)
  }, [])

  const persist = useCallback((next: AppState) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
    } catch {
      /* storage full — keep running in memory */
    }
  }, [])

  const mutate = useCallback(
    (fn: (draft: AppState) => AppState) => {
      setState((prev) => {
        if (!prev) return prev
        const next = fn(prev)
        persist(next)
        return next
      })
    },
    [persist],
  )

  const current = state ?? EMPTY_STATE
  const lang = current.settings.lang
  const t = useCallback<T>((key, params) => translate(lang, key, params), [lang])
  const currentUser = current.users.find((u) => u.id === current.sessionUserId) ?? null

  useEffect(() => {
    document.documentElement.lang = lang
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'
    document.title = lang === 'ar' ? 'SecurePay — متابعة المدفوعات' : 'SecurePay — Suivi des paiements TPE'
  }, [lang])

  const logAudit = useCallback(
    (action: string, detail: string, severity: AuditEntry['severity'] = 'low') => {
      mutate((prev) => {
        const actor =
          prev.users.find((u) => u.id === prev.sessionUserId) ?? prev.users[0] ?? null
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: actor?.id ?? 'system',
          actorName: actor?.name ?? 'Système',
          action,
          detail,
          at: new Date().toISOString(),
          severity,
        }
        return { ...prev, audit: [entry, ...prev.audit].slice(0, 200) }
      })
    },
    [mutate],
  )

  const can = useCallback(
    (perm: keyof Permissions) => Boolean(currentUser?.permissions?.[perm]),
    [currentUser],
  )

  const employees = useMemo(
    () => current.users.filter((u) => u.role === 'employee'),
    [current.users],
  )

  const userById = useCallback(
    (id: string) => current.users.find((u) => u.id === id),
    [current.users],
  )

  const employeeName = useCallback(
    (id: string) => current.users.find((u) => u.id === id)?.name ?? '—',
    [current.users],
  )

  const authenticate = useCallback<Store['authenticate']>(
    async (email, password) => {
      const user = current.users.find(
        (u) => u.email.toLowerCase() === email.trim().toLowerCase(),
      )
      if (!user) return { error: 'auth.invalid' }
      const hash = await hashPassword(password, user.salt)
      if (hash !== user.passwordHash) return { error: 'auth.invalid' }
      if (!user.active) return { error: 'common.permissionDenied' }
      return { user }
    },
    [current.users],
  )

  const startSession = useCallback(
    (userId: string) => {
      const user = current.users.find((u) => u.id === userId)
      if (user) {
        setState((prev) => {
          if (!prev) return prev
          const entry: AuditEntry = {
            id: uid('au'),
            actorId: user.id,
            actorName: user.name,
            action: 'Connexion',
            detail: `${user.role === 'owner' ? 'Propriétaire' : 'Employé'} · double authentification validée`,
            at: new Date().toISOString(),
            severity: 'low',
          }
          const next = { ...prev, sessionUserId: userId, audit: [entry, ...prev.audit] }
          persist(next)
          return next
        })
      }
    },
    [current.users, persist],
  )

  const register = useCallback<Store['register']>(
    async (input) => {
      const email = input.email.trim().toLowerCase()
      if (!input.name.trim() || !email || !input.password || !input.shopName.trim()) {
        return { ok: false, error: 'auth.fillFields' }
      }
      if (input.password.length < 6) return { ok: false, error: 'auth.passwordShort' }
      if (current.users.some((u) => u.email.toLowerCase() === email)) {
        return { ok: false, error: 'auth.emailExists' }
      }
      const salt = `sp-${uid('s')}`
      const passwordHash = await hashPassword(input.password, salt)
      const owner: User = {
        id: uid('u'),
        name: input.name.trim(),
        email,
        phone: input.phone.trim(),
        role: 'owner',
        shopName: input.shopName.trim(),
        passwordHash,
        salt,
        permissions: {
          addTransaction: true,
          viewAllTransactions: true,
          viewReports: true,
          viewFraud: true,
          verifyPayments: true,
          manageEmployees: true,
        },
        active: true,
        createdAt: new Date().toISOString(),
        color: '#2F6BFF',
      }
      mutate((prev) => {
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: owner.id,
          actorName: owner.name,
          action: 'Création de compte',
          detail: `Nouveau commerce : ${owner.shopName}`,
          at: new Date().toISOString(),
          severity: 'low',
        }
        return {
          ...prev,
          users: [...prev.users, owner],
          sessionUserId: owner.id,
          audit: [entry, ...prev.audit],
        }
      })
      return { ok: true }
    },
    [current.users, mutate],
  )

  const logout = useCallback(() => {
    const user = current.users.find((u) => u.id === current.sessionUserId)
    mutate((prev) => {
      const entry: AuditEntry = {
        id: uid('au'),
        actorId: user?.id ?? 'system',
        actorName: user?.name ?? 'Système',
        action: 'Déconnexion',
        detail: 'Session fermée sur cet appareil',
        at: new Date().toISOString(),
        severity: 'low',
      }
      return { ...prev, sessionUserId: null, audit: [entry, ...prev.audit] }
    })
  }, [current.sessionUserId, current.users, mutate])

  const addTransaction = useCallback<Store['addTransaction']>(
    (input, force = false) => {
      if (!currentUser?.permissions.addTransaction) {
        return { ok: false, error: 'common.permissionDenied' }
      }
      const reference = input.reference.trim().toUpperCase()
      if (reference.length < 6 || !/^[A-Z0-9-]+$/.test(reference)) {
        return { ok: false, error: 'add.invalidReference' }
      }
      if (
        !Number.isFinite(input.amountExpected) ||
        input.amountExpected < 50 ||
        input.amountExpected > 5_000_000
      ) {
        return { ok: false, error: 'add.invalidAmount' }
      }
      if (new Date(input.date).getTime() > Date.now() + 60_000) {
        return { ok: false, error: 'add.invalidDate' }
      }
      if (!input.customer.trim()) return { ok: false, error: 'add.missingCustomer' }

      const duplicate = current.transactions.find(
        (tx) => tx.reference.toUpperCase() === reference,
      )
      if (duplicate && !force) {
        return { ok: false, duplicate }
      }

      const nowIso = new Date().toISOString()
      const tx: Transaction = {
        id: uid('tx'),
        reference,
        amountExpected: Math.round(input.amountExpected),
        amountConfirmed: 0,
        date: new Date(input.date).toISOString(),
        method: input.method,
        status: 'pending',
        customer: input.customer.trim(),
        terminal: input.terminal,
        employeeId: input.employeeId || currentUser.id,
        notes: input.notes.trim(),
        flags: duplicate ? ['duplicate'] : [],
        duplicateOf: duplicate?.id,
        createdAt: nowIso,
        updatedAt: nowIso,
      }

      mutate((prev) => {
        const nextTxns = [tx, ...prev.transactions]
        let alerts = prev.alerts
        alerts = reconcileAlerts(alerts, nextTxns[0], nextTxns, prev.settings)
        if (duplicate) {
          alerts = reconcileAlerts(alerts, duplicate, nextTxns, prev.settings)
        }
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Nouvelle transaction',
          detail: `${tx.reference} · ${tx.amountExpected} DZD · ${tx.method.toUpperCase()}${
            duplicate ? ' · DOUBLON signalé' : ''
          }`,
          at: nowIso,
          severity: duplicate ? 'high' : 'low',
        }
        return {
          ...prev,
          transactions: nextTxns,
          alerts,
          audit: [entry, ...prev.audit],
        }
      })
      return { ok: true, tx }
    },
    [current.transactions, currentUser, mutate],
  )

  const updateStatus = useCallback<Store['updateStatus']>(
    (id, status, note) => {
      if (!currentUser) return
      const nowIso = new Date().toISOString()
      mutate((prev) => {
        const tx = prev.transactions.find((x) => x.id === id)
        if (!tx) return prev
        const updated: Transaction = { ...tx, status, updatedAt: nowIso }
        if (status === 'confirmed' && updated.amountConfirmed === 0) {
          updated.amountConfirmed = updated.amountExpected
        }
        if (['pending', 'failed', 'missing', 'delayed'].includes(status)) {
          updated.amountConfirmed = 0
        }
        const nextTxns = prev.transactions.map((x) => (x.id === id ? updated : x))
        const alerts = reconcileAlerts(prev.alerts, updated, nextTxns, prev.settings)
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Changement de statut',
          detail: `${tx.reference} · ${tx.status} → ${status}${note ? ` · ${note}` : ''}`,
          at: nowIso,
          severity: status === 'suspicious' ? 'high' : 'medium',
        }
        return {
          ...prev,
          transactions: nextTxns,
          alerts,
          audit: [entry, ...prev.audit],
        }
      })
    },
    [currentUser, mutate],
  )

  const lookupBank = useCallback<Store['lookupBank']>(
    (reference) => {
      const ref = reference.trim().toUpperCase()
      if (!ref) return null
      const tx = current.transactions.find((x) => x.reference.toUpperCase() === ref)
      if (!tx) return null
      const existing = current.bankLedger[ref]
      if (existing) return existing
      const record = simulateBankRecord({
        reference: ref,
        amount: tx.amountExpected,
        terminal: tx.terminal,
        method: tx.method,
        date: tx.date,
      })
      mutate((prev) => ({
        ...prev,
        bankLedger: { ...prev.bankLedger, [ref]: record },
      }))
      return record
    },
    [current.bankLedger, current.transactions, mutate],
  )

  const verifyTransaction = useCallback<Store['verifyTransaction']>(
    (id) => {
      if (!currentUser) return null
      if (!currentUser.permissions.verifyPayments) return null
      const tx = current.transactions.find((x) => x.id === id)
      if (!tx) return null
      const ref = tx.reference.toUpperCase()
      const record =
        current.bankLedger[ref] ??
        simulateBankRecord({
          reference: ref,
          amount: tx.amountExpected,
          terminal: tx.terminal,
          method: tx.method,
          date: tx.date,
        })
      const nowIso = new Date().toISOString()

      mutate((prev) => {
        const target = prev.transactions.find((x) => x.id === id)
        if (!target) return prev
        let status: TxStatus = target.status
        let amountConfirmed = target.amountConfirmed
        let flags = target.flags.filter((f) => !['missing', 'delayed', 'failed'].includes(f))
        switch (record.status) {
          case 'confirmed':
            status = 'confirmed'
            amountConfirmed = Math.min(record.settledAmount || target.amountExpected, target.amountExpected)
            if (Math.abs(amountConfirmed - target.amountExpected) > 1) {
              status = 'suspicious'
              flags = [...new Set([...flags, 'amount_mismatch'])]
            }
            break
          case 'pending':
            status = 'pending'
            amountConfirmed = 0
            break
          case 'failed':
            status = 'failed'
            amountConfirmed = 0
            flags = [...new Set([...flags, 'failed'])]
            break
          case 'mismatch':
            status = 'suspicious'
            amountConfirmed = record.settledAmount
            flags = [...new Set([...flags, 'amount_mismatch'])]
            break
          case 'not_found':
            status = 'missing'
            amountConfirmed = 0
            flags = [...new Set([...flags, 'missing'])]
            break
        }
        const updated: Transaction = {
          ...target,
          status,
          amountConfirmed,
          flags,
          bankCheckedAt: nowIso,
          bankRef: `BR${hashString(ref) % 10_000_000}`,
          bankMessage: record.message,
          updatedAt: nowIso,
        }
        const nextTxns = prev.transactions.map((x) => (x.id === id ? updated : x))
        const alerts = reconcileAlerts(prev.alerts, updated, nextTxns, prev.settings)
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Vérification bancaire',
          detail: `${ref} · ${record.status} · ${record.settledAmount} DZD (banque simulée)`,
          at: nowIso,
          severity: record.status === 'confirmed' ? 'low' : 'high',
        }
        return {
          ...prev,
          transactions: nextTxns,
          alerts,
          bankLedger: { ...prev.bankLedger, [ref]: record },
          audit: [entry, ...prev.audit],
        }
      })
      return record
    },
    [current.bankLedger, current.transactions, currentUser, mutate],
  )

  const attachReceipt = useCallback<Store['attachReceipt']>(
    (id, analysis) => {
      if (!currentUser) return
      mutate((prev) => {
        const tx = prev.transactions.find((x) => x.id === id)
        if (!tx) return prev
        const updated: Transaction = { ...tx, receipt: analysis, updatedAt: new Date().toISOString() }
        const nextTxns = prev.transactions.map((x) => (x.id === id ? updated : x))
        const alerts = reconcileAlerts(prev.alerts, updated, nextTxns, prev.settings)
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Analyse de reçu',
          detail: `${tx.reference} · score ${analysis.score}/100 · ${analysis.verdict}`,
          at: new Date().toISOString(),
          severity: analysis.verdict === 'suspicious' ? 'high' : 'low',
        }
        return { ...prev, transactions: nextTxns, alerts, audit: [entry, ...prev.audit] }
      })
    },
    [currentUser, mutate],
  )

  const toggleFlag = useCallback<Store['toggleFlag']>(
    (id, flag, on) => {
      if (!currentUser) return
      mutate((prev) => {
        const tx = prev.transactions.find((x) => x.id === id)
        if (!tx) return prev
        const flags = on
          ? [...new Set([...tx.flags, flag])]
          : tx.flags.filter((f) => f !== flag)
        const updated: Transaction = { ...tx, flags, updatedAt: new Date().toISOString() }
        if (flag === 'duplicate' && on) updated.duplicateOf = tx.duplicateOf
        const nextTxns = prev.transactions.map((x) => (x.id === id ? updated : x))
        const alerts = reconcileAlerts(prev.alerts, updated, nextTxns, prev.settings)
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Signalement',
          detail: `${tx.reference} · ${on ? 'ajout' : 'retrait'} du signal « ${flag} »`,
          at: new Date().toISOString(),
          severity: on ? 'high' : 'low',
        }
        return { ...prev, transactions: nextTxns, alerts, audit: [entry, ...prev.audit] }
      })
    },
    [currentUser, mutate],
  )

  const resolveAlert = useCallback<Store['resolveAlert']>(
    (id) => {
      if (!currentUser) return
      mutate((prev) => {
        const alert = prev.alerts.find((a) => a.id === id)
        const alerts = prev.alerts.map((a) =>
          a.id === id ? { ...a, read: true, resolved: true } : a,
        )
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Alerte traitée',
          detail: alert
            ? `${translate(prev.settings.lang, alert.titleKey as TranslationKey, alert.params)} · ${
                alert.transactionId ?? id
              }`
            : id,
          at: new Date().toISOString(),
          severity: 'low',
        }
        return { ...prev, alerts, audit: [entry, ...prev.audit] }
      })
    },
    [currentUser, mutate],
  )

  const markAllAlertsRead = useCallback(() => {
    mutate((prev) => ({
      ...prev,
      alerts: prev.alerts.map((a) => ({ ...a, read: true })),
    }))
  }, [mutate])

  const addEmployee = useCallback<Store['addEmployee']>(
    (input) => {
      if (!currentUser?.permissions.manageEmployees) {
        return { ok: false, error: 'common.permissionDenied' }
      }
      if (!input.name.trim() || !input.email.trim()) {
        return { ok: false, error: 'emp.fillFields' }
      }
      const email = input.email.trim().toLowerCase()
      if (current.users.some((u) => u.email.toLowerCase() === email)) {
        return { ok: false, error: 'emp.emailExists' }
      }
      const password = `sp${Math.floor(1000 + Math.random() * 9000)}`
      const salt = `sp-${uid('s')}`
      void (async () => {
        const passwordHash = await hashPassword(password, salt)
        const employee: User = {
          id: uid('u'),
          name: input.name.trim(),
          email,
          phone: input.phone.trim(),
          role: 'employee',
          shopName: currentUser.shopName,
          passwordHash,
          salt,
          permissions: input.permissions,
          active: true,
          createdAt: new Date().toISOString(),
          color: ['#22C55E', '#F59E0B', '#8B5CF6', '#22D3EE'][
            Math.floor(Math.random() * 4)
          ],
        }
        mutate((prev) => {
          const entry: AuditEntry = {
            id: uid('au'),
            actorId: currentUser.id,
            actorName: currentUser.name,
            action: 'Ajout employé',
            detail: `${employee.name} · ${employee.email}`,
            at: new Date().toISOString(),
            severity: 'medium',
          }
          return { ...prev, users: [...prev.users, employee], audit: [entry, ...prev.audit] }
        })
      })()
      return { ok: true, password }
    },
    [current.users, currentUser, mutate],
  )

  const updateEmployee = useCallback<Store['updateEmployee']>(
    (id, patch) => {
      if (!currentUser?.permissions.manageEmployees) return
      mutate((prev) => {
        const target = prev.users.find((u) => u.id === id)
        if (!target) return prev
        const users = prev.users.map((u) => (u.id === id ? { ...u, ...patch } : u))
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: patch.active === false ? 'Suspension employé' : 'Modification employé',
          detail: `${target.name}${patch.permissions ? ' · permissions mises à jour' : ''}${
            patch.active !== undefined ? ` · ${patch.active ? 'actif' : 'suspendu'}` : ''
          }`,
          at: new Date().toISOString(),
          severity: 'medium',
        }
        return { ...prev, users, audit: [entry, ...prev.audit] }
      })
    },
    [currentUser, mutate],
  )

  const removeEmployee = useCallback<Store['removeEmployee']>(
    (id) => {
      if (!currentUser?.permissions.manageEmployees) return
      mutate((prev) => {
        const target = prev.users.find((u) => u.id === id)
        if (!target) return prev
        const entry: AuditEntry = {
          id: uid('au'),
          actorId: currentUser.id,
          actorName: currentUser.name,
          action: 'Suppression employé',
          detail: `${target.name} · accès révoqué`,
          at: new Date().toISOString(),
          severity: 'high',
        }
        return {
          ...prev,
          users: prev.users.filter((u) => u.id !== id),
          audit: [entry, ...prev.audit],
        }
      })
    },
    [currentUser, mutate],
  )

  const updateProfile = useCallback<Store['updateProfile']>(
    (patch) => {
      if (!currentUser) return
      mutate((prev) => ({
        ...prev,
        users: prev.users.map((u) => (u.id === currentUser.id ? { ...u, ...patch } : u)),
        audit: [
          {
            id: uid('au'),
            actorId: currentUser.id,
            actorName: currentUser.name,
            action: 'Profil modifié',
            detail: Object.keys(patch).join(', '),
            at: new Date().toISOString(),
            severity: 'low' as const,
          },
          ...prev.audit,
        ],
      }))
    },
    [currentUser, mutate],
  )

  const changePassword = useCallback<Store['changePassword']>(
    async (currentPwd, next) => {
      if (!currentUser) return 'wrong'
      if (next.length < 6) return 'short'
      const hash = await hashPassword(currentPwd, currentUser.salt)
      if (hash !== currentUser.passwordHash) return 'wrong'
      const salt = `sp-${uid('s')}`
      const passwordHash = await hashPassword(next, salt)
      mutate((prev) => ({
        ...prev,
        users: prev.users.map((u) =>
          u.id === currentUser.id ? { ...u, salt, passwordHash } : u,
        ),
        audit: [
          {
            id: uid('au'),
            actorId: currentUser.id,
            actorName: currentUser.name,
            action: 'Mot de passe modifié',
            detail: 'Mot de passe du compte mis à jour',
            at: new Date().toISOString(),
            severity: 'medium' as const,
          },
          ...prev.audit,
        ],
      }))
      return 'ok'
    },
    [currentUser, mutate],
  )

  const setSettings = useCallback<Store['setSettings']>(
    (patch) => {
      mutate((prev) => {
        const settings = { ...prev.settings, ...patch }
        let alerts = prev.alerts
        for (const tx of prev.transactions) {
          if (patch.highValueThreshold === undefined && patch.notificationsEnabled === undefined) break
          alerts = reconcileAlerts(alerts, tx, prev.transactions, settings)
        }
        const entries: AuditEntry[] = []
        if (patch.lang && patch.lang !== prev.settings.lang) {
          entries.push({
            id: uid('au'),
            actorId: currentUser?.id ?? 'system',
            actorName: currentUser?.name ?? 'Système',
            action: 'Changement de langue',
            detail: patch.lang === 'ar' ? 'Arabe (RTL)' : 'Français',
            at: new Date().toISOString(),
            severity: 'low',
          })
        }
        return {
          ...prev,
          settings,
          alerts,
          audit: [...entries, ...prev.audit],
        }
      })
    },
    [currentUser, mutate],
  )

  const resetDemo = useCallback(async () => {
    const seeded = await createSeedState()
    setState((prev) => ({
      ...seeded,
      sessionUserId: prev?.sessionUserId ?? null,
      settings: prev?.settings ?? seeded.settings,
      audit: [
        {
          id: uid('au'),
          actorId: prev?.sessionUserId ?? 'system',
          actorName: prev?.users.find((u) => u.id === prev.sessionUserId)?.name ?? 'Système',
          action: 'Réinitialisation des données',
          detail: 'Jeu de démonstration restauré',
          at: new Date().toISOString(),
          severity: 'medium',
        },
        ...seeded.audit,
      ],
    }))
  }, [])

  const value = useMemo<Store>(
    () => ({
      ready,
      state: current,
      lang,
      dir: lang === 'ar' ? 'rtl' : 'ltr',
      t,
      currentUser,
      employees,
      userById,
      employeeName,
      can,
      authenticate,
      startSession,
      register,
      logout,
      addTransaction,
      updateStatus,
      verifyTransaction,
      lookupBank,
      attachReceipt,
      toggleFlag,
      resolveAlert,
      markAllAlertsRead,
      addEmployee,
      updateEmployee,
      removeEmployee,
      updateProfile,
      changePassword,
      setSettings,
      resetDemo,
      logAudit,
      notify,
      toast,
      clearToast: () => setToast(null),
    }),
    [
      ready,
      current,
      lang,
      t,
      currentUser,
      employees,
      userById,
      employeeName,
      can,
      authenticate,
      startSession,
      register,
      logout,
      addTransaction,
      updateStatus,
      verifyTransaction,
      lookupBank,
      attachReceipt,
      toggleFlag,
      resolveAlert,
      markAllAlertsRead,
      addEmployee,
      updateEmployee,
      removeEmployee,
      updateProfile,
      changePassword,
      setSettings,
      resetDemo,
      logAudit,
      notify,
      toast,
    ],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore(): Store {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error('useStore must be used inside StoreProvider')
  return ctx
}

export type { Alert }
