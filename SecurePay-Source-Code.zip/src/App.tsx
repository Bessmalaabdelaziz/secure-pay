import { Navigate, Route, Routes } from 'react-router-dom'
import { AppLayout, Protected } from './components/AppShell'
import Splash from './screens/Splash'
import Auth from './screens/Auth'
import Dashboard from './screens/Dashboard'
import Transactions from './screens/Transactions'
import AddTransaction from './screens/AddTransaction'
import TransactionDetails from './screens/TransactionDetails'
import Verification from './screens/Verification'
import ReceiptAnalysis from './screens/ReceiptAnalysis'
import Fraud from './screens/Fraud'
import Notifications from './screens/Notifications'
import Reports from './screens/Reports'
import Employees from './screens/Employees'
import Profile from './screens/Profile'
import AuditLog from './screens/AuditLog'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Splash />} />
      <Route path="/auth" element={<Auth />} />
      <Route
        path="/app"
        element={
          <Protected>
            <AppLayout />
          </Protected>
        }
      >
        <Route index element={<Navigate to="/app/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="transactions" element={<Transactions />} />
        <Route path="transactions/new" element={<AddTransaction />} />
        <Route path="transactions/:id" element={<TransactionDetails />} />
        <Route path="verify" element={<Verification />} />
        <Route path="receipt" element={<ReceiptAnalysis />} />
        <Route path="fraud" element={<Fraud />} />
        <Route path="notifications" element={<Notifications />} />
        <Route path="reports" element={<Reports />} />
        <Route path="employees" element={<Employees />} />
        <Route path="audit" element={<AuditLog />} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/app/dashboard" replace />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
