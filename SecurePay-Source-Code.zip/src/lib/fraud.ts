import type { Alert, Settings, Transaction } from '../types'
import type { TranslationKey } from '../i18n'

export interface Signal {
  id: string
  weight: number
  titleKey: TranslationKey
  bodyKey: TranslationKey
  params: Record<string, string | number>
}

const HOUR = 3600_000

function isOffHours(iso: string): boolean {
  const h = new Date(iso).getHours()
  return h >= 23 || h < 5
}

function rapidCount(tx: Transaction, all: Transaction[]): number {
  const t = new Date(tx.date).getTime()
  return all.filter(
    (o) =>
      o.id !== tx.id &&
      o.terminal === tx.terminal &&
      Math.abs(new Date(o.date).getTime() - t) < 10 * 60_000,
  ).length + 1
}

/** Weighted rule engine — deterministic, no external calls. */
export function detectSignals(
  tx: Transaction,
  all: Transaction[],
  settings: Settings,
): Signal[] {
  const signals: Signal[] = []
  const duplicates = all.filter(
    (o) => o.id !== tx.id && o.reference.trim().toUpperCase() === tx.reference.trim().toUpperCase(),
  )

  if (duplicates.length > 0) {
    signals.push({
      id: 'duplicate',
      weight: 45,
      titleKey: 'alert.duplicate.title',
      bodyKey: 'alert.duplicate.body',
      params: { ref: tx.reference, count: duplicates.length + 1 },
    })
  }

  const gap = tx.amountExpected - tx.amountConfirmed
  if (tx.amountConfirmed > 0 && gap > 1 && ['confirmed', 'suspicious'].includes(tx.status)) {
    signals.push({
      id: 'mismatch',
      weight: 30,
      titleKey: 'alert.mismatch.title',
      bodyKey: 'alert.mismatch.body',
      params: {
        ref: tx.reference,
        expected: Math.round(tx.amountExpected),
        settled: Math.round(tx.amountConfirmed),
      },
    })
  }

  if (tx.amountExpected >= settings.highValueThreshold) {
    signals.push({
      id: 'high_value',
      weight: 20,
      titleKey: 'alert.highValue.title',
      bodyKey: 'alert.highValue.body',
      params: {
        amount: Math.round(tx.amountExpected),
        threshold: Math.round(settings.highValueThreshold),
      },
    })
  }

  if (isOffHours(tx.date)) {
    const time = new Date(tx.date).toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit',
    })
    signals.push({
      id: 'off_hours',
      weight: 15,
      titleKey: 'alert.offHours.title',
      bodyKey: 'alert.offHours.body',
      params: { amount: Math.round(tx.amountExpected), time, ref: tx.reference },
    })
  }

  const rapid = rapidCount(tx, all)
  if (rapid >= 4) {
    signals.push({
      id: 'rapid',
      weight: 18,
      titleKey: 'alert.rapid.title',
      bodyKey: 'alert.rapid.body',
      params: { count: rapid, terminal: tx.terminal },
    })
  }

  if (tx.receipt && tx.receipt.score < 50) {
    signals.push({
      id: 'suspicious_receipt',
      weight: 22,
      titleKey: 'alert.receipt.title',
      bodyKey: 'alert.receipt.body',
      params: { ref: tx.reference, score: tx.receipt.score },
    })
  }

  if (tx.status === 'missing') {
    signals.push({
      id: 'missing',
      weight: 40,
      titleKey: 'alert.missing.title',
      bodyKey: 'alert.missing.body',
      params: { ref: tx.reference, amount: Math.round(tx.amountExpected) },
    })
  }

  if (tx.status === 'failed') {
    signals.push({
      id: 'failed',
      weight: 25,
      titleKey: 'alert.failed.title',
      bodyKey: 'alert.failed.body',
      params: { ref: tx.reference, amount: Math.round(tx.amountExpected) },
    })
  }

  if (
    tx.status === 'delayed' ||
    (tx.status === 'pending' &&
      Date.now() - new Date(tx.date).getTime() > 48 * HOUR)
  ) {
    signals.push({
      id: 'delayed',
      weight: 20,
      titleKey: 'alert.delayed.title',
      bodyKey: 'alert.delayed.body',
      params: { ref: tx.reference, amount: Math.round(tx.amountExpected) },
    })
  }

  return signals
}

export function riskScore(tx: Transaction, all: Transaction[], settings: Settings): number {
  const total = detectSignals(tx, all, settings).reduce((s, sig) => s + sig.weight, 0)
  return Math.min(100, total)
}

const SEVERITY_WEIGHT: Record<string, number> = {
  duplicate: 45,
  mismatch: 30,
  high_value: 20,
  rapid: 18,
  off_hours: 15,
  suspicious_receipt: 22,
  missing: 40,
  failed: 25,
  delayed: 20,
}

export function signalSeverity(id: string): 'low' | 'medium' | 'high' {
  const w = SEVERITY_WEIGHT[id] ?? 10
  if (w >= 35) return 'high'
  if (w >= 20) return 'medium'
  return 'low'
}

function alertId(type: string, txId: string): string {
  return `al_${type}_${txId}`
}

/**
 * Creates missing alerts for the given transaction, keeping read/resolved
 * flags of alerts that already exist (stable ids).
 */
export function reconcileAlerts(
  existing: Alert[],
  tx: Transaction,
  all: Transaction[],
  settings: Settings,
): Alert[] {
  if (!settings.notificationsEnabled) return existing
  const byId = new Map(existing.map((a) => [a.id, a]))
  for (const sig of detectSignals(tx, all, settings)) {
    const id = alertId(sig.id, tx.id)
    const found = byId.get(id)
    if (found && !found.resolved) {
      byId.set(id, { ...found, params: sig.params, severity: signalSeverity(sig.id) })
    } else if (!found) {
      byId.set(id, {
        id,
        type: sig.id as Alert['type'],
        severity: signalSeverity(sig.id),
        titleKey: sig.titleKey,
        messageKey: sig.bodyKey,
        params: sig.params,
        transactionId: tx.id,
        createdAt: new Date().toISOString(),
        read: false,
        resolved: false,
      })
    }
  }
  // Drop alerts whose signal no longer applies (e.g. duplicate resolved).
  const valid = new Set(detectSignals(tx, all, settings).map((s) => alertId(s.id, tx.id)))
  return [...byId.values()].filter(
    (a) => a.transactionId !== tx.id || a.resolved || valid.has(a.id),
  )
}
