import type { Lang, PaymentMethod, TxStatus } from '../types'

const DZD = new Intl.NumberFormat('fr-FR', {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
})

export function formatAmount(value: number): string {
  return DZD.format(Math.round(value)).replace(/\u202f/g, ' ')
}

export function formatDZD(value: number): string {
  return `${formatAmount(value)} DZD`
}

export function formatCompact(value: number): string {
  if (Math.abs(value) >= 1_000_000) {
    return `${(value / 1_000_000).toFixed(value % 1_000_000 === 0 ? 0 : 1).replace('.', ',')} M`
  }
  if (Math.abs(value) >= 1_000) {
    return `${(value / 1_000).toFixed(value % 1_000 === 0 ? 0 : 1).replace('.', ',')} k`
  }
  return formatAmount(value)
}

export function formatDate(iso: string, lang: Lang): string {
  const d = new Date(iso)
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(d)
}

export function formatDateShort(iso: string, lang: Lang): string {
  const d = new Date(iso)
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
    day: '2-digit',
    month: '2-digit',
  }).format(d)
}

export function formatTime(iso: string, lang: Lang): string {
  const d = new Date(iso)
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
    hour: '2-digit',
    minute: '2-digit',
  }).format(d)
}

export function formatDateTime(iso: string, lang: Lang): string {
  return `${formatDate(iso, lang)} · ${formatTime(iso, lang)}`
}

export function relativeTime(iso: string, lang: Lang): string {
  const diff = Date.now() - new Date(iso).getTime()
  const min = Math.round(diff / 60000)
  if (min < 1) return lang === 'ar' ? 'الآن' : "à l'instant"
  if (min < 60) return lang === 'ar' ? `قبل ${min} د` : `il y a ${min} min`
  const hours = Math.round(min / 60)
  if (hours < 24) return lang === 'ar' ? `قبل ${hours} س` : `il y a ${hours} h`
  const days = Math.round(hours / 24)
  if (days < 30) return lang === 'ar' ? `قبل ${days} ي` : `il y a ${days} j`
  return formatDate(iso, lang)
}

export function monthLabel(date: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
    month: 'long',
    year: 'numeric',
  }).format(date)
}

export function dayLabel(date: Date, lang: Lang): string {
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-DZ', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  }).format(date)
}

export const STATUS_LABEL: Record<TxStatus, { fr: string; ar: string }> = {
  confirmed: { fr: 'Confirmé', ar: 'مؤكد' },
  pending: { fr: 'En attente', ar: 'قيد الانتظار' },
  failed: { fr: 'Échoué', ar: 'فاشل' },
  delayed: { fr: 'Retardé', ar: 'متأخر' },
  missing: { fr: 'Manquant', ar: 'مفقود' },
  suspicious: { fr: 'Suspect', ar: 'مشبوه' },
}

export const METHOD_LABEL: Record<PaymentMethod, { fr: string; ar: string }> = {
  cib: { fr: 'Carte CIB', ar: 'بطاقة CIB' },
  edahabia: { fr: 'Edahabia', ar: 'الذهبية' },
  cash: { fr: 'Espèces', ar: 'نقدا' },
  virement: { fr: 'Virement', ar: 'تحويل' },
}

export const METHOD_SHORT: Record<PaymentMethod, string> = {
  cib: 'CIB',
  edahabia: 'EDH',
  cash: 'ESP',
  virement: 'VIR',
}

export function startOfDay(d: Date): Date {
  const c = new Date(d)
  c.setHours(0, 0, 0, 0)
  return c
}

export function addDays(d: Date, n: number): Date {
  const c = new Date(d)
  c.setDate(c.getDate() + n)
  return c
}

export function sameDay(a: Date, b: Date): boolean {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  )
}

export function toLocalInputValue(iso: string): string {
  const d = new Date(iso)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
    d.getHours(),
  )}:${pad(d.getMinutes())}`
}

export function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}${Date.now()
    .toString(36)
    .slice(-4)}`
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? '')
    .join('')
}

export function maskIban(value: string): string {
  if (value.length <= 6) return value
  return `${value.slice(0, 3)}••••${value.slice(-3)}`
}

/** SHA-256 hash with salt, WebCrypto. Used for local prototype credentials only. */
export async function hashPassword(password: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${password}`)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
}

export function downloadFile(filename: string, content: string, mime = 'text/csv') {
  const blob = new Blob(['\ufeff' + content], { type: `${mime};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
