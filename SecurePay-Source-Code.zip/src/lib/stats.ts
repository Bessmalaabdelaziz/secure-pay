import type { PaymentMethod, Stats, Transaction, TxStatus } from '../types'
import { addDays, sameDay, startOfDay } from './format'

export function inRange(tx: Transaction, from: Date, to: Date): boolean {
  const t = new Date(tx.date).getTime()
  return t >= from.getTime() && t <= to.getTime()
}

export function filterRange(txns: Transaction[], days: number): Transaction[] {
  const to = new Date()
  const from = startOfDay(addDays(to, -(days - 1)))
  return txns.filter((t) => inRange(t, from, to))
}

export function rangeBounds(days: number): { from: Date; to: Date } {
  const to = new Date()
  to.setHours(23, 59, 59, 999)
  const from = startOfDay(addDays(to, -(days - 1)))
  return { from, to }
}

export function computeStats(txns: Transaction[]): Stats {
  const s: Stats = {
    expected: 0,
    confirmed: 0,
    pending: 0,
    missing: 0,
    failed: 0,
    suspicious: 0,
    delayed: 0,
    count: txns.length,
    gap: 0,
    recoveryRate: 0,
    avgTicket: 0,
  }
  for (const t of txns) {
    s.expected += t.amountExpected
    s.confirmed += Math.min(t.amountConfirmed, t.amountExpected)
    switch (t.status) {
      case 'pending':
        s.pending += t.amountExpected
        break
      case 'delayed':
        s.delayed += t.amountExpected
        break
      case 'missing':
        s.missing += t.amountExpected
        break
      case 'failed':
        s.failed += t.amountExpected
        break
      case 'suspicious':
        s.suspicious += t.amountExpected - t.amountConfirmed
        break
      default:
        break
    }
  }
  s.gap = Math.max(0, s.expected - s.confirmed)
  s.recoveryRate = s.expected > 0 ? (s.confirmed / s.expected) * 100 : 0
  s.avgTicket = s.count > 0 ? s.expected / s.count : 0
  return s
}

export interface DayPoint {
  date: Date
  label: string
  expected: number
  confirmed: number
  count: number
}

export function dailySeries(txns: Transaction[], days: number): DayPoint[] {
  const today = startOfDay(new Date())
  const points: DayPoint[] = []
  for (let i = days - 1; i >= 0; i--) {
    const date = addDays(today, -i)
    const dayTx = txns.filter((t) => sameDay(new Date(t.date), date))
    const expected = dayTx.reduce((s, t) => s + t.amountExpected, 0)
    const confirmed = dayTx.reduce(
      (s, t) => s + Math.min(t.amountConfirmed, t.amountExpected),
      0,
    )
    points.push({
      date,
      label: new Intl.DateTimeFormat('fr-FR', { day: '2-digit', month: '2-digit' }).format(date),
      expected,
      confirmed,
      count: dayTx.length,
    })
  }
  return points
}

export function monthlySeries(txns: Transaction[], months: number): DayPoint[] {
  const now = new Date()
  const out: DayPoint[] = []
  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1)
    const next = new Date(now.getFullYear(), now.getMonth() - i + 1, 1)
    const monthTx = txns.filter((t) => {
      const td = new Date(t.date)
      return td >= d && td < next
    })
    out.push({
      date: d,
      label: new Intl.DateTimeFormat('fr-FR', { month: 'short' }).format(d),
      expected: monthTx.reduce((s, t) => s + t.amountExpected, 0),
      confirmed: monthTx.reduce((s, t) => s + Math.min(t.amountConfirmed, t.amountExpected), 0),
      count: monthTx.length,
    })
  }
  return out
}

export function statusBreakdown(txns: Transaction[]): { status: TxStatus; count: number; amount: number }[] {
  const statuses: TxStatus[] = [
    'confirmed',
    'pending',
    'delayed',
    'missing',
    'failed',
    'suspicious',
  ]
  return statuses.map((status) => {
    const list = txns.filter((t) => t.status === status)
    return {
      status,
      count: list.length,
      amount: list.reduce((s, t) => s + t.amountExpected, 0),
    }
  })
}

export function methodBreakdown(txns: Transaction[]): { method: PaymentMethod; count: number; amount: number }[] {
  const methods: PaymentMethod[] = ['cib', 'edahabia', 'cash', 'virement']
  return methods
    .map((method) => {
      const list = txns.filter((t) => t.method === method)
      return {
        method,
        count: list.length,
        amount: list.reduce((s, t) => s + t.amountExpected, 0),
      }
    })
    .filter((m) => m.count > 0)
}

export function employeeBreakdown(
  txns: Transaction[],
  names: Record<string, string>,
): { employeeId: string; name: string; count: number; confirmed: number; expected: number }[] {
  const map = new Map<string, { count: number; confirmed: number; expected: number }>()
  for (const t of txns) {
    const cur = map.get(t.employeeId) ?? { count: 0, confirmed: 0, expected: 0 }
    cur.count += 1
    cur.expected += t.amountExpected
    cur.confirmed += Math.min(t.amountConfirmed, t.amountExpected)
    map.set(t.employeeId, cur)
  }
  return [...map.entries()]
    .map(([employeeId, v]) => ({
      employeeId,
      name: names[employeeId] ?? '—',
      ...v,
    }))
    .sort((a, b) => b.confirmed - a.confirmed)
}

export function toCSV(txns: Transaction[], employeeNames: Record<string, string>): string {
  const header = [
    'Reference',
    'Date',
    'Montant attendu (DZD)',
    'Montant confirme (DZD)',
    'Statut',
    'Moyen',
    'Client',
    'Terminal',
    'Employé',
    'Ecart (DZD)',
  ]
  const rows = txns.map((t) => [
    t.reference,
    new Date(t.date).toISOString(),
    String(Math.round(t.amountExpected)),
    String(Math.round(t.amountConfirmed)),
    t.status,
    t.method,
    t.customer.replace(/;/g, ','),
    t.terminal,
    (employeeNames[t.employeeId] ?? '').replace(/;/g, ','),
    String(Math.round(t.amountExpected - t.amountConfirmed)),
  ])
  return [header, ...rows].map((r) => r.map((c) => `"${c}"`).join(';')).join('\n')
}
