import type { ReceiptAnalysis, Transaction } from '../types'
import { hashString } from '../data/seed'

export interface ReceiptCheck {
  id: 'reference' | 'amount' | 'date' | 'terminal' | 'stamp' | 'font' | 'duplicate'
  ok: boolean
  detail: string
}

/**
 * Simulated document analysis. It reads the values entered for the
 * transaction and produces deterministic consistency checks so the demo
 * behaves the same way on every run. It never contacts a bank.
 */
export function runReceiptAnalysis(input: {
  fileName: string
  image: string
  tx: Transaction
  all: Transaction[]
  merchant: string
}): ReceiptAnalysis {
  const { fileName, image, tx, all, merchant } = input
  const h = hashString(`${fileName}:${image.length}:${tx.reference}`)
  const band = (shift: number) => (h >> shift) % 100

  const refOk = band(0) > 6
  const amountDiff = tx.amountConfirmed > 0 && Math.abs(tx.amountConfirmed - tx.amountExpected) > 1
  const amountOk = !amountDiff && band(3) > 10
  const dateOk = band(6) > 12
  const terminalOk = band(9) > 6
  const stampOk = band(12) > 18
  const fontOk = band(15) > 20
  const duplicateOk = !all.some(
    (o) => o.id !== tx.id && o.receipt?.fileName === fileName,
  )

  const ocrAmount = amountOk
    ? tx.amountExpected
    : Math.max(0, tx.amountExpected - (amountDiff ? tx.amountExpected - tx.amountConfirmed : 2_000))
  const ocrDate = dateOk
    ? new Date(tx.date)
    : new Date(new Date(tx.date).getTime() - 7 * 86_400_000)

  const checks: ReceiptCheck[] = [
    {
      id: 'reference',
      ok: refOk,
      detail: refOk
        ? `Référence ${tx.reference} lue et identique.`
        : 'Référence illisible ou différente de la saisie.',
    },
    {
      id: 'amount',
      ok: amountOk,
      detail: amountOk
        ? `Montant ${tx.amountExpected} DZD aligné avec la saisie.`
        : `Le reçu affiche ${ocrAmount} DZD au lieu de ${tx.amountExpected} DZD.`,
    },
    {
      id: 'date',
      ok: dateOk,
      detail: dateOk
        ? 'Date du ticket cohérente avec la transaction.'
        : `Date du ticket ${ocrDate.toLocaleDateString('fr-FR')} incohérente.`,
    },
    {
      id: 'terminal',
      ok: terminalOk,
      detail: terminalOk
        ? `Terminal ${tx.terminal} présent sur le ticket.`
        : 'Identifiant du terminal différent.',
    },
    {
      id: 'stamp',
      ok: stampOk,
      detail: stampOk
        ? 'Signature électronique du terminal détectée.'
        : 'Aucune signature / cachet du terminal visible.',
    },
    {
      id: 'font',
      ok: fontOk,
      detail: fontOk
        ? 'Typographie et alignement homogènes.'
        : 'Police du total différente du reste du ticket (retouche probable).',
    },
    {
      id: 'duplicate',
      ok: duplicateOk,
      detail: duplicateOk
        ? 'Aucun reçu identique dans le journal.'
        : 'Ce reçu a déjà été utilisé sur une autre transaction.',
    },
  ]

  const passed = checks.filter((c) => c.ok).length
  const score = Math.round((passed / checks.length) * 100)
  const verdict: ReceiptAnalysis['verdict'] =
    score >= 85 ? 'clean' : score >= 55 ? 'doubtful' : 'suspicious'

  return {
    fileName,
    analyzedAt: new Date().toISOString(),
    score,
    verdict,
    checks,
    ocr: {
      reference: refOk ? tx.reference : tx.reference.slice(0, -2) + '??',
      amount: ocrAmount,
      date: ocrDate.toLocaleDateString('fr-FR'),
      terminal: tx.terminal,
      merchant,
    },
    image,
  }
}

export function resizeImage(file: File, maxSize = 720): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = () => reject(new Error('read-error'))
    reader.onload = () => {
      const img = new Image()
      img.onerror = () => reject(new Error('decode-error'))
      img.onload = () => {
        const ratio = Math.min(1, maxSize / Math.max(img.width, img.height))
        const canvas = document.createElement('canvas')
        canvas.width = Math.round(img.width * ratio)
        canvas.height = Math.round(img.height * ratio)
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          resolve(String(reader.result))
          return
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height)
        resolve(canvas.toDataURL('image/jpeg', 0.72))
      }
      img.src = String(reader.result)
    }
    reader.readAsDataURL(file)
  })
}
