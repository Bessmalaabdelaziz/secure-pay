export type Role = 'owner' | 'employee'

export type TxStatus =
  | 'confirmed'
  | 'pending'
  | 'failed'
  | 'delayed'
  | 'missing'
  | 'suspicious'

export type PaymentMethod = 'cib' | 'edahabia' | 'cash' | 'virement'

export type Severity = 'low' | 'medium' | 'high'

export type Lang = 'fr' | 'ar'

export interface Permissions {
  addTransaction: boolean
  viewAllTransactions: boolean
  viewReports: boolean
  viewFraud: boolean
  verifyPayments: boolean
  manageEmployees: boolean
}

export interface User {
  id: string
  name: string
  email: string
  phone: string
  role: Role
  shopName: string
  passwordHash: string
  salt: string
  permissions: Permissions
  active: boolean
  createdAt: string
  color: string
}

export interface ReceiptAnalysis {
  fileName: string
  analyzedAt: string
  score: number
  verdict: 'clean' | 'doubtful' | 'suspicious'
  checks: { id: string; ok: boolean; detail: string }[]
  ocr: {
    reference: string
    amount: number
    date: string
    terminal: string
    merchant: string
  }
  image?: string
}

export interface Transaction {
  id: string
  reference: string
  amountExpected: number
  amountConfirmed: number
  date: string
  method: PaymentMethod
  status: TxStatus
  customer: string
  terminal: string
  employeeId: string
  notes: string
  bankRef?: string
  bankCheckedAt?: string
  bankMessage?: string
  duplicateOf?: string
  flags: string[]
  receipt?: ReceiptAnalysis
  createdAt: string
  updatedAt: string
}

export type AlertType =
  | 'duplicate'
  | 'amount_mismatch'
  | 'high_value'
  | 'off_hours'
  | 'rapid_succession'
  | 'suspicious_receipt'
  | 'missing_payment'
  | 'failed_payment'
  | 'delayed_payment'
  | 'permission'

export interface Alert {
  id: string
  type: AlertType
  severity: Severity
  titleKey: string
  messageKey: string
  params: Record<string, string | number>
  transactionId?: string
  createdAt: string
  read: boolean
  resolved: boolean
}

export interface AuditEntry {
  id: string
  actorId: string
  actorName: string
  action: string
  detail: string
  at: string
  severity: Severity
}

export type BankStatus = 'confirmed' | 'pending' | 'failed' | 'not_found' | 'mismatch'

export interface BankRecord {
  reference: string
  status: BankStatus
  settledAmount: number
  settlementDate?: string
  terminal: string
  issuer: string
  message: string
}

export interface Settings {
  lang: Lang
  notificationsEnabled: boolean
  biometric: boolean
  twoFactor: boolean
  highValueThreshold: number
  autoLockMinutes: number
}

export interface AppState {
  version: number
  users: User[]
  transactions: Transaction[]
  alerts: Alert[]
  audit: AuditEntry[]
  bankLedger: Record<string, BankRecord>
  settings: Settings
  sessionUserId: string | null
}

export interface NewTransactionInput {
  reference: string
  amountExpected: number
  date: string
  method: PaymentMethod
  customer: string
  terminal: string
  notes: string
  employeeId: string
}

export interface Stats {
  expected: number
  confirmed: number
  pending: number
  missing: number
  failed: number
  suspicious: number
  delayed: number
  count: number
  gap: number
  recoveryRate: number
  avgTicket: number
}
