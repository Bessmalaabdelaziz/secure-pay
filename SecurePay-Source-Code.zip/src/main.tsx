import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import App from './App'
import { StoreProvider } from './store'
import './styles.css'

// On Android (Capacitor) the WebView is served from a local origin where a cold
// start or resume may load the start URL; the hash router keeps deep routes working.
const nativeBridge = (window as unknown as {
  Capacitor?: { isNativePlatform?: () => boolean }
}).Capacitor
const Router = nativeBridge?.isNativePlatform?.() ? HashRouter : BrowserRouter

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Router>
      <StoreProvider>
        <App />
      </StoreProvider>
    </Router>
  </StrictMode>,
)
