import { useMemo, useState } from 'react'
import type { DayPoint } from '../lib/stats'
import { formatAmount, formatCompact } from '../lib/format'
import type { TxStatus } from '../types'
import { STATUS_LABEL } from '../lib/format'

export function BarPairChart({
  points,
  height = 150,
  lang,
}: {
  points: DayPoint[]
  height?: number
  lang: 'fr' | 'ar'
}) {
  const [active, setActive] = useState<number>(points.length - 1)
  const max = Math.max(1, ...points.map((p) => Math.max(p.expected, p.confirmed)))
  const selected = points[Math.min(active, points.length - 1)]
  const width = 320
  const padX = 4
  const padB = 22
  const chartH = height - padB
  const slot = (width - padX * 2) / Math.max(points.length, 1)
  const barW = Math.max(2.5, Math.min(7, slot * 0.32))
  const labelEvery = points.length > 20 ? 6 : points.length > 10 ? 3 : 1

  return (
    <div className="chart" dir="ltr">
      <div className="chart__readout">
        <div>
          <span className="chart__readout-label">
            {new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-FR', {
              day: '2-digit',
              month: 'short',
            }).format(selected.date)}
          </span>
          <strong>{formatAmount(selected.confirmed)} DZD</strong>
        </div>
        <div className="chart__legend">
          <span>
            <i className="dot dot--green" />
            {lang === 'ar' ? 'مؤكد' : 'Confirmé'}
          </span>
          <span>
            <i className="dot dot--muted" />
            {lang === 'ar' ? 'متوقع' : 'Attendu'}
          </span>
        </div>
      </div>
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="chart__svg"
        role="img"
        aria-label="Encaissements par jour"
        preserveAspectRatio="none"
      >
        {[0.25, 0.5, 0.75, 1].map((g) => (
          <line
            key={g}
            x1={0}
            x2={width}
            y1={chartH - chartH * g}
            y2={chartH - chartH * g}
            className="chart__grid"
          />
        ))}
        {points.map((p, i) => {
          const cx = padX + slot * i + slot / 2
          const hExp = (Math.max(p.expected, 1) / max) * (chartH - 8)
          const hConf = (p.confirmed / max) * (chartH - 8)
          const isActive = i === Math.min(active, points.length - 1)
          return (
            <g key={p.date.toISOString()} onPointerDown={() => setActive(i)} className="chart__bar">
              <rect x={cx - barW - 1.5} y={0} width={barW * 2 + 4} height={height} fill="transparent" />
              <rect
                x={cx - barW - 1}
                y={chartH - hExp}
                width={barW}
                height={hExp}
                rx={barW / 2}
                className={`chart__bar-exp ${isActive ? 'is-active' : ''}`}
              />
              <rect
                x={cx + 1}
                y={chartH - hConf}
                width={barW}
                height={Math.max(hConf, p.confirmed > 0 ? 2 : 0)}
                rx={barW / 2}
                className={`chart__bar-conf ${isActive ? 'is-active' : ''}`}
              />
              {i % labelEvery === 0 ? (
                <text x={cx} y={height - 6} textAnchor="middle" className="chart__label">
                  {new Intl.DateTimeFormat(lang === 'ar' ? 'ar-DZ' : 'fr-FR', {
                    day: '2-digit',
                  }).format(p.date)}
                </text>
              ) : null}
            </g>
          )
        })}
      </svg>
    </div>
  )
}

const STATUS_COLOR: Record<TxStatus, string> = {
  confirmed: '#22C55E',
  pending: '#F59E0B',
  delayed: '#FB923C',
  missing: '#F04438',
  failed: '#EF4444',
  suspicious: '#A78BFA',
}

export function Donut({
  data,
  total,
  centerLabel,
  lang,
}: {
  data: { status: TxStatus; count: number; amount: number }[]
  total: number
  centerLabel: string
  lang: 'fr' | 'ar'
}) {
  const radius = 46
  const circumference = 2 * Math.PI * radius
  let offset = 0
  const segments = data.filter((d) => d.count > 0)
  return (
    <div className="donut" dir="ltr">
      <svg viewBox="0 0 120 120" className="donut__svg" role="img" aria-label={centerLabel}>
        <circle cx="60" cy="60" r={radius} className="donut__track" />
        {segments.map((seg) => {
          const fraction = total > 0 ? seg.amount / total : 0
          const length = fraction * circumference
          const el = (
            <circle
              key={seg.status}
              cx="60"
              cy="60"
              r={radius}
              fill="none"
              stroke={STATUS_COLOR[seg.status]}
              strokeWidth="13"
              strokeDasharray={`${Math.max(length - 2, 0)} ${circumference}`}
              strokeDashoffset={-offset}
              strokeLinecap="round"
              transform="rotate(-90 60 60)"
            />
          )
          offset += length
          return el
        })}
      </svg>
      <div className="donut__center">
        <span>{centerLabel}</span>
        <strong>{formatCompact(total)}</strong>
      </div>
      <ul className="donut__legend">
        {data
          .filter((d) => d.count > 0)
          .map((d) => (
            <li key={d.status}>
              <i style={{ background: STATUS_COLOR[d.status] }} />
              <span>{STATUS_LABEL[d.status][lang]}</span>
              <b>{d.count}</b>
            </li>
          ))}
      </ul>
    </div>
  )
}

export function HBars({
  items,
}: {
  items: { label: string; value: number; caption?: string; color?: string }[]
}) {
  const max = Math.max(1, ...items.map((i) => i.value))
  return (
    <div className="hbars">
      {items.map((item) => (
        <div className="hbars__row" key={item.label}>
          <div className="hbars__head">
            <span>{item.label}</span>
            <b>{item.caption ?? formatAmount(item.value)}</b>
          </div>
          <div className="hbars__track">
            <div
              className="hbars__fill"
              style={{
                width: `${Math.max((item.value / max) * 100, 3)}%`,
                background: item.color ?? 'linear-gradient(90deg,#2F6BFF,#22D3EE)',
              }}
            />
          </div>
        </div>
      ))}
    </div>
  )
}

export function MiniSpark({
  values,
  color = '#22C55E',
}: {
  values: number[]
  color?: string
}) {
  const path = useMemo(() => {
    const max = Math.max(1, ...values)
    const step = 100 / Math.max(values.length - 1, 1)
    return values
      .map((v, i) => `${i === 0 ? 'M' : 'L'}${i * step},${28 - (v / max) * 24}`)
      .join(' ')
  }, [values])
  return (
    <svg viewBox="0 0 100 32" className="spark" preserveAspectRatio="none" aria-hidden="true">
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}
