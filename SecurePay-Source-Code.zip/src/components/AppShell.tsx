import { useEffect, type ReactNode } from 'react'
import { NavLink, Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { Icon, type IconName } from './icons'
import { Logo } from './icons'
import { Spinner } from './ui'

function ToastHost() {
  const { toast, clearToast } = useStore()
  useEffect(() => {
    if (!toast) return
    const id = window.setTimeout(clearToast, 3200)
    return () => window.clearTimeout(id)
  }, [toast, clearToast])
  if (!toast) return null
  return (
    <div className={`toast toast--${toast.tone}`} role="status" aria-live="polite">
      <Icon
        name={toast.tone === 'success' ? 'checkCircle' : toast.tone === 'error' ? 'alertTriangle' : 'info'}
        size={18}
      />
      <span>{toast.message}</span>
    </div>
  )
}

export function BootScreen() {
  const { t } = useStore()
  return (
    <div className="boot">
      <Logo size={64} />
      <p className="boot__name">SecurePay</p>
      <Spinner label={t('splash.loading')} />
    </div>
  )
}

export function Protected({ children }: { children: ReactNode }) {
  const { ready, currentUser } = useStore()
  if (!ready) return <BootScreen />
  if (!currentUser) return <Navigate to="/auth" replace />
  return <>{children}</>
}

interface NavItem {
  to: string
  icon: IconName
  label: string
  center?: boolean
}

export function AppLayout() {
  const { t, currentUser, state, can } = useStore()
  const location = useLocation()
  const navigate = useNavigate()
  const unread = state.alerts.filter((a) => !a.read && !a.resolved).length

  useEffect(() => {
    window.scrollTo({ top: 0 })
  }, [location.pathname])

  if (!currentUser) return <Navigate to="/auth" replace />

  const isOwner = currentUser.role === 'owner'
  const items: NavItem[] = isOwner
    ? [
        { to: '/app/dashboard', icon: 'home', label: t('nav.home') },
        { to: '/app/transactions', icon: 'list', label: t('nav.transactions') },
        { to: '/app/transactions/new', icon: 'plus', label: t('nav.add'), center: true },
        { to: '/app/fraud', icon: 'shield', label: t('nav.fraud') },
        { to: '/app/profile', icon: 'user', label: t('nav.profile') },
      ]
    : [
        { to: '/app/dashboard', icon: 'home', label: t('nav.home') },
        { to: '/app/transactions', icon: 'list', label: t('nav.transactions') },
        { to: '/app/transactions/new', icon: 'plus', label: t('nav.add'), center: true },
        { to: '/app/notifications', icon: 'bell', label: t('nav.alerts') },
        { to: '/app/profile', icon: 'user', label: t('nav.profile') },
      ]

  return (
    <div className="app-frame">
      <div className="app-bg" aria-hidden="true" />
      <div className="app-shell">
        <div key={location.pathname} className="route-view">
          <Outlet />
        </div>
        <nav className="tabbar" aria-label="Navigation principale">
          {items.map((item) =>
            item.center ? (
              <button
                key={item.to}
                type="button"
                className="tabbar__fab"
                aria-label={item.label}
                onClick={() =>
                  can('addTransaction')
                    ? navigate(item.to)
                    : navigate('/app/profile')
                }
              >
                <Icon name="plus" size={26} strokeWidth={2.1} />
              </button>
            ) : (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `tabbar__item ${isActive ? 'is-active' : ''}`}
              >
                <span className="tabbar__icon">
                  <Icon name={item.icon} size={21} />
                  {item.to === '/app/notifications' && unread > 0 ? (
                    <span className="tabbar__dot" />
                  ) : null}
                </span>
                <span className="tabbar__label">{item.label}</span>
              </NavLink>
            ),
          )}
        </nav>
        <ToastHost />
      </div>
    </div>
  )
}
