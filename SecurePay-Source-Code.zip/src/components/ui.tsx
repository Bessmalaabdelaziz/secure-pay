import {
  useEffect,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type SelectHTMLAttributes,
  type TextareaHTMLAttributes,
} from 'react'
import { useNavigate } from 'react-router-dom'
import { Icon, type IconName } from './icons'
import { formatAmount, initials } from '../lib/format'
import type { TxStatus } from '../types'
import { STATUS_LABEL } from '../lib/format'
import { useStore } from '../store'

export function Screen({
  children,
  className = '',
  withNav = true,
}: {
  children: ReactNode
  className?: string
  withNav?: boolean
}) {
  return (
    <div className={`screen ${withNav ? 'screen--nav' : ''} ${className}`.trim()}>{children}</div>
  )
}

export function PageHeader({
  title,
  subtitle,
  onBack,
  actions,
  transparent = false,
}: {
  title: string
  subtitle?: string
  onBack?: () => void
  actions?: ReactNode
  transparent?: boolean
}) {
  const navigate = useNavigate()
  return (
    <header className={`page-header ${transparent ? 'page-header--flat' : ''}`}>
      <button
        type="button"
        className="icon-btn page-header__back"
        aria-label="Retour"
        onClick={() => (onBack ? onBack() : navigate(-1))}
      >
        <Icon name="arrowLeft" size={20} />
      </button>
      <div className="page-header__titles">
        <h1>{title}</h1>
        {subtitle ? <p>{subtitle}</p> : null}
      </div>
      {actions ? <div className="page-header__actions">{actions}</div> : <span className="page-header__spacer" />}
    </header>
  )
}

export function Card({
  children,
  className = '',
  onClick,
  tone,
}: {
  children: ReactNode
  className?: string
  onClick?: () => void
  tone?: 'default' | 'accent' | 'warn' | 'danger' | 'success'
}) {
  const cls = `card ${tone && tone !== 'default' ? `card--${tone}` : ''} ${
    onClick ? 'card--tap' : ''
  } ${className}`.trim()
  if (onClick) {
    return (
      <button type="button" className={cls} onClick={onClick}>
        {children}
      </button>
    )
  }
  return <div className={cls}>{children}</div>
}

export function SectionHeader({
  title,
  action,
  onAction,
}: {
  title: string
  action?: string
  onAction?: () => void
}) {
  return (
    <div className="section-header">
      <h2>{title}</h2>
      {action && onAction ? (
        <button type="button" className="link-btn" onClick={onAction}>
          {action}
          <Icon name="chevronRight" size={14} />
        </button>
      ) : null}
    </div>
  )
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'success'
  size?: 'sm' | 'md' | 'lg'
  full?: boolean
  icon?: IconName
  iconEnd?: IconName
  loading?: boolean
}

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  full,
  icon,
  iconEnd,
  loading,
  className = '',
  disabled,
  ...rest
}: ButtonProps) {
  return (
    <button
      type="button"
      className={`btn btn--${variant} btn--${size} ${full ? 'btn--full' : ''} ${className}`.trim()}
      disabled={disabled || loading}
      {...rest}
    >
      {loading ? <span className="spinner" aria-hidden="true" /> : null}
      {!loading && icon ? <Icon name={icon} size={18} /> : null}
      <span>{children}</span>
      {!loading && iconEnd ? <Icon name={iconEnd} size={16} /> : null}
    </button>
  )
}

export function IconButton({
  icon,
  label,
  badge,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  icon: IconName
  label: string
  badge?: number
}) {
  return (
    <button type="button" className="icon-btn" aria-label={label} {...rest}>
      <Icon name={icon} size={20} />
      {badge && badge > 0 ? <span className="icon-btn__badge">{badge > 9 ? '9+' : badge}</span> : null}
    </button>
  )
}

export function Badge({
  children,
  tone = 'neutral',
  icon,
}: {
  children: ReactNode
  tone?: 'neutral' | 'success' | 'warn' | 'danger' | 'info' | 'purple'
  icon?: IconName
}) {
  return (
    <span className={`badge badge--${tone}`}>
      {icon ? <Icon name={icon} size={12} /> : null}
      {children}
    </span>
  )
}

const STATUS_TONE: Record<TxStatus, 'success' | 'warn' | 'danger' | 'info' | 'purple'> = {
  confirmed: 'success',
  pending: 'warn',
  failed: 'danger',
  delayed: 'warn',
  missing: 'danger',
  suspicious: 'purple',
}

const STATUS_ICON: Record<TxStatus, IconName> = {
  confirmed: 'checkCircle',
  pending: 'clock',
  failed: 'xCircle',
  delayed: 'clock',
  missing: 'alertTriangle',
  suspicious: 'shield',
}

export function StatusBadge({ status }: { status: TxStatus }) {
  const { lang } = useStore()
  return (
    <Badge tone={STATUS_TONE[status]} icon={STATUS_ICON[status]}>
      {STATUS_LABEL[status][lang]}
    </Badge>
  )
}

export function Avatar({
  name,
  color,
  size = 40,
}: {
  name: string
  color?: string
  size?: number
}) {
  return (
    <span
      className="avatar"
      style={{
        width: size,
        height: size,
        background: color ? `${color}22` : 'rgba(59,118,255,0.18)',
        color: color ?? '#8FB0FF',
        fontSize: size * 0.36,
      }}
    >
      {initials(name)}
    </span>
  )
}

export function Field({
  label,
  hint,
  error,
  children,
  optional,
}: {
  label: string
  hint?: string
  error?: string
  children: ReactNode
  optional?: string
}) {
  return (
    <label className={`field ${error ? 'field--error' : ''}`}>
      <span className="field__label">
        {label}
        {optional ? <em>{optional}</em> : null}
      </span>
      {children}
      {error ? <span className="field__error">{error}</span> : hint ? <span className="field__hint">{hint}</span> : null}
    </label>
  )
}

export function Input({ className = '', ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`input ${className}`.trim()} {...rest} />
}

export function TextArea({ className = '', ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`input textarea ${className}`.trim()} {...rest} />
}

export function Select({ className = '', children, ...rest }: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div className="select-wrap">
      <select className={`input select ${className}`.trim()} {...rest}>
        {children}
      </select>
      <Icon name="chevronDown" size={16} />
    </div>
  )
}

export function Toggle({
  checked,
  onChange,
  label,
  description,
}: {
  checked: boolean
  onChange: (v: boolean) => void
  label: string
  description?: string
}) {
  return (
    <button
      type="button"
      className="toggle-row"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
    >
      <span className="toggle-row__text">
        <span className="toggle-row__label">{label}</span>
        {description ? <span className="toggle-row__desc">{description}</span> : null}
      </span>
      <span className={`switch ${checked ? 'switch--on' : ''}`}>
        <span className="switch__knob" />
      </span>
    </button>
  )
}

export function Segmented<T extends string | number>({
  options,
  value,
  onChange,
  name,
}: {
  options: { value: T; label: string }[]
  value: T
  onChange: (v: T) => void
  name?: string
}) {
  return (
    <div className="segmented" role="group" aria-label={name}>
      {options.map((opt) => (
        <button
          type="button"
          key={String(opt.value)}
          className={`segmented__item ${opt.value === value ? 'is-active' : ''}`}
          onClick={() => onChange(opt.value)}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}

export function Chip({
  children,
  active,
  onClick,
  tone,
}: {
  children: ReactNode
  active?: boolean
  onClick?: () => void
  tone?: 'success' | 'warn' | 'danger'
}) {
  return (
    <button
      type="button"
      className={`chip ${active ? 'chip--active' : ''} ${tone ? `chip--${tone}` : ''}`.trim()}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

export function Sheet({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null
  return (
    <div className="sheet-overlay" onClick={onClose} role="presentation">
      <div
        className="sheet"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sheet__handle" />
        <div className="sheet__head">
          <h3>{title}</h3>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Fermer">
            <Icon name="x" size={18} />
          </button>
        </div>
        <div className="sheet__body">{children}</div>
        {footer ? <div className="sheet__footer">{footer}</div> : null}
      </div>
    </div>
  )
}

export function EmptyState({
  icon,
  title,
  hint,
  action,
}: {
  icon: IconName
  title: string
  hint?: string
  action?: ReactNode
}) {
  return (
    <div className="empty">
      <span className="empty__icon">
        <Icon name={icon} size={26} />
      </span>
      <p className="empty__title">{title}</p>
      {hint ? <p className="empty__hint">{hint}</p> : null}
      {action ? <div className="empty__action">{action}</div> : null}
    </div>
  )
}

export function InfoNote({
  icon = 'info',
  tone = 'info',
  title,
  children,
}: {
  icon?: IconName
  tone?: 'info' | 'warn' | 'danger' | 'success'
  title?: string
  children: ReactNode
}) {
  return (
    <div className={`note note--${tone}`}>
      <span className="note__icon">
        <Icon name={icon} size={16} />
      </span>
      <div className="note__body">
        {title ? <p className="note__title">{title}</p> : null}
        <div className="note__text">{children}</div>
      </div>
    </div>
  )
}

export function KeyValue({
  label,
  value,
  tone,
}: {
  label: string
  value: ReactNode
  tone?: 'success' | 'danger' | 'warn'
}) {
  return (
    <div className="kv">
      <span className="kv__label">{label}</span>
      <span className={`kv__value ${tone ? `kv__value--${tone}` : ''}`}>{value}</span>
    </div>
  )
}

export function Money({
  value,
  size = 'md',
  strong,
}: {
  value: number
  size?: 'sm' | 'md' | 'lg' | 'xl'
  strong?: boolean
}) {
  return (
    <span className={`money money--${size} ${strong ? 'money--strong' : ''}`}>
      {formatAmount(value)}
      <span className="money__cur">DZD</span>
    </span>
  )
}

export function ProgressBar({
  value,
  tone = 'success',
  label,
}: {
  value: number
  tone?: 'success' | 'warn' | 'danger' | 'info'
  label?: string
}) {
  return (
    <div className="progress">
      {label ? (
        <div className="progress__head">
          <span>{label}</span>
          <span>{Math.round(value)}%</span>
        </div>
      ) : null}
      <div className="progress__track">
        <div
          className={`progress__fill progress__fill--${tone}`}
          style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
        />
      </div>
    </div>
  )
}

export function Spinner({ label }: { label?: string }) {
  return (
    <div className="busy">
      <span className="spinner spinner--lg" />
      {label ? <span className="busy__label">{label}</span> : null}
    </div>
  )
}

export function AccessDenied() {
  const { t } = useStore()
  return (
    <Screen>
      <PageHeader title={t('common.permissionDenied')} />
      <EmptyState
        icon="lock"
        title={t('common.permissionDenied')}
        hint={t('prof.roleEmployee')}
      />
    </Screen>
  )
}
