import { useNavigate } from 'react-router-dom'
import type { Transaction } from '../types'
import { METHOD_LABEL, METHOD_SHORT, formatAmount, formatTime } from '../lib/format'
import { useStore } from '../store'
import { Icon, type IconName } from './icons'
import { StatusBadge } from './ui'

const METHOD_ICON: Record<Transaction['method'], IconName> = {
  cib: 'card',
  edahabia: 'walletCards',
  cash: 'wallet',
  virement: 'bank',
}

export function TransactionRow({
  tx,
  showEmployee = false,
  onOpen,
}: {
  tx: Transaction
  showEmployee?: boolean
  onOpen?: () => void
}) {
  const { t, lang, employeeName } = useStore()
  const navigate = useNavigate()
  const open = onOpen ?? (() => navigate(`/app/transactions/${tx.id}`))
  const gap = tx.amountExpected - tx.amountConfirmed

  return (
    <button type="button" className="txrow" onClick={open}>
      <span className={`txrow__icon txrow__icon--${tx.status}`}>
        <Icon name={METHOD_ICON[tx.method]} size={19} />
      </span>
      <span className="txrow__main">
        <span className="txrow__top">
          <span className="txrow__customer">{tx.customer}</span>
          <span className="txrow__amount">{formatAmount(tx.amountExpected)}</span>
        </span>
        <span className="txrow__bottom">
          <span className="txrow__meta">
            {METHOD_SHORT[tx.method]} · {tx.reference.slice(-6)}
            {showEmployee ? ` · ${employeeName(tx.employeeId).split(' ')[0]}` : ''}
          </span>
          <span className="txrow__right">
            <span className="txrow__time">{formatTime(tx.date, lang)}</span>
            <StatusBadge status={tx.status} />
          </span>
        </span>
        {gap > 1 && tx.amountConfirmed > 0 ? (
          <span className="txrow__gap">
            {t('det.confirmedAmount')} : {formatAmount(tx.amountConfirmed)} DZD
          </span>
        ) : null}
      </span>
    </button>
  )
}

export function statusLabel(tx: Transaction): string {
  return `${METHOD_LABEL[tx.method].fr}`
}
