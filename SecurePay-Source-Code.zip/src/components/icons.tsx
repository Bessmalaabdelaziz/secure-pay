import type { SVGProps } from 'react'

export type IconName =
  | 'home'
  | 'list'
  | 'plus'
  | 'shield'
  | 'chart'
  | 'user'
  | 'users'
  | 'bell'
  | 'arrowLeft'
  | 'arrowRight'
  | 'arrowUpRight'
  | 'arrowDownRight'
  | 'check'
  | 'checkCircle'
  | 'x'
  | 'xCircle'
  | 'clock'
  | 'alert'
  | 'alertTriangle'
  | 'search'
  | 'filter'
  | 'upload'
  | 'camera'
  | 'bank'
  | 'card'
  | 'receipt'
  | 'lock'
  | 'logout'
  | 'settings'
  | 'eye'
  | 'eyeOff'
  | 'download'
  | 'trendUp'
  | 'trendDown'
  | 'sparkles'
  | 'phone'
  | 'mail'
  | 'chevronRight'
  | 'trash'
  | 'edit'
  | 'copy'
  | 'info'
  | 'zap'
  | 'wallet'
  | 'calendar'
  | 'globe'
  | 'refresh'
  | 'send'
  | 'key'
  | 'building'
  | 'scan'
  | 'walletCards'
  | 'target'
  | 'flag'
  | 'shieldCheck'
  | 'chevronDown'
  | 'minus'
  | 'pause'

const PATHS: Record<IconName, JSX.Element> = {
  home: (
    <>
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5" />
    </>
  ),
  list: (
    <>
      <path d="M8 6h13M8 12h13M8 18h13" />
      <circle cx="3.5" cy="6" r="1.2" />
      <circle cx="3.5" cy="12" r="1.2" />
      <circle cx="3.5" cy="18" r="1.2" />
    </>
  ),
  plus: <path d="M12 5v14M5 12h14" />,
  minus: <path d="M5 12h14" />,
  shield: (
    <>
      <path d="M12 3l7.5 3v5.5c0 4.7-3.1 8.2-7.5 9.5-4.4-1.3-7.5-4.8-7.5-9.5V6L12 3z" />
      <path d="M9 12l2 2 4-4" />
    </>
  ),
  chart: (
    <>
      <path d="M4 20h16" />
      <path d="M7 20V10M12 20V4M17 20v-7" />
    </>
  ),
  user: (
    <>
      <circle cx="12" cy="8" r="3.6" />
      <path d="M4.5 20c.7-3.6 3.7-5.6 7.5-5.6s6.8 2 7.5 5.6" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M2.8 19.5c.6-3.2 3.2-5 6.2-5s5.6 1.8 6.2 5" />
      <path d="M16 5.3a3.2 3.2 0 0 1 0 6.2M18 14.9c2 .5 3.4 2.1 3.8 4.6" />
    </>
  ),
  bell: (
    <>
      <path d="M6 9a6 6 0 1 1 12 0c0 4 1.4 5.4 2 6H4c.6-.6 2-2 2-6z" />
      <path d="M10 19a2 2 0 0 0 4 0" />
    </>
  ),
  arrowLeft: <path d="M19 12H5m0 0 6-6m-6 6 6 6" />,
  arrowRight: <path d="M5 12h14m0 0-6-6m6 6-6 6" />,
  arrowUpRight: <path d="M7 17 17 7M9 7h8v8" />,
  arrowDownRight: <path d="M7 7l10 10M17 9v8H9" />,
  check: <path d="M4.5 12.5 9.5 17.5 19.5 6.5" />,
  checkCircle: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M8 12.2l2.7 2.6L16 9" />
    </>
  ),
  x: <path d="M6 6l12 12M18 6 6 18" />,
  xCircle: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M9 9l6 6M15 9l-6 6" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3 2" />
    </>
  ),
  alert: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 8v5M12 16.2v.2" />
    </>
  ),
  alertTriangle: (
    <>
      <path d="M12 4 2.8 20h18.4L12 4z" />
      <path d="M12 10v4M12 17.2v.2" />
    </>
  ),
  search: (
    <>
      <circle cx="11" cy="11" r="6.5" />
      <path d="m16 16 4.5 4.5" />
    </>
  ),
  filter: <path d="M3 5h18l-7 8v6l-4 2v-8L3 5z" />,
  upload: (
    <>
      <path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5" />
      <path d="M4 15v3.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V15" />
    </>
  ),
  camera: (
    <>
      <path d="M4 8h2.8l1.4-2h7.6L17 8h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z" />
      <circle cx="12" cy="13" r="3.4" />
    </>
  ),
  bank: (
    <>
      <path d="M3 9.5 12 4l9 5.5" />
      <path d="M5 10v8M10 10v8M14 10v8M19 10v8" />
      <path d="M3 20h18" />
    </>
  ),
  card: (
    <>
      <rect x="2.5" y="5" width="19" height="14" rx="3" />
      <path d="M2.5 10h19" />
      <path d="M6 15h4" />
    </>
  ),
  receipt: (
    <>
      <path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z" />
      <path d="M9 8h6M9 12h6" />
    </>
  ),
  lock: (
    <>
      <rect x="4.5" y="10" width="15" height="10.5" rx="2.5" />
      <path d="M8 10V7.5a4 4 0 0 1 8 0V10" />
      <path d="M12 14.5v2" />
    </>
  ),
  logout: (
    <>
      <path d="M14 4h4a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-4" />
      <path d="M10 8l-4 4 4 4M6 12h9" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 3v2.2M12 18.8V21M4.2 7.5l1.9 1.1M17.9 15.4l1.9 1.1M4.2 16.5l1.9-1.1M17.9 8.6l1.9-1.1" />
    </>
  ),
  eye: (
    <>
      <path d="M2.5 12s3.5-6.5 9.5-6.5S21.5 12 21.5 12S18 18.5 12 18.5 2.5 12 2.5 12z" />
      <circle cx="12" cy="12" r="2.8" />
    </>
  ),
  eyeOff: (
    <>
      <path d="M4 4l16 16" />
      <path d="M9.5 5.9A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-3.2 4M7 7.8A16.6 16.6 0 0 0 2.5 12S6 18.5 12 18.5c1 0 1.9-.2 2.8-.5" />
    </>
  ),
  download: (
    <>
      <path d="M12 4v12m0 0 4.5-4.5M12 16l-4.5-4.5" />
      <path d="M4 18.5V20h16v-1.5" />
    </>
  ),
  trendUp: (
    <>
      <path d="M3 17l6-6 4 4 7-8" />
      <path d="M14 7h6v6" />
    </>
  ),
  trendDown: (
    <>
      <path d="M3 7l6 6 4-4 7 8" />
      <path d="M14 17h6v-6" />
    </>
  ),
  sparkles: (
    <>
      <path d="M12 3l1.8 4.6L18.5 9.4 13.8 11.2 12 16l-1.8-4.8L5.5 9.4l4.7-1.8L12 3z" />
      <path d="M18.5 15.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2z" />
    </>
  ),
  phone: (
    <path d="M7 3h3l1.5 4.5-2 1.6a12 12 0 0 0 5.4 5.4l1.6-2L21 14v3a2 2 0 0 1-2 2C11.6 19 5 12.4 5 5a2 2 0 0 1 2-2z" />
  ),
  mail: (
    <>
      <rect x="3" y="5" width="18" height="14" rx="3" />
      <path d="m3.8 7 8.2 6 8.2-6" />
    </>
  ),
  chevronRight: <path d="m9 5 7 7-7 7" />,
  chevronDown: <path d="m5 9 7 7 7-7" />,
  trash: (
    <>
      <path d="M4 7h16M9 7V4.5h6V7M6.5 7l.9 12.5a1 1 0 0 0 1 1h7.2a1 1 0 0 0 1-1L17.5 7" />
      <path d="M10 11v5.5M14 11v5.5" />
    </>
  ),
  edit: (
    <>
      <path d="M4 20h4l11-11a2.5 2.5 0 0 0-3.5-3.5L4 16.5V20z" />
      <path d="m14 7 3 3" />
    </>
  ),
  copy: (
    <>
      <rect x="8" y="8" width="12" height="12" rx="2.5" />
      <path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5M12 7.8v.2" />
    </>
  ),
  zap: <path d="M13 3 5 14h6l-1 7 8-11h-6l1-7z" />,
  wallet: (
    <>
      <rect x="3" y="6" width="18" height="13" rx="3" />
      <path d="M3 10h18" />
      <path d="M16.5 14.5h1.5" />
    </>
  ),
  walletCards: (
    <>
      <rect x="3" y="7" width="15" height="11" rx="2.5" />
      <path d="M6 7V5.5A1.5 1.5 0 0 1 7.5 4h11A1.5 1.5 0 0 1 20 5.5V15" />
      <path d="M6 11h6" />
    </>
  ),
  calendar: (
    <>
      <rect x="3.5" y="5" width="17" height="15.5" rx="3" />
      <path d="M3.5 10h17M8 3.5V6M16 3.5V6" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3c2.5 2.6 3.8 5.6 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z" />
    </>
  ),
  refresh: (
    <>
      <path d="M20 11a8 8 0 0 0-13.8-5.2L4 8" />
      <path d="M4 4v4h4" />
      <path d="M4 13a8 8 0 0 0 13.8 5.2L20 16" />
      <path d="M20 20v-4h-4" />
    </>
  ),
  send: <path d="M4 12 20 4l-6 16-3.2-6.8L4 12z" />,
  key: (
    <>
      <circle cx="8" cy="12" r="4" />
      <path d="M12 12h9M17 12v3M20 12v2" />
    </>
  ),
  building: (
    <>
      <rect x="4" y="3.5" width="16" height="17" rx="2.5" />
      <path d="M9 8h2M13 8h2M9 12h2M13 12h2M10 20v-4h4v4" />
    </>
  ),
  scan: (
    <>
      <path d="M4 9V6a2 2 0 0 1 2-2h3M20 9V6a2 2 0 0 0-2-2h-3M4 15v3a2 2 0 0 0 2 2h3M20 15v3a2 2 0 0 1-2 2h-3" />
      <path d="M4 12h16" />
    </>
  ),
  target: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="12" cy="12" r="1" />
    </>
  ),
  flag: (
    <>
      <path d="M6 21V4h9l3 3-3 3h4l-4 4H6" />
    </>
  ),
  shieldCheck: (
    <>
      <path d="M12 3l7.5 3v5.5c0 4.7-3.1 8.2-7.5 9.5-4.4-1.3-7.5-4.8-7.5-9.5V6L12 3z" />
      <path d="M8.6 11.9 11 14.3l4.4-4.6" />
    </>
  ),
  pause: (
    <>
      <rect x="7" y="5" width="3.5" height="14" rx="1" />
      <rect x="13.5" y="5" width="3.5" height="14" rx="1" />
    </>
  ),
}

interface IconProps extends Omit<SVGProps<SVGSVGElement>, 'name'> {
  name: IconName
  size?: number
}

export function Icon({ name, size = 20, strokeWidth = 1.7, ...rest }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {PATHS[name]}
    </svg>
  )
}

export function Logo({ size = 44 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
      <defs>
        <linearGradient id="spLogoGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#3B76FF" />
          <stop offset="1" stopColor="#22D3EE" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="18" fill="#0E1B34" />
      <path
        d="M32 12l16 6.5v13c0 10.2-6.8 17.6-16 20.5-9.2-2.9-16-10.3-16-20.5v-13L32 12z"
        fill="url(#spLogoGrad)"
        opacity="0.22"
      />
      <path
        d="M32 12l16 6.5v13c0 10.2-6.8 17.6-16 20.5-9.2-2.9-16-10.3-16-20.5v-13L32 12z"
        fill="none"
        stroke="url(#spLogoGrad)"
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <path
        d="M25 32.5l5 5 9.5-10.5"
        fill="none"
        stroke="#EAF0FA"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}
