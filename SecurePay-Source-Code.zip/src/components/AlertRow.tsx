import { useNavigate } from 'react-router-dom'
import type { Alert } from '../types'
import { useStore } from '../store'
import { relativeTime } from '../lib/format'
import { Icon, type IconName } from './icons'
import type { TranslationKey } from '../i18n'

const TYPE_ICON: Record<Alert['type'], IconName> = {
  duplicate: 'copy',
  amount_mismatch: 'alertTriangle',
  high_value: 'trendUp',
  off_hours: 'clock',
  rapid_succession: 'zap',
  suspicious_receipt: 'receipt',
  missing_payment: 'alertTriangle',
  failed_payment: 'xCircle',
  delayed_payment: 'clock',
  permission: 'lock',
}

export function AlertRow({
  alert,
  onOpen,
  onResolve,
  showResolve = false,
}: {
  alert: Alert
  onOpen?: () => void
  onResolve?: () => void
  showResolve?: boolean
}) {
  const { t, lang } = useStore()
  const severityLabel =
    alert.severity === 'high'
      ? t('notif.severityHigh')
      : alert.severity === 'medium'
        ? t('notif.severityMedium')
        : t('notif.severityLow')

  return (
    <div className={`alertrow alertrow--${alert.severity} ${alert.read ? 'is-read' : ''} ${alert.resolved ? 'is-resolved' : ''}`}>
      <button type="button" className="alertrow__main" onClick={onOpen}>
        <span className={`alertrow__icon alertrow__icon--${alert.severity}`}>
          <Icon name={TYPE_ICON[alert.type] ?? 'alert'} size={18} />
        </span>
        <span className="alertrow__text">
          <span className="alertrow__title">
            {t(alert.titleKey as TranslationKey, alert.params)}
            {!alert.read ? <i className="alertrow__unread" /> : null}
          </span>
          <span className="alertrow__body">
            {t(alert.messageKey as TranslationKey, alert.params)}
          </span>
          <span className="alertrow__meta">
            {severityLabel} · {relativeTime(alert.createdAt, lang)}
            {alert.resolved ? ` · ${t('fraud.resolved')}` : ''}
          </span>
        </span>
      </button>
      {showResolve && !alert.resolved ? (
        <button
          type="button"
          className="alertrow__resolve"
          onClick={onResolve}
          aria-label={t('notif.resolve')}
        >
          <Icon name="check" size={16} />
        </button>
      ) : null}
    </div>
  )
}

export function useAlertNavigation() {
  const navigate = useNavigate()
  return (alert: Alert) => {
    if (alert.transactionId) {
      if (alert.type === 'suspicious_receipt') {
        navigate(`/app/receipt?tx=${alert.transactionId}`)
      } else {
        navigate(`/app/transactions/${alert.transactionId}`)
      }
    } else {
      navigate('/app/notifications')
    }
  }
}
