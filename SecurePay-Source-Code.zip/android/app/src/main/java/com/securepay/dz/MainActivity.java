package com.securepay.dz;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
